package com.star.matrix.impl;

import com.star.matrix.DataLakeService;
import com.star.matrix.MatrixService;
import com.star.matrix.dto.HospitalDetail;
import com.star.matrix.dto.PolicyDataResponse;
import com.star.matrix.dto.request.MatrixHospitalPayload;
import com.star.matrix.entity.*;
import com.star.matrix.properties.ApplicationProperties;
import com.star.matrix.repository.*;
import io.micrometer.tracing.Tracer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.star.matrix.constant.EnvVariableConstant.PMS_MONGO_BATCH_SIZE;
import static com.star.matrix.constant.EnvVariableConstant.POLICY_MONGO_BATCH_SIZE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DataSyncServiceImplTest {

	@InjectMocks
	private DataSyncServiceImpl service;
	
	@Mock
    private DataLakeService dataLakeService;
	
	@Mock
    private HospitalPayloadRepository hospitalPayloadRepository;

	@Mock
    private PolicyBatchProgressRepository policyBatchProgressRepository;

	@Mock
    private PmsBatchProgressRepository pmsBatchProgressRepository;

	@Mock
    private EnvVariablesServiceImpl envVariablesService;

	@Mock
    private PolicyPayloadRepository policyPayloadRepository;

	@Mock
    private MatrixService matrixService;

	@Mock
	private Tracer tracer;

	@Mock
    private ApplicationProperties applicationProperties;

	@Mock
	private PolicyBatchDetailRepository policyBatchDetailRepository;

	@Test
	void testProcessPmsDataFromDataLake() {
		var endTime = LocalDateTime.now().withMinute(0).withSecond(0).withNano(0);
		var startTime = endTime.minusHours(1);
		PmsBatchProgress progress = new PmsBatchProgress();
		progress.setFromTime(startTime);
		progress.setToTime(endTime);

		when(pmsBatchProgressRepository.findFirstByOrderByToTimeDesc()).thenReturn(Optional.of(progress));
		when(dataLakeService.getUpdatedPmsData(anyString(), anyString())).thenReturn(Collections.emptyList());

		service.processPmsDataFromDataLake();
		verify(pmsBatchProgressRepository).save(any(PmsBatchProgress.class));
		verify(dataLakeService).getUpdatedPmsData(anyString(), anyString());
	}

	@Test
	void testProcessPmsDataFromDataLakeOptionalIsNotPresent() {
		when(pmsBatchProgressRepository.findFirstByOrderByToTimeDesc()).thenReturn(Optional.empty());
		when(dataLakeService.getUpdatedPmsData(anyString(), anyString())).thenReturn(Collections.emptyList());

		service.processPmsDataFromDataLake();
		verify(pmsBatchProgressRepository).save(any(PmsBatchProgress.class));
		verify(dataLakeService).getUpdatedPmsData(anyString(), anyString());
	}


	@Test
	void testProcessMinimumPolicyDataFromDataLake() {
		PolicyBatchProgress previous = new PolicyBatchProgress();
		previous.setEndIndex(1);
		previous.setStatus(BatchStatus.COMPLETED);

		when(policyBatchProgressRepository.findFirstByDateOrderByCreatedAtDesc(any()))
				.thenReturn(Optional.of(previous));

		when(dataLakeService.getUpdatedMinimumPolicyDateData(anyString(), anyString(), any()))
				.thenReturn(Collections.emptyList());
		service.processMinimumPolicyDataFromDataLake();

		verify(policyBatchProgressRepository).save(any(PolicyBatchProgress.class));
		verify(dataLakeService).getUpdatedMinimumPolicyDateData(anyString(), anyString(), any());
	}


	@Test
	void testProcessPmsDataFromDataLake_withValidData() {
		LocalDateTime from = LocalDateTime.now().minusHours(1);
		LocalDateTime to = LocalDateTime.now();

		MatrixHospitalPayload response = new MatrixHospitalPayload();
		response.setShaiHospitalId("HOSP123");
		List<HospitalDetail> responseList = List.of(response);

		when(dataLakeService.getUpdatedPmsData(anyString(), anyString())).thenReturn(responseList);

		service.processPmsDataFromDataLake(from, to);

		verify(hospitalPayloadRepository, times(1)).save(any());
		verify(pmsBatchProgressRepository, times(1)).save(any());
	}

	@Test
	void testProcessPmsDataFromDataLake_withEmptyResponse() {
		LocalDateTime from = LocalDateTime.now().minusHours(1);
		LocalDateTime to = LocalDateTime.now();

		when(dataLakeService.getUpdatedPmsData(anyString(), anyString())).thenReturn(List.of());

		service.processPmsDataFromDataLake(from, to);

		verify(hospitalPayloadRepository, never()).save(any());
		verify(pmsBatchProgressRepository, times(1)).save(any());
	}

	@Test
	void testProcessMinimumPolicyDataFromDataLake_skipIfPreviousIsNoData() {
		LocalDate reportedDate = LocalDate.now().minusDays(1);

		PolicyBatchProgress previous = new PolicyBatchProgress();
		previous.setStatus(BatchStatus.NO_DATA);

		when(policyBatchProgressRepository.findFirstByDateOrderByCreatedAtDesc(any()))
				.thenReturn(Optional.of(previous));

		service.processMinimumPolicyDataFromDataLake(reportedDate, false);
		verify(policyPayloadRepository, never()).save(any());
	}

	@Test
	void testProcessMinimumPolicyDataFromDataLake_whenNoPreviousProgress() {
		LocalDate reportedDate = LocalDate.now().minusDays(1);
		List<PolicyDataResponse> responses = new ArrayList<>();

		when(policyBatchProgressRepository.findFirstByDateOrderByCreatedAtDesc(any()))
				.thenReturn(Optional.empty());
		when(dataLakeService.getUpdatedMinimumPolicyDateData(anyString(), anyString(), any()))
				.thenReturn(responses);
		when(policyBatchDetailRepository.findFirstByDateOrderByCreatedAtDesc(any()))
				.thenReturn(Optional.empty());
		service.processMinimumPolicyDataFromDataLake(reportedDate, false);

		verify(policyPayloadRepository, never()).save(any());
		verify(policyBatchProgressRepository).save(any());
	}
	@Test
	void testProcessPmsDataToMatrix() {
		when(envVariablesService.getInt(PMS_MONGO_BATCH_SIZE.name(), 100)).thenReturn(2);

		HospitalPayload payload = new HospitalPayload();
		when(hospitalPayloadRepository.findByStatusOrderByCreatedAtAsc(any(), any())).thenReturn(List.of(payload));

		service.processPmsDataToMatrix();

		verify(matrixService, times(1)).handleHospitalResponse(payload);
	}

	@Test
	void testProcessMinimumPolicyDataToMatrix() {
		when(envVariablesService.getInt(POLICY_MONGO_BATCH_SIZE.name(), 100)).thenReturn(2);
		PolicyPayload payload = new PolicyPayload();
		when(policyPayloadRepository.findByStatusOrderByCreatedAtAsc(any(), any())).thenReturn(List.of(payload));

		service.processMinimumPolicyDataToMatrix();

		verify(matrixService, times(1)).handlePolicyResponse(payload);
	}

	@Test
	void testFetchPolicyData_exceptionHandled() {
		when(dataLakeService.getUpdatedMinimumPolicyDateData(any(), any(), any()))
				.thenThrow(new RuntimeException("Data fetch error"));

		List<PolicyDataResponse> result = service.fetchPolicyData(0, 5, LocalDate.now());

		assertThat(result).isEmpty();
	}

	@Test
	void testFetchPmsData_exceptionHandled() {
		when(dataLakeService.getUpdatedPmsData(any(), any()))
				.thenThrow(new RuntimeException("Boom"));

		List<MatrixHospitalPayload> result = service.fetchPmsData(LocalDateTime.now().minusHours(1), LocalDateTime.now());

		assertThat(result).isEmpty();
	}







}
