package com.star.matrix.impl;

import com.star.matrix.client.DataLakeClient;
import com.star.matrix.dto.PolicyDataResponse;
import com.star.matrix.dto.request.StatementIDRequest;
import com.star.matrix.dto.response.DataBricksResponse;
import com.star.matrix.exception.MatrixDataSyncException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.*;

import static com.star.matrix.constant.EnvVariableConstant.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DataLakeServiceImplTest {

    @InjectMocks
    private DataLakeServiceImpl dataLakeService;

    @Mock
    private DataLakeClient dataLakeClient;

    @Mock
    private EnvVariablesServiceImpl envVariablesService;

    @Mock
    private StatementIDRequest statementRequest;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        statementRequest=new StatementIDRequest();
        statementRequest.setStatement("stmt");
        statementRequest.setWaitTimeout("10s");
        statementRequest.setWarehouseId("wareHouseID");

        when(envVariablesService.getValueByKey(WAREHOUSE_ID.name())).thenReturn("warehouse");
        when(envVariablesService.getValueByKey(WAIT_TIMEOUT.name())).thenReturn(String.valueOf(30));
        when(envVariablesService.getValueByKey(POLICY_MEMBER_QUERY.name())).thenReturn("SELECT * FROM members WHERE policy = '{policyNumber}'");
        when(envVariablesService.getValueByKey(POLICY_DOCUMENT_QUERY.name())).thenReturn("SELECT * FROM documents WHERE policy = '{policyNumber}'");
        when(envVariablesService.getValueByKey(POLICY_CLAIM_DOCUMENT_QUERY.name())).thenReturn("SELECT * FROM claim_docs WHERE intimation = '{intimationNumber}'");
        when(envVariablesService.getValueByKey(POLICY_CLAIM_HISTORY_QUERY.name())).thenReturn("SELECT * FROM claims WHERE policy = '{policyNumber}'");
    }


    @Test
    void testGetPolicyAndMemberDetails_success() {
        when(envVariablesService.getValueByKey(WAREHOUSE_ID.name())).thenReturn("warehouse");
        when(envVariablesService.getValueByKey(WAIT_TIMEOUT.name())).thenReturn(String.valueOf(30));
        when(envVariablesService.getValueByKey(POLICY_MEMBER_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");

        List<Object> row = Arrays.asList(
                "POL123", "2024-01-01", "2025-01-01", "2024", "500000", "PREV123", "John", "M", "1990-01-01",
                "Self", "500000", "No", "HID123", "2024-01-01", "Retail", "2024-01-01", "2025-01-01", "2022-01-01", "productname"
        );

        var result = new DataBricksResponse.Result();
        result.setDataArray(List.of(row));
        var status = new DataBricksResponse.Status();
        status.setState("SUCCEEDED");

        var dataBricksResponse = new DataBricksResponse();
        dataBricksResponse.setStatus(status);
        dataBricksResponse.setResult(result);
        DataBricksResponse.Manifest manifest = new DataBricksResponse.Manifest();
        dataBricksResponse.setManifest(manifest);

        when(dataLakeClient.getDataBricksResponse(any())).thenReturn(dataBricksResponse);

        var resultList = dataLakeService.getPolicyAndMemberDetails("POL123");

        assertNotNull(resultList);
        assertEquals(1, resultList.size());
        assertEquals("POL123", resultList.get(0).getPolicyNo());
        assertNotNull(resultList.get(0).getMembers());
        assertEquals(1, resultList.get(0).getMembers().size());

        ArgumentCaptor<StatementIDRequest> captor = ArgumentCaptor.forClass(StatementIDRequest.class);
        verify(dataLakeClient).getDataBricksResponse(captor.capture());
        String query = captor.getValue().getStatement();
        assertTrue(query.contains("'POL123'"));
    }

    @Test
    void testGetPolicyDocuments_success() {
        when(envVariablesService.getValueByKey(WAREHOUSE_ID.name())).thenReturn("warehouse");
        when(envVariablesService.getValueByKey(WAIT_TIMEOUT.name())).thenReturn(String.valueOf(30));
        when(envVariablesService.getValueByKey(POLICY_MEMBER_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");

        var response = new DataBricksResponse();

        var status = new DataBricksResponse.Status();
        status.setState("SUCCEEDED");
        response.setStatus(status);

        DataBricksResponse.Manifest manifest = new DataBricksResponse.Manifest();
        response.setManifest(manifest);
        DataBricksResponse.Result result = new DataBricksResponse.Result();
        List<Object> row = Arrays.asList("POL123", "PROP456", "PDF", "doc1", "source", "typeA");
        result.setDataArray(List.of(row));
        response.setResult(result);

        when(dataLakeClient.getDataBricksResponse(any())).thenReturn(response);

        var resultList = dataLakeService.getPolicyDocuments(Set.of("POL123"));

        assertEquals(1, resultList.size());
        assertEquals("POL123", resultList.get(0).getPolicyNo());
        assertEquals(1, resultList.get(0).getDocumentDetails().size());

        ArgumentCaptor<StatementIDRequest> captor = ArgumentCaptor.forClass(StatementIDRequest.class);
        verify(dataLakeClient).getDataBricksResponse(captor.capture());
        captor.getValue();
    }


    @Test
    void testGetPolicyDocuments_emptyResultOnException() {
        when(envVariablesService.getValueByKey(POLICY_DOCUMENT_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");
        when(dataLakeClient.getDataBricksResponse(any())).thenThrow(new RuntimeException("Failed"));
        assertThrows(RuntimeException.class, ()-> dataLakeService.getPolicyDocuments(Set.of("X")));
    }

    @Test
    void testGetPolicyClaimHistory_success() {
        when(envVariablesService.getValueByKey(WAREHOUSE_ID.name())).thenReturn("warehouse");
        when(envVariablesService.getValueByKey(WAIT_TIMEOUT.name())).thenReturn(String.valueOf(30));
        when(envVariablesService.getValueByKey(POLICY_CLAIM_HISTORY_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");



        var stmtResp = new DataBricksResponse();

        var status = new DataBricksResponse.Status();
        status.setState("SUCCEEDED");
        stmtResp.setStatus(status);

        DataBricksResponse.Manifest manifest = new DataBricksResponse.Manifest();
        stmtResp.setManifest(manifest);

        DataBricksResponse.Result result = new DataBricksResponse.Result();
        List<Object> row = new ArrayList<>(Collections.nCopies(22, "val"));
        row.set(0, "POL999");
        result.setDataArray(List.of(row));
        stmtResp.setResult(result);

        when(dataLakeClient.getDataBricksResponse(any())).thenReturn(stmtResp);

        var resultList = dataLakeService.getPolicyClaimHistory(Set.of("POL999"));

        assertEquals(1, resultList.size());
        assertEquals("POL999", resultList.get(0).getPolicyNumber());
    }


    @Test
    void testGetPolicyClaimHistory_onFailure_returnsEmpty() {

        when(envVariablesService.getValueByKey(POLICY_CLAIM_HISTORY_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");
        when(dataLakeClient.getDataBricksResponse(any())).thenThrow(new RuntimeException("boom"));
        assertThrows(RuntimeException.class, ()-> dataLakeService.getPolicyClaimHistory(Set.of("X")));

    }

    @Test
    void testGetPolicyClaimDocuments_success() {
        when(envVariablesService.getValueByKey(WAREHOUSE_ID.name())).thenReturn("warehouse");
        when(envVariablesService.getValueByKey(WAIT_TIMEOUT.name())).thenReturn(String.valueOf(30));
        when(envVariablesService.getValueByKey(POLICY_DOCUMENT_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");

        var response = new DataBricksResponse();

        var status = new DataBricksResponse.Status();
        status.setState("SUCCEEDED");
        response.setStatus(status);

        response.setStatementId("stmt789");

        response.setManifest(new DataBricksResponse.Manifest());

        var result = new DataBricksResponse.Result();
        List<List<Object>> dataArray = List.of(
                Arrays.asList("INT123", "docName", "token123", "PDF", "internal")
        );
        result.setDataArray(dataArray);
        response.setResult(result);

        when(dataLakeClient.getDataBricksResponse(any())).thenReturn(response);

        var resultList = dataLakeService.getPolicyClaimDocuments(Set.of("INT123"));

        assertEquals(1, resultList.size());
        assertEquals("INT123", resultList.get(0).getIntimationNumber());

        ArgumentCaptor<StatementIDRequest> captor = ArgumentCaptor.forClass(StatementIDRequest.class);
        verify(dataLakeClient).getDataBricksResponse(captor.capture());
        captor.getValue();
    }


    @Test
    void testGetPolicyClaimDocuments_onErrorReturnsEmpty() {
        when(envVariablesService.getValueByKey(POLICY_CLAIM_DOCUMENT_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");
        when(dataLakeClient.getDataBricksResponse(any())).thenThrow(new RuntimeException("error"));
        assertThrows(RuntimeException.class, ()-> dataLakeService.getPolicyClaimDocuments(Set.of("Y")));

    }

    @Test
    void testCloseDataLakeConnection_success() {
        when(dataLakeClient.stopDBConnection()).thenReturn(true);
        assertTrue(dataLakeService.closeDataLakeConnection());
    }

    @Test
    void testCloseDataLakeConnection_onError() {
        when(dataLakeClient.stopDBConnection()).thenThrow(new RuntimeException("fail"));
        assertFalse(dataLakeService.closeDataLakeConnection());
    }



    @Test
    void testGetPolicyDocuments_nullDataArray_returnsEmptyList() {
        var status = new DataBricksResponse.Status();
        status.setState("SUCCEEDED");

        var result = new DataBricksResponse.Result();
        result.setDataArray(null);

        var response = new DataBricksResponse();
        response.setStatus(status);
        response.setResult(result);

        when(envVariablesService.getValueByKey(WAREHOUSE_ID.name())).thenReturn("warehouse");
        when(envVariablesService.getValueByKey(WAIT_TIMEOUT.name())).thenReturn(String.valueOf(30));
        when(envVariablesService.getValueByKey(POLICY_DOCUMENT_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");


        var statement = new DataBricksResponse();
        var pendingStatus = new DataBricksResponse.Status();
        pendingStatus.setState("PENDING");
        statement.setStatus(pendingStatus);
        statement.setStatementId("stmtNullData");
        when(dataLakeClient.getDataBricksResponse(any())).thenReturn(statement);

        StatementIDRequest statementIDRequest=new StatementIDRequest();
        statementIDRequest.setStatement("select * from policy where number = 'POLNULL'");
        statementIDRequest.setWarehouseId("warehouse");
        statementIDRequest.setWaitTimeout("30");
        when(dataLakeClient.getDataBricksResponse(statementIDRequest)).thenReturn(response);
        assertThrows(MatrixDataSyncException.class, ()-> dataLakeService.getPolicyDocuments(Set.of("POLNULL")));
    }

    @Test
    void testGetDataBricksResponse_whenStatusFailed_shouldThrow() {
        var response = new DataBricksResponse();
        var status = new DataBricksResponse.Status();
        status.setState("FAILED");
        response.setStatus(status);

        when(dataLakeClient.getDataBricksResponse(any())).thenReturn(response);
        assertThrows(MatrixDataSyncException.class, () -> {
            dataLakeService.getPolicyAndMemberDetails("some-policy-number");
        });

    }


    @Test
    void testGetUpdatedPmsData_statusFailed_shouldThrow() {
        String startTime = "2024-01-01T10:00:00";
        String endTime = "2024-01-01T11:00:00";

        when(envVariablesService.getValueByKey(WAREHOUSE_ID.name())).thenReturn("warehouse");
        when(envVariablesService.getValueByKey(WAIT_TIMEOUT.name())).thenReturn(String.valueOf(30));
        when(envVariablesService.getValueByKey(PMS_UPDATED_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");


        var response = new DataBricksResponse();
        var status = new DataBricksResponse.Status();
        status.setState("FAILED");
        response.setStatus(status);

        when(dataLakeClient.getDataBricksResponse(any())).thenReturn(response);

        assertThrows(MatrixDataSyncException.class, () -> {
            dataLakeService.getUpdatedPmsData(endTime, startTime);
        });
    }

    @Test
    void testGetUpdatedPmsData_resultNull_shouldThrow() {
        String startTime = "2024-01-01T10:00:00";
        String endTime = "2024-01-01T11:00:00";

        when(envVariablesService.getValueByKey(WAREHOUSE_ID.name())).thenReturn("warehouse");
        when(envVariablesService.getValueByKey(WAIT_TIMEOUT.name())).thenReturn(String.valueOf(30));
        when(envVariablesService.getValueByKey(PMS_UPDATED_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");


        var response = new DataBricksResponse();
        var status = new DataBricksResponse.Status();
        status.setState("SUCCEEDED");
        response.setStatus(status);
        response.setManifest(null);

        when(dataLakeClient.getDataBricksResponse(any())).thenReturn(response);

        assertThrows(MatrixDataSyncException.class, () -> {
            dataLakeService.getUpdatedPmsData(endTime, startTime);
        });
    }

    @Test
    void testGetUpdatedPmsData_dataArrayNull_shouldReturnEmpty() {
        String startTime = "2024-01-01T10:00:00";
        String endTime = "2024-01-01T11:00:00";

        when(envVariablesService.getValueByKey(WAREHOUSE_ID.name())).thenReturn("warehouse");
        when(envVariablesService.getValueByKey(WAIT_TIMEOUT.name())).thenReturn(String.valueOf(30));
        when(envVariablesService.getValueByKey(PMS_UPDATED_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");


        var result = new DataBricksResponse.Result();
        result.setDataArray(null);

        var status = new DataBricksResponse.Status();
        status.setState("SUCCEEDED");

        var response = new DataBricksResponse();
        response.setStatus(status);
        response.setManifest(new DataBricksResponse.Manifest());
        response.setResult(result);

        when(dataLakeClient.getDataBricksResponse(any())).thenReturn(response);

        var resultList = dataLakeService.getUpdatedPmsData(endTime, startTime);
        assertTrue(resultList.isEmpty());
    }
    @Test
    void testGetUpdatedMinimumPolicyDateData_successfullyParsesResponse() {
        String startIndex = "1", endIndex = "2";
        LocalDate date = LocalDate.of(2024, 1, 1);
        DataBricksResponse response = new DataBricksResponse();
        DataBricksResponse.Status status = new DataBricksResponse.Status();
        status.setState("SUCCEEDED");
        List<Object> row = Arrays.asList("POL123", "Retail", "OFC01", "PROD01", "2023-01-01", "2024-01-01",
                "John Doe", "600001", "POL2022", "ACTIVE", "500000", "[]");
        DataBricksResponse.Result result = new DataBricksResponse.Result();
        result.setDataArray(List.of(row));
        response.setStatus(status);
        response.setResult(result);
        response.setManifest(new DataBricksResponse.Manifest());
        when(envVariablesService.getValueByKey(WAREHOUSE_ID.name())).thenReturn("warehouse");
        when(envVariablesService.getValueByKey(WAIT_TIMEOUT.name())).thenReturn(String.valueOf(30));
        when(envVariablesService.getValueByKey(POLICY_UPDATED_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");

        when(dataLakeClient.getDataBricksResponse(any())).thenReturn(response);
        List<PolicyDataResponse> resultList = dataLakeService.getUpdatedMinimumPolicyDateData(startIndex, endIndex, date);

        assertEquals(1, resultList.size());
        assertEquals("POL123", resultList.get(0).getPolicyInfo().getPolicyNumber());
    }

    @Test
    void testGetUpdatedMinimumPolicyDateData_throwsExceptionOnFailedState() {
        String startIndex = "1", endIndex = "2";
        LocalDate date = LocalDate.of(2024, 1, 1);

        DataBricksResponse response = new DataBricksResponse();
        DataBricksResponse.Status status = new DataBricksResponse.Status();
        status.setState("FAILED");

        response.setStatus(status);

        when(envVariablesService.getValueByKey(WAREHOUSE_ID.name())).thenReturn("warehouse");
        when(envVariablesService.getValueByKey(WAIT_TIMEOUT.name())).thenReturn(String.valueOf(30));
        when(envVariablesService.getValueByKey(POLICY_UPDATED_QUERY.name())).thenReturn("select * from policy where number = '{policyNumber}'");

        when(dataLakeClient.getDataBricksResponse(any())).thenReturn(response);
        assertThrows(MatrixDataSyncException.class,
                () -> dataLakeService.getUpdatedMinimumPolicyDateData(startIndex, endIndex, date));
    }
}
