package com.star.matrix.impl;

import com.star.matrix.entity.EnvironmentVariables;
import com.star.matrix.repository.EnvironmentVariablesRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class EnvVariablesServiceImplTest {

    private EnvironmentVariablesRepository repository;
    private EnvVariablesServiceImpl envVariablesService;

    @BeforeEach
    void setUp() {
        repository = mock(EnvironmentVariablesRepository.class);
        when(repository.findAll()).thenReturn(List.of(
                createEnvVar("key1", "value1"),
                createEnvVar("intKey", "123"),
                createEnvVar("boolKey", "true"),
                createEnvVar("invalidInt", "abc"),
                createEnvVar("invalidBool", "notTrueOrFalse")
        ));

        envVariablesService = new EnvVariablesServiceImpl(repository); // calls refreshCache
    }

    private EnvironmentVariables createEnvVar(String key, String value) {
        EnvironmentVariables env = new EnvironmentVariables();
        env.setKey(key);
        env.setValue(value);
        return env;
    }

    @Test
    void testGet_existingKey() {
        assertEquals("value1", envVariablesService.get("key1"));
    }

    @Test
    void testGet_missingKey_returnsDefault() {
        assertEquals("default", envVariablesService.get("missing", "default"));
    }

    @Test
    void testGet_missingKey_returnsNull() {
        assertNull(envVariablesService.get("missing"));
    }

    @Test
    void testGetInt_valid() {
        assertEquals(123, envVariablesService.getInt("intKey", 0));
    }

    @Test
    void testGetInt_invalid_returnsDefault() {
        assertEquals(99, envVariablesService.getInt("invalidInt", 99));
    }

    @Test
    void testGetInt_missing_returnsDefault() {
        assertEquals(11, envVariablesService.getInt("missingInt", 11));
    }

    @Test
    void testGetBool_validTrue() {
        assertTrue(envVariablesService.getBool("boolKey", false));
    }

    @Test
    void testGetBool_invalid_returnsDefault() {
        assertFalse(envVariablesService.getBool("invalidBool", false));
    }


    @Test
    void testGetValueByKey_delegatesToGet() {
        assertEquals("value1", envVariablesService.getValueByKey("key1"));
    }

    @Test
    void testRefreshCache_loadsValuesFromRepository() {
        EnvironmentVariablesRepository newRepo = mock(EnvironmentVariablesRepository.class);
        when(newRepo.findAll()).thenReturn(List.of(createEnvVar("testKey", "testVal")));

        EnvVariablesServiceImpl newService = new EnvVariablesServiceImpl(newRepo);
        newService.refreshCache();

        assertEquals("testVal", newService.get("testKey"));
    }
}
