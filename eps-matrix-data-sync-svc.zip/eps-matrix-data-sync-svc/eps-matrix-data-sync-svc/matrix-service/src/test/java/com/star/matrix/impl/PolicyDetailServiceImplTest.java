package com.star.matrix.impl;

import com.star.matrix.DataLakeService;
import com.star.matrix.dto.common.*;
import com.star.matrix.dto.response.PolicyHistoryResponse;
import com.star.matrix.exception.MatrixDataSyncException;
import com.star.matrix.properties.ApplicationProperties;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.star.matrix.exception.MatrixErrorCode.FAILED_TO_FETCH_POLICY_CLAIM_HISTORY_DATA;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PolicyDetailServiceImplTest {


    @Mock
    private ApplicationProperties applicationProperties;

    @Mock
    private DataLakeService dataLakeService;

    @InjectMocks
    private PolicyDetailServiceImpl service;

    @Spy
    private ExecutorService executor = Executors.newFixedThreadPool(1); // real executor or mock

    private final String policyNumber = "POL123";

    @AfterEach
    void tearDown() {
        executor.shutdownNow();
    }

    private PolicyMemberDetailSummary createPolicyMemberDetailSummary(String policyNo) {
        PolicyMemberDetailSummary.Member member = new PolicyMemberDetailSummary.Member();
        member.setDob("1990-01-01");
        member.setPed("PED");
        member.setGender("M");
        member.setRelation("Self");
        member.setSumInsured("100000");
        member.setHealthId("H123");
        member.setInsuredName("John Doe");
        member.setEffectiveFrom("2020-01-01");
        member.setEffectiveTo("2021-01-01");
        member.setInsuredInceptionDate("2020-01-01");

        return getPolicyMemberDetailSummary(policyNo, member);
    }

    private static PolicyMemberDetailSummary getPolicyMemberDetailSummary(String policyNo, PolicyMemberDetailSummary.Member member) {
        PolicyMemberDetailSummary summary = new PolicyMemberDetailSummary();
        summary.setPolicyNo(policyNo);
        summary.setPolicyFromDate("2020-01-01");
        summary.setPolicyToDate("2021-01-01");
        summary.setUwYear("2020");
        summary.setSumInsured("100000");
        summary.setProductName("ProductX");
        summary.setPreviousPolicyNo("PREV123");
        summary.setPolicySource("SourceX");
        summary.setPolicyInceptionDate("2019-01-01");
        summary.setPolicyType("TypeA");
        summary.setMembers(List.of(member));
        return summary;
    }

    private PolicyDocumentSummary createPolicyDocumentSummary(String policyNo) {
        PolicyDocumentSummary.DocumentDetail doc = new PolicyDocumentSummary.DocumentDetail();
        doc.setDocumentType("Type1");
        doc.setDocumentName("Doc1");
        doc.setDocumentSource("Source1");
        doc.setProposalNo("Prop1");
        doc.setApiDocumentType("APIType");

        PolicyDocumentSummary summary = new PolicyDocumentSummary();
        summary.setPolicyNo(policyNo);
        summary.setDocumentDetails(List.of(doc));
        return summary;
    }

    private ClaimHistorySummary createClaimHistorySummary(String policyNo, String intimationNumber) {
        ClaimHistory history = new ClaimHistory();
        history.setPolicyNumber(policyNo);
        history.setClaimNumber("CLM001");
        history.setClaimStatus("Approved");
        history.setClaimType("TypeA");
        history.setPedName("PED1");
        history.setCataractDetails("None");
        history.setDiagnosis("DiagnosisX");
        history.setCopay("10%");
        history.setHealthId("H123");
        history.setPolicyYear("2021");
        history.setIntimationNumber(intimationNumber);
        history.setPatientName("PatientX");
        history.setApprovedAmount("5000");
        history.setHospitalName("HospitalX");
        history.setSublimitName("SublimitX");
        history.setSublimitAmount("1000");
        history.setIcdCode("ICD123");
        history.setSublimitCategory("CategoryA");
        history.setSiRestrictionFlag("N");

        ClaimHistorySummary summary = new ClaimHistorySummary();
        summary.setPolicyNumber(policyNo);
        summary.setClaimHistories(List.of(history));
        return summary;
    }

    private ClaimDocumentSummary createClaimDocumentSummary(String intimationNumber) {
        ClaimDocument doc = new ClaimDocument();
        doc.setDocumentName("DocName");
        doc.setDocumentToken("Token123");
        doc.setDocumentType("TypeDoc");
        doc.setDocumentSource("SourceDoc");
        doc.setIntimationNumber(intimationNumber);

        ClaimDocumentSummary summary = new ClaimDocumentSummary();
        summary.setIntimationNumber(intimationNumber);
        summary.setClaimDocuments(List.of(doc));
        return summary;
    }
    @Test
    void testGetPolicyHistoryDetails_success() {
        // Arrange
        String policyNumber = "P/161218/01/2021/004234";

        var pmdFuture = List.of(createPolicyMemberDetailSummary(policyNumber));
        var docsFuture = List.of(createPolicyDocumentSummary(policyNumber));
        var historyFuture = List.of(createClaimHistorySummary(policyNumber, "INT001"));
        var claimsFuture = List.of(createClaimDocumentSummary("INT001"));

        when(dataLakeService.getPolicyAndMemberDetails(eq(policyNumber))).thenReturn(pmdFuture);
        when(dataLakeService.getPolicyDocuments(anySet())).thenReturn(docsFuture);
        when(dataLakeService.getPolicyClaimHistory(anySet())).thenReturn(historyFuture);
        when(dataLakeService.getPolicyClaimDocuments(anySet())).thenReturn(claimsFuture);

        // Act
        var response = service.getPolicyHistoryDetails(policyNumber);

        // Assert
        assertNotNull(response);
        assertFalse(response.getPolicies().isEmpty());

        var policy = response.getPolicies().get(0);
        assertEquals(policyNumber, policy.getPolicyNo());
        assertFalse(policy.getMember().isEmpty());
        assertFalse(policy.getDocument().isEmpty());
        assertFalse(policy.getClaim().isEmpty());

        assertNotNull(policy.getClaim().getFirst().getDocuments());
        assertEquals("DocName", policy.getClaim().getFirst().getDocuments().getFirst().getDocumentName());
    }

    @Test
    void testGetPolicyHistoryDetails_dataLakeException_throwsMatrixDataSyncException() {
        when(dataLakeService.getPolicyAndMemberDetails(any())).thenThrow(new RuntimeException("DB error"));

        MatrixDataSyncException ex = assertThrows(MatrixDataSyncException.class,
                () -> service.getPolicyHistoryDetails(policyNumber));

        assertEquals(FAILED_TO_FETCH_POLICY_CLAIM_HISTORY_DATA, ex.getMatrixErrorCode());
    }

    @Test
    void testSanitizeResponse_emptyLists() {

        var combined = new PolicyClaimHistoryCombined(List.of(), List.of(), List.of(), List.of());

        var response = service.sanitizeResponse(combined);

        assertNotNull(response);
        assertTrue(response.getPolicies().isEmpty());
    }

    @Test
    void testAddPolicyMemberDetails_nullMembers_shouldThrowException() {
        var policyMemberDetailSummary = new PolicyMemberDetailSummary();
        policyMemberDetailSummary.setMembers(null);

        var policy = new PolicyHistoryResponse.Policy();

        assertThrows(NullPointerException.class, () ->
                PolicyDetailServiceImpl.addPolicyMemberDetails(policyMemberDetailSummary, policy)
        );
    }


    @Test
    void testAddPolicyDocuments_noMatchPolicyNumber() {
        var policyDocumentSummaries = List.of(createPolicyDocumentSummary("OTHER_POLICY"));
        var policy = new PolicyHistoryResponse.Policy();

        PolicyDetailServiceImpl.addPolicyDocuments(policyDocumentSummaries, policyNumber, policy);

        assertNull(policy.getDocument());
    }

    @Test
    void testAddPolicyClaimHistory_noMatchingPolicy() {
        var claimHistorySummaries = List.of(createClaimHistorySummary("OTHER_POLICY", "INT001"));
        var claimDocumentSummaries = List.of(createClaimDocumentSummary("INT001"));
        var policy = new PolicyHistoryResponse.Policy();

        PolicyDetailServiceImpl.addPolicyClaimHistory(claimHistorySummaries, claimDocumentSummaries, policyNumber, policy);

        assertNull(policy.getClaim());
    }
}
