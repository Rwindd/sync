package com.star.matrix.impl;

import com.star.matrix.client.MediAssistClient;
import com.star.matrix.dto.response.MatrixPmsResponse;
import com.star.matrix.dto.response.MatrixPolicyResponse;
import com.star.matrix.entity.HospitalPayload;
import com.star.matrix.entity.PolicyFailedPayload;
import com.star.matrix.entity.PolicyPayload;
import com.star.matrix.enumeration.RequestStatus;
import com.star.matrix.properties.ApplicationProperties;
import com.star.matrix.repository.HospitalFailedPayloadRepository;
import com.star.matrix.repository.HospitalPayloadRepository;
import com.star.matrix.repository.PolicyFailedPayloadRepository;
import com.star.matrix.repository.PolicyPayloadRepository;
import com.star.matrix.util.ObjectMapperUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static com.star.matrix.constant.EnvVariableConstant.MATRIX_MAX_RETRY_COUNT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

class MatrixServiceImplTest {

	@Mock
	private HospitalPayloadRepository hospitalPayloadRepository;

	@Mock
	private PolicyPayloadRepository policyPayloadRepository;

	@Mock
	private PolicyFailedPayloadRepository policyFailedPayloadRepository;

	@Mock
	private HospitalFailedPayloadRepository hospitalFailedPayloadRepository;

	@Mock
	private MediAssistClient mediAssistClient;

	@Mock
	private ApplicationProperties applicationProperties;

	@Mock
	private EnvVariablesServiceImpl envVariablesService;

	@InjectMocks
	private MatrixServiceImpl matrixService;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
	}

	// Helper: create HospitalPayload with retry count
	private HospitalPayload createHospitalPayload(int retryCount) {
		HospitalPayload hp = new HospitalPayload();
		hp.setRetryCount(retryCount);
		hp.setHospitalID("HOSP1");
		hp.setMatrixHospitalPayload(null);
		return hp;
	}

	// Helper: create PolicyPayload with retry count
	private PolicyPayload createPolicyPayload(int retryCount) {
		PolicyPayload pp = new PolicyPayload();
		pp.setRetryCount(retryCount);
		pp.setPolicyNumber("POL123");
		pp.setPayload(null);
		return pp;
	}

	@Test
	void testHandleHospitalResponse_success() {
		HospitalPayload hp = createHospitalPayload(0);
		MatrixPmsResponse resp = new MatrixPmsResponse();
		resp.setIsSuccess(true);

		when(mediAssistClient.hospitalPush(any())).thenReturn(resp);
		when(hospitalPayloadRepository.save(any())).thenReturn(hp);

		matrixService.handleHospitalResponse(hp);

		assertThat(hp.getStatus()).isEqualTo(RequestStatus.SUCCESS);
		verify(hospitalPayloadRepository).save(hp);
		verify(hospitalFailedPayloadRepository, never()).save(any());
	}

	@Test
	void testHandleHospitalResponse_failure_incrementRetry() {
		HospitalPayload hp = createHospitalPayload(1);
		MatrixPmsResponse resp = new MatrixPmsResponse();
		resp.setIsSuccess(false);

		when(mediAssistClient.hospitalPush(ObjectMapperUtil.convertObjectToJson(hp.getMatrixHospitalPayload()))).thenReturn(resp);
		when(envVariablesService.getInt(MATRIX_MAX_RETRY_COUNT.name(), 3)).thenReturn(3);

		when(hospitalPayloadRepository.save(any())).thenReturn(hp);

		matrixService.handleHospitalResponse(hp);

		assertThat(hp.getRetryCount()).isEqualTo(2);
		assertThat(hp.getStatus()).isNull();
		verify(hospitalFailedPayloadRepository, never()).save(any());
		verify(hospitalPayloadRepository).save(hp);
	}

	@Test
	void testHandleHospitalResponse_failure_maxRetryReached() {
		int maxRetry = 2;
		HospitalPayload hp = createHospitalPayload(1);
		MatrixPmsResponse resp = new MatrixPmsResponse();
		resp.setIsSuccess(false);

		when(mediAssistClient.hospitalPush(ObjectMapperUtil.convertObjectToJson(hp.getMatrixHospitalPayload()))).thenReturn(resp);
		when(envVariablesService.getInt(MATRIX_MAX_RETRY_COUNT.name(), 3)).thenReturn(2);
		when(hospitalFailedPayloadRepository.save(any())).thenAnswer(i -> i.getArgument(0));
		when(hospitalPayloadRepository.save(any())).thenReturn(hp);

		matrixService.handleHospitalResponse(hp);

		assertThat(hp.getRetryCount()).isEqualTo(maxRetry);
		assertThat(hp.getStatus()).isEqualTo(RequestStatus.FAILED);
		verify(hospitalFailedPayloadRepository)
				.save(argThat(failedPayload -> failedPayload.getHospitalID().equals(hp.getHospitalID())
						&& failedPayload.getPayload() == hp.getMatrixHospitalPayload()));
		verify(hospitalPayloadRepository).save(hp);
	}

	@Test
	void testHandlePolicyResponse_responseNotSuccess() {
		PolicyPayload pp = createPolicyPayload(0);
		MatrixPolicyResponse resp = new MatrixPolicyResponse();

		when(mediAssistClient.policyPush(any())).thenReturn(resp);

		matrixService.handlePolicyResponse(pp);

		verify(policyFailedPayloadRepository, times(1)).save(any());
		verify(policyPayloadRepository).save(pp);
	}

	@Test
	void testHandlePolicyResponse_ResponseIsNull() {
		PolicyPayload pp = createPolicyPayload(2);
		when(mediAssistClient.policyPush(pp.getPayload())).thenReturn(null);
		when(envVariablesService.getInt(MATRIX_MAX_RETRY_COUNT.name(), 3)).thenReturn(3);
		when(policyPayloadRepository.save(any())).thenReturn(pp);
		matrixService.handlePolicyResponse(pp);

		assertEquals(3, pp.getRetryCount());
		assertEquals(RequestStatus.FAILED, pp.getStatus());
		verify(policyFailedPayloadRepository).save(any(PolicyFailedPayload.class));
		verify(policyPayloadRepository).save(pp);
	}

	@Test
	void testHandlePolicyResponse_failure_incrementRetry() {

		PolicyPayload pp = createPolicyPayload(1);
		MatrixPolicyResponse resp = new MatrixPolicyResponse();
		resp.setIsSuccess(false);

		when(mediAssistClient.policyPush(pp.getPayload())).thenReturn(resp);
		when(envVariablesService.getInt(MATRIX_MAX_RETRY_COUNT.name(), 3)).thenReturn(3);
		when(policyPayloadRepository.save(any())).thenReturn(pp);

		matrixService.handlePolicyResponse(pp);

		assertThat(pp.getRetryCount()).isEqualTo(2);
		assertThat(pp.getStatus()).isNull();
		verify(policyFailedPayloadRepository, never()).save(any());
		verify(policyPayloadRepository).save(pp);
	}

	@Test
	void testHandlePolicyResponse_failure_maxRetryReached() {
		int maxRetry = 3;
		PolicyPayload pp = createPolicyPayload(2);
		MatrixPolicyResponse resp = new MatrixPolicyResponse();
		resp.setIsSuccess(false);

		when(mediAssistClient.policyPush(pp.getPayload())).thenReturn(resp);
		when(envVariablesService.getInt(MATRIX_MAX_RETRY_COUNT.name(), 3)).thenReturn(3);
		when(policyFailedPayloadRepository.save(any())).thenAnswer(i -> i.getArgument(0));
		when(policyPayloadRepository.save(any())).thenReturn(pp);

		matrixService.handlePolicyResponse(pp);

		assertThat(pp.getRetryCount()).isEqualTo(maxRetry);
		assertThat(pp.getStatus()).isEqualTo(RequestStatus.FAILED);

		verify(policyFailedPayloadRepository)
				.save(argThat(failedPayload -> failedPayload.getPolicyNumber().equals(pp.getPolicyNumber())
						&& failedPayload.getPayload() == pp.getPayload()));
		verify(policyPayloadRepository).save(pp);
	}
	
	@Test
	void testHandleHospitalResponse_MatrixPmsResponseNull() {
		HospitalPayload hp = createHospitalPayload(0);

		when(mediAssistClient.hospitalPush(any())).thenReturn(null);

		matrixService.handleHospitalResponse(hp);

		verify(hospitalPayloadRepository).save(hp);
		verify(hospitalFailedPayloadRepository, times(1)).save(any());
	}
	
	@Test
	void testHandleHospitalResponse_failure() {
		HospitalPayload hp = createHospitalPayload(0);
		MatrixPmsResponse resp = new MatrixPmsResponse();
		resp.setIsSuccess(false);

		when(mediAssistClient.hospitalPush(any())).thenReturn(resp);

		matrixService.handleHospitalResponse(hp);

		verify(hospitalPayloadRepository).save(hp);
		verify(hospitalFailedPayloadRepository, times(1)).save(any());
	}
	
	@Test
	void testHandlePolicyResponse_success() {
		PolicyPayload pp = createPolicyPayload(0);
		MatrixPolicyResponse resp = new MatrixPolicyResponse();
		resp.setIsSuccess(true);

		when(mediAssistClient.policyPush(any())).thenReturn(resp);
		when(policyPayloadRepository.save(any())).thenReturn(pp);

		matrixService.handlePolicyResponse(pp);

		assertThat(pp.getStatus()).isEqualTo(RequestStatus.SUCCESS);
		verify(policyFailedPayloadRepository, never()).save(any());
		verify(policyPayloadRepository).save(pp);
	}
}