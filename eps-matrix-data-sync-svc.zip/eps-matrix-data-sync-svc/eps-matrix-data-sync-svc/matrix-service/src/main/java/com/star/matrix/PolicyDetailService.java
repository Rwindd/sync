package com.star.matrix;

import com.star.matrix.dto.response.PolicyHistoryResponse;

public interface PolicyDetailService {

    PolicyHistoryResponse getPolicyHistoryDetails(String policyNumber);
}
