package com.star.matrix.impl;

import com.star.matrix.EnvVariablesService;
import com.star.matrix.dto.request.EnvVariableDeleteRequestDto;
import com.star.matrix.dto.request.EnvironmentVariablesRequestDto;
import com.star.matrix.dto.response.EnvVariablesResponse;
import com.star.matrix.entity.EnvironmentVariables;
import com.star.matrix.exception.MatrixDataSyncException;
import com.star.matrix.repository.EnvironmentVariablesRepository;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

import static com.star.matrix.exception.MatrixErrorCode.ENVIRONMENT_VARIABLES_ALREADY_EXISTS_FOR_GIVEN_KEY;
import static com.star.matrix.exception.MatrixErrorCode.NO_ENVIRONMENT_VARIABLES_FOUND_FOR_GIVEN_KEY;

@Slf4j
@Service
public class EnvVariablesServiceImpl implements EnvVariablesService {

    private final EnvironmentVariablesRepository environmentVariablesRepository;
    private final Map<String, String> cache = new ConcurrentHashMap<>();

    public EnvVariablesServiceImpl(EnvironmentVariablesRepository repository) {
        this.environmentVariablesRepository = repository;
        refreshCache();
    }

    @PostConstruct
    @Override
    public void refreshCache() {
        environmentVariablesRepository.findAll().forEach(cfg ->
                cache.put(cfg.getKey(), cfg.getValue())
        );
    }

    public String get(String key, String defaultVal) {
        return cache.getOrDefault(key, defaultVal);
    }

    public String get(String key) {
        return get(key, null);
    }

    @Override
    public Integer getInt(String key, Integer defaultVal) {
        try {
            return Integer.valueOf(get(key));
        } catch (Exception e) {
            return defaultVal;
        }
    }

    @Override
    public Long getLong(String key, long defaultVal) {
        try {
            return Long.valueOf(get(key));
        } catch (Exception e) {
            return defaultVal;
        }
    }

    @Override
    public boolean getBool(String key, boolean defaultVal) {
        try {
            return Boolean.parseBoolean(get(key));
        } catch (Exception e) {
            return defaultVal;
        }
    }

    @Override
    public String getValueByKey(String key) {
        var value = get(key);
        log.info("Value received from cache : {} for key : {}", value, key);
        return value;
    }

    @Override
    public List<EnvVariablesResponse> getEnvironmentVariables(String key) {
        if (Objects.isNull(key)) {
            return environmentVariablesRepository.findAll().stream().map(env ->
                    EnvVariablesResponse.builder()
                            .key(env.getKey())
                            .value(env.getValue()).build()).toList();
        }
        return environmentVariablesRepository.findByKey(key)
                .map(env -> EnvVariablesResponse.builder()
                        .key(env.getKey())
                        .value(env.getValue()).build())
                .map(List::of).orElse(new ArrayList<>());

    }

    @Override
    public String updateEnvironmentVariables(String key, boolean delete, EnvironmentVariablesRequestDto environmentVariablesRequestDto) {
        EnvironmentVariables env = environmentVariablesRepository.findByKey(key)
                .orElseThrow(() -> new MatrixDataSyncException(NO_ENVIRONMENT_VARIABLES_FOUND_FOR_GIVEN_KEY));
        if (delete) {
            environmentVariablesRepository.delete(env);
            refreshCache();
            return "DELETE_MESSAGE";
        } else {
            env.setValue(environmentVariablesRequestDto.getValue());
            env.setKey(environmentVariablesRequestDto.getKey());
            environmentVariablesRepository.save(env);
            refreshCache();
            return "UPDATE_MESSAGE";
        }
    }

    @Override
    public String createEnvironmentVariables(EnvironmentVariablesRequestDto environmentVariablesRequestDto) {
        if (environmentVariablesRepository.findByKey(environmentVariablesRequestDto.getKey()).isPresent())
            throw new MatrixDataSyncException(ENVIRONMENT_VARIABLES_ALREADY_EXISTS_FOR_GIVEN_KEY);
        EnvironmentVariables environmentVariables = new EnvironmentVariables();
        environmentVariables.setKey(environmentVariablesRequestDto.getKey());
        environmentVariables.setValue(environmentVariablesRequestDto.getValue());
        environmentVariablesRepository.save(environmentVariables);
        return "CREATE_MESSAGE";
    }

    @Override
    public String deleteEnvironmentVariables(EnvVariableDeleteRequestDto deleteRequestDto) {
        log.info("deleteEnvironmentVariables for ids :- {}", deleteRequestDto.getId());
        List<String> idList = deleteRequestDto.getId();
        for (String id : idList) {
            environmentVariablesRepository.deleteById(id);
            log.info("deleteEnvironmentVariables for id :- {}", id);
        }
        return "ENVIRONMENT VARIABLE DELETED SUCCESSFULLY";
    }

}
