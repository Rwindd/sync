package com.star.matrix;

import com.star.matrix.dto.request.OneTimeBatchRemoveRequest;
import com.star.matrix.dto.request.OneTimeBatchUpdateRequest;
import com.star.matrix.dto.request.OneTimeGroupBatchUpdateRequest;

import java.time.LocalDate;
import java.time.LocalDateTime;

public interface DataSyncService {

    void processPmsDataFromDataLake();

    void processPmsDataFromDataLake(LocalDateTime fromTime, LocalDateTime toTime);

    void processMinimumPolicyDataFromDataLake();

    void processMinimumPolicyDataFromDataLake(LocalDate reportedDate, boolean manual);

    void processOneTimeMinimumPolicyDataToMatrix(OneTimeBatchUpdateRequest command);

    void processOneTimeMinimumPolicyDataRemovalToMatrix(OneTimeBatchRemoveRequest command);

    void processMinimumPolicyDataToMatrix();

    void processMinimumPolicyDataToMatrix(long startDateEpoch, long endDateEpoch, int batchSize);

    void processPmsDataToMatrix();

    void processPmsDataToMatrix(long startDateEpoch, long endDateEpoch, int batchSize);

    void processRenewQuoteDataFromDataLake();

    void processRenewQuoteDataFromDataLake(LocalDate reportedDate);

    void processRenewQuoteDataToZoho();

    void processRenewQuoteDataToZoho(long startDateEpoch, long endDateEpoch, int batchSize);

    void processRetryableZohoRenewalToMatrix();

    void processMinimumGroupPolicyDataFromDataLake();

    void processMinimumGroupPolicyDataFromDataLake(LocalDate reportedDate, boolean manual);

    void processRetryableGroupPolicyToMatrix();

    void processOneTimeMinimumGroupPolicyDataToMatrix(OneTimeGroupBatchUpdateRequest command);

    void processOneTimeMinimumGroupPolicyDataRemovalToMatrix(OneTimeBatchRemoveRequest command);

}
