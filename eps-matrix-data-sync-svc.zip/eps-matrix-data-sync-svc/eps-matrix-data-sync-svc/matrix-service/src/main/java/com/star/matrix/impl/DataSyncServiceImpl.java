package com.star.matrix.impl;

import com.star.matrix.*;
import com.star.matrix.dto.GroupPolicyData;
import com.star.matrix.dto.HospitalDetail;
import com.star.matrix.dto.PolicyDataResponse;
import com.star.matrix.dto.request.*;
import com.star.matrix.dto.zoho.RenewalQuoteEncrypt;
import com.star.matrix.entity.*;
import com.star.matrix.entity.grouppolicy.*;

import com.star.matrix.entity.grouppolicy.GroupPolicyPayload;
import com.star.matrix.entity.zoho.RenewQuoteBatchProgress;
import com.star.matrix.entity.zoho.RenewQuoteBatchStatus;
import com.star.matrix.entity.zoho.RenewQuotePayload;
import com.star.matrix.entity.zoho.RenewQuoteBatchDetail;
import com.star.matrix.enumeration.RequestStatus;
import com.star.matrix.exception.MatrixDataSyncException;
import com.star.matrix.properties.ApplicationProperties;
import com.star.matrix.repository.*;
import com.star.matrix.util.*;
import io.micrometer.tracing.Tracer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import static com.star.matrix.constant.EnvVariableConstant.*;
import static com.star.matrix.exception.MatrixErrorCode.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class DataSyncServiceImpl implements DataSyncService {

    public static final String START = "START";
    public static final String STOP = "STOP";
    public static final String STOP_RESTART = "STOP_RESTART";
    public static final String RETRY = "RETRY";
    private final DataLakeService dataLakeService;
    private final HospitalPayloadRepository hospitalPayloadRepository;
    private final PolicyBatchProgressRepository policyBatchProgressRepository;
    private final PolicyOneTimeBatchProgressRepository oneTimeBatchProgressRepository;
    private final GroupPolicyOneTimeBatchProgressRepository oneTimeGroupPolicyBatchProgressRepository;
    private final PolicyOneTimeBatchProgressCustomRepository oneTimeBatchProgressCustomRepository;
    private final GroupPolicyOneTimeBatchProgressCustomRepository oneTimeGroupPolicyBatchProgressCustomRepository;
    private final PmsBatchProgressRepository pmsBatchProgressRepository;
    private final PolicyPayloadRepository policyPayloadRepository;
    private final MatrixService matrixService;
    private final OneTimePolicyStatusRepository oneTimePolicyStatusRepository;
    private final EnvVariablesService envVariablesService;
    private final Tracer tracer;
    private final TracingUtils tracingUtils;
    private final PolicyBatchDetailRepository policyBatchDetailRepository;
    private final RenewQuoteBatchProgressRepository renewQuoteBatchProgressRepository;
    private final RenewQuotePayloadRepository renewQuotePayloadRepository;
    private final RenewQuoteBatchDetailRepository renewQuoteBatchDetailRepository;
    private final ZohoService zohoService;
    private final GroupPolicyBatchDetailRepository groupPolicyBatchDetailRepository;
    private final GroupPolicyBatchProgressRepository groupPolicyBatchProgressRepository;
    private final GroupPolicyPayloadRepository groupPolicyPayloadRepository;
    private final KafkaEventPublisherUtil kafkaEventPublisherUtil;
    private final ApplicationProperties applicationProperties;
    private final OneTimeGroupPolicyStatusRepository oneTimeGroupPolicyStatusRepository;
    private final GroupPolicyOneTimeBatchProgressRepository groupPolicyOneTimeBatchProgressRepository;

    @Override
    public void processPmsDataFromDataLake() {
        log.info("PMS data fetch scheduler started at {}", LocalDateTime.now());
        var endTime = LocalDateTime.now().withMinute(0).withSecond(0).withNano(0);
        var startTime = endTime.minusHours(envVariablesService.getInt(PMS_DL_FETCH_RANGE_IN_HOUR.name(), 1));
        Optional<PmsBatchProgress> progressOptional = pmsBatchProgressRepository.findFirstByOrderByToTimeDesc();
        if (progressOptional.isPresent()) {
            startTime = progressOptional.get().getToTime();
        }
        processPmsDataFromDataLake(startTime, endTime);
    }

    @Override
    public void processPmsDataFromDataLake(LocalDateTime fromTime, LocalDateTime toTime) {
        log.info("PMS data fetch scheduler started at {}", LocalDateTime.now());
        PmsBatchProgress progress = createInitialPmsBatchProgress(fromTime, toTime);
        List<MatrixHospitalPayload> responses = fetchPmsData(fromTime, toTime);
        updateProgressStatus(progress, responses);
        pmsBatchProgressRepository.save(progress);
    }

    @Override
    public void processMinimumPolicyDataFromDataLake() {
        log.info("Policy data fetch scheduler started at {}", LocalDateTime.now());
        LocalDate reportedDate = LocalDate.now().minusDays(envVariablesService.getInt(POLICY_FETCH_MINUS_NO_OF_DAYS.name(), 1));
        processMinimumPolicyDataFromDataLake(reportedDate, false);
    }

    @Override
    public void processMinimumPolicyDataFromDataLake(LocalDate reportedDate, boolean manual) {
        int fromIndex = 1;
        if (!manual) {
            boolean isPolicyBatchCompleted = policyBatchDetailRepository.findFirstByDateOrderByCreatedAtDesc(reportedDate.atStartOfDay())
                    .map(detail -> PolicyBatchStatus.COMPLETED == detail.getPolicyBatchStatus()).orElse(false);
            if (isPolicyBatchCompleted) {
                log.info("policyBatchStatus is already COMPLETED for date : {}", reportedDate.atStartOfDay());
                return;
            }
        }
        Optional<PolicyBatchProgress> latestProgress = getLatestEndIndex(reportedDate);
        if (latestProgress.isPresent()) {
            var previous = latestProgress.get();
            if (previous.getStatus() == BatchStatus.NO_DATA) {
                if (!manual) {
                    log.info("Previous batch had NO_DATA status for {}", reportedDate);
                    policyBatchDetailRepository.findFirstByDateOrderByCreatedAtDesc(reportedDate.atStartOfDay())
                            .ifPresentOrElse(detail -> {
                                detail.setPolicyBatchStatus(PolicyBatchStatus.COMPLETED);
                                log.info("policyBatchStatus is marked as COMPLETED for date : {}", reportedDate.atStartOfDay());
                            }, () -> {
                                var policyBatchDetail = new PolicyBatchDetail();
                                policyBatchDetail.setDate(reportedDate.atStartOfDay());
                                policyBatchDetail.setPolicyBatchStatus(PolicyBatchStatus.COMPLETED);
                                policyBatchDetailRepository.save(policyBatchDetail);
                            });
                    return;
                } else {
                    fromIndex = previous.getStartIndex();
                }
            } else {
                fromIndex = previous.getEndIndex() + 1;
            }
        }
        int toIndex = fromIndex + envVariablesService.getInt(POLICY_FETCH_BATCH_SIZE.name(), 500);
        PolicyBatchProgress finalProgressData;
        finalProgressData = createInitialBatchProgress(reportedDate, fromIndex, toIndex);
        List<PolicyDataResponse> responses = fetchPolicyData(fromIndex, toIndex, reportedDate);
        updateProgressStatus(finalProgressData, responses);
        policyBatchProgressRepository.save(finalProgressData);
        //dataLakeService.closeDataLakeConnection();
    }

    @Override
    @Async
    public void processOneTimeMinimumPolicyDataToMatrix(OneTimeBatchUpdateRequest request) {
        Optional<OneTimePolicyStatus> data = oneTimePolicyStatusRepository.findFirstByOrderByCreatedAtDesc();
        if (STOP.equalsIgnoreCase(request.getCommand())) {
            log.info("stopping one time data sync");
            data.ifPresent(this::stopPolicySync);
            return;
        } else if (STOP_RESTART.equalsIgnoreCase(request.getCommand())) {
            validateOrInitializeBatchStatus();
            data.ifPresent(this::stopRetryPolicySync);
        } else if (START.equalsIgnoreCase(request.getCommand())) {
            log.info("starting one time data sync");
            data = startPolicySync(data);
            int fromIndex = determineStartingIndex();
            BatchStatus finalStatus = processBatches(fromIndex);
            updateFinalSyncStatus(data, finalStatus);
        } else if (RETRY.equalsIgnoreCase(request.getCommand())) {
            log.info("retry one time data sync");
            int fromIndex = request.getFromIndex();
            int endIndex = request.getEndIndex();
            startBulkPolicyRetry(data);
            retryBatches(fromIndex, endIndex, request);
        }
        //dataLakeService.closeDataLakeConnection();
    }

    @Override
    public void processOneTimeMinimumPolicyDataRemovalToMatrix(OneTimeBatchRemoveRequest request) {
        if (request.isRemoveProgressCollection()) {
            oneTimeBatchProgressRepository.deleteAll();
        }
        if (request.isRemoveStatusCollection()) {
            oneTimePolicyStatusRepository.deleteAll();
        }
    }

    private void retryBatches(int fromIndex, int endIndex, OneTimeBatchUpdateRequest request) {
        AtomicBoolean hasMore = new AtomicBoolean(true);
        int batchSize = envVariablesService.getInt(ONE_TIME_POLICY_RETRY_MONGO_BATCH_SIZE.name(), 10);
        AtomicInteger page = new AtomicInteger();
        while (hasMore.get()) {
            ensureSyncNotRetryStopped();
            var batchProgressList = oneTimeBatchProgressCustomRepository.getOneTimePolicyBatchProgress(fromIndex, endIndex,
                    batchSize, page.get(), request.getStatuses(), request.isMatrixSuccess());
            if (batchProgressList.isEmpty()) {
                return;
            }
            for (var batchProgress : batchProgressList) {
                tracingUtils.runWithSpanRunnable("process-failed-policy", () -> {
                    var responses = fetchOneTimePolicyData(batchProgress.getStartIndex(), batchProgress.getEndIndex());
                    updateProgressStatus(batchProgress, responses);
                    if (responses != null && !responses.isEmpty()) {
                        boolean isSuccess = matrixService.pushBulkPolicy(getPolicyPayloads(responses));
                        batchProgress.setMatrixSuccess(isSuccess);
                    }
                    batchProgress.setTraceId(tracer.currentSpan().context().traceId());
                    batchProgress.setRetries(batchProgress.getRetries() + 1);
                    oneTimeBatchProgressRepository.save(batchProgress);
                });
            }
            hasMore.set(batchProgressList.size() == batchSize);
            page.getAndIncrement();
        }
    }

    private void retryGroupPolicyBatches(int fromIndex, int endIndex, OneTimeGroupBatchUpdateRequest request) {
        AtomicBoolean hasMore = new AtomicBoolean(true);
        int batchSize = envVariablesService.getInt(ONE_TIME_GROUP_POLICY_RETRY_MONGO_BATCH_SIZE.name(), 10);
        AtomicInteger page = new AtomicInteger();
        while (hasMore.get()) {
            ensureGroupSyncNotRetryStopped();
            var batchProgressList = oneTimeGroupPolicyBatchProgressCustomRepository.getOneTimeGroupPolicyBatchProgress(fromIndex, endIndex,
                    batchSize, page.get(), request.getStatuses(), request.isMatrixSuccess());
            if (batchProgressList.isEmpty()) {
                return;
            }
            for (var batchProgress : batchProgressList) {
                tracingUtils.runWithSpanRunnable("process-failed-group-policy", () -> {
                    var responses = fetchOneTimeGroupPolicyData(batchProgress.getStartIndex(), batchProgress.getEndIndex());
                    updateGroupPolicyProgressStatus(batchProgress, responses);
                    if (responses != null && !responses.isEmpty()) {
                        boolean isSuccess = matrixService.pushBulkGroupPolicy(responses);
                        batchProgress.setMatrixSuccess(isSuccess);
                    }
                    batchProgress.setTraceId(tracer.currentSpan().context().traceId());
                    batchProgress.setRetries(batchProgress.getRetries() + 1);
                    oneTimeGroupPolicyBatchProgressRepository.save(batchProgress);
                });
            }
            hasMore.set(batchProgressList.size() == batchSize);
            page.getAndIncrement();
        }
    }

    private void ensureGroupSyncNotRetryStopped() {
        var currentStatus = oneTimeGroupPolicyStatusRepository.findFirstByOrderByCreatedAtDesc();
        if (currentStatus.isPresent() && OneTimeStatus.RETRY_STOPPED == currentStatus.get().getStatus()) {
            throw new MatrixDataSyncException(ONE_TIME_GROUP_POLICY_SYNC_STOPPED);
        }
    }

    private void updateGroupPolicyProgressStatus(OneTimeGroupPolicyBatchProgress batchProgress, List<GroupPolicyData> responses) {
        if (responses == null) {
            batchProgress.setStatus(BatchStatus.FAILED);
        } else if (responses.isEmpty()) {
            batchProgress.setStatus(BatchStatus.NO_DATA);
        } else {
            batchProgress.setEndIndex(batchProgress.getStartIndex() + responses.size() - 1);
            batchProgress.setStatus(BatchStatus.COMPLETED);
        }
    }

    private void startBulkPolicyRetry(Optional<OneTimePolicyStatus> data) {
        if (data.isPresent()) {
            log.info("one time data sync already present");
            if (data.get().getStatus() == OneTimeStatus.IN_PROGRESS) {
                throw new MatrixDataSyncException(ONE_TIME_POLICY_SYNC_ALREADY_IN_PROGRESS);
            }
            data.get().setStatus(OneTimeStatus.RETRY_INITIATED);
            var status = oneTimePolicyStatusRepository.save(data.get());
            log.info("one time data sync updated : {}", status);
            return;
        }
        throw new MatrixDataSyncException(ONE_TIME_POLICY_SYNC_STATUS_NOT_FOUND);
    }

    private Optional<OneTimePolicyStatus> startPolicySync(Optional<OneTimePolicyStatus> data) {
        if (data.isPresent()) {
            log.info("one time data sync already present");
            if (data.get().getStatus() == OneTimeStatus.IN_PROGRESS) {
                throw new MatrixDataSyncException(ONE_TIME_POLICY_SYNC_ALREADY_IN_PROGRESS);
            }
            data.get().setStatus(OneTimeStatus.IN_PROGRESS);
            var status = oneTimePolicyStatusRepository.save(data.get());
            log.info("one time data sync updated : {}", status);
        } else {
            log.info("creating new data sync status entry");
            OneTimePolicyStatus newStatus = new OneTimePolicyStatus();
            newStatus.setStatus(OneTimeStatus.IN_PROGRESS);
            var status = oneTimePolicyStatusRepository.save(newStatus);
            log.info("nwe data sync status entry created: {}", status);
            data = Optional.of(newStatus);
        }
        return data;
    }

    private void stopPolicySync(OneTimePolicyStatus data) {
        data.setStatus(OneTimeStatus.STOPPED);
        oneTimePolicyStatusRepository.save(data);
    }

    private void stopRetryPolicySync(OneTimePolicyStatus data) {
        data.setStatus(OneTimeStatus.RETRY_STOPPED);
        oneTimePolicyStatusRepository.save(data);
    }

    private BatchStatus processBatches(int fromIndex) {
        AtomicLong atomicFromIndex = new AtomicLong(fromIndex);
        while (true) {
            var response = tracingUtils.runWithSpanSupplier("process-policy", () -> {
                ensureSyncNotStopped();
                long toIndex = calculateToIndex(atomicFromIndex.get());
                OneTimePolicyBatchProgress progress = createInitialOneTimeBatchProgress(atomicFromIndex.get(), toIndex);
                log.info("Start and end index {} {}", atomicFromIndex.get(), toIndex);
                var responses = fetchOneTimePolicyData(atomicFromIndex.get(), toIndex);
                updateProgressStatus(progress, responses);
                if (responses != null && !responses.isEmpty()) {
                    boolean isSuccess = matrixService.pushBulkPolicy(getPolicyPayloads(responses));
                    progress.setMatrixSuccess(isSuccess);
                }
                progress.setTraceId(tracer.currentSpan().context().traceId());
                oneTimeBatchProgressRepository.save(progress);
                return progress;
            });
            if (isProcessingComplete(response)) {
                return response.getStatus();
            }
            atomicFromIndex.set(response.getEndIndex() + 1);
        }
    }

    private void ensureSyncNotStopped() {
        var currentStatus = oneTimePolicyStatusRepository.findFirstByOrderByCreatedAtDesc();
        if (currentStatus.isPresent() && OneTimeStatus.STOPPED == currentStatus.get().getStatus()) {
            throw new MatrixDataSyncException(ONE_TIME_POLICY_SYNC_STOPPED);
        }
    }

    private void ensureSyncNotRetryStopped() {
        var currentStatus = oneTimePolicyStatusRepository.findFirstByOrderByCreatedAtDesc();
        if (currentStatus.isPresent() && OneTimeStatus.RETRY_STOPPED == currentStatus.get().getStatus()) {
            throw new MatrixDataSyncException(ONE_TIME_POLICY_SYNC_STOPPED);
        }
    }

    private void updateFinalSyncStatus(Optional<OneTimePolicyStatus> data, BatchStatus status) {
        if (data.isPresent()) {
            if (status == BatchStatus.NO_DATA) {
                data.get().setStatus(OneTimeStatus.COMPLETED);
            } else if (status == BatchStatus.FAILED) {
                data.get().setStatus(OneTimeStatus.FAILED);
            }
            oneTimePolicyStatusRepository.save(data.get());
        }
    }

    private void validateOrInitializeBatchStatus() {
        Optional<OneTimePolicyStatus> statusOpt = oneTimePolicyStatusRepository.findFirstByOrderByCreatedAtDesc();
        if (statusOpt.isPresent()) {
            if (OneTimeStatus.IN_PROGRESS == statusOpt.get().getStatus()) {
                throw new MatrixDataSyncException(ONE_TIME_BATCH_ALREADY_IN_PROGRESS);
            }
        } else {
            OneTimePolicyStatus entity = new OneTimePolicyStatus();
            entity.setStatus(OneTimeStatus.IN_PROGRESS);
            oneTimePolicyStatusRepository.save(entity);
        }
    }

    private int determineStartingIndex() {
        return oneTimeBatchProgressRepository.findFirstByOrderByCreatedAtDesc().map(progress -> {
            if (progress.getStatus() == BatchStatus.NO_DATA) {
                log.info("Previous batch had NO_DATA status");
                return progress.getStartIndex();
            } else {
                return progress.getEndIndex() + 1;
            }
        }).orElse(1);
    }

    private long calculateToIndex(long fromIndex) {
        long batchSize = envVariablesService.getLong(ONE_TIME_POLICY_MONGO_BATCH_SIZE.name(), 200L);
        return fromIndex + batchSize - 1;
    }

    private boolean isProcessingComplete(OneTimePolicyBatchProgress progress) {
        BatchStatus status = progress.getStatus();
        return status == BatchStatus.NO_DATA;
    }

    @Override
    public void processMinimumPolicyDataToMatrix() {
        Pageable pageable = PageRequest.of(0, envVariablesService.getInt(POLICY_MONGO_BATCH_SIZE.name(), 100));
        List<PolicyPayload> results = policyPayloadRepository.findByStatusOrderByCreatedAtAsc(RequestStatus.INITIATED, pageable);
        log.info("No of records fetched for policy sync to matrix {} : ", results.size());
        results.forEach(matrixService::handlePolicyResponse);
    }

    @Override
    public void processMinimumPolicyDataToMatrix(long startDateEpoch, long endDateEpoch, int batchSize) {
        Instant startInstant = Instant.ofEpochMilli(startDateEpoch);
        Instant endInstant = Instant.ofEpochMilli(endDateEpoch);
        Pageable pageable = PageRequest.of(0, batchSize);
        List<PolicyPayload> failedResults = policyPayloadRepository.findByStatusAndCreatedAtBetweenOrderByCreatedAtAsc(
                RequestStatus.FAILED,
                startInstant,
                endInstant,
                pageable
        );
        log.info("Processing {} FAILED records first for date range: {} to {}",
                failedResults.size(), startInstant, endInstant);
        failedResults.forEach(matrixService::handlePolicyResponse);
    }

    @Override
    public void processPmsDataToMatrix() {
        Pageable pageable = PageRequest.of(0, envVariablesService.getInt(PMS_MONGO_BATCH_SIZE.name(), 100));
        List<HospitalPayload> results = hospitalPayloadRepository.findByStatusOrderByCreatedAtAsc(RequestStatus.INITIATED, pageable);
        log.info("No of records fetched for hospital sync to matrix {} : ", results.size());
        results.forEach(matrixService::handleHospitalResponse);
    }

    @Override
    public void processPmsDataToMatrix(long startDateEpoch, long endDateEpoch, int batchSize) {
        Instant startInstant = Instant.ofEpochMilli(startDateEpoch);
        Instant endInstant = Instant.ofEpochMilli(endDateEpoch);

        Pageable pageable = PageRequest.of(0, batchSize);

        List<HospitalPayload> failedResults = hospitalPayloadRepository.findByStatusAndCreatedAtBetweenOrderByCreatedAtAsc(
                RequestStatus.FAILED,
                startInstant,
                endInstant,
                pageable
        );

        log.info("Processing {} FAILED hospital records first for date range: {} to {}",
                failedResults.size(), startInstant, endInstant);
        failedResults.forEach(matrixService::handleHospitalResponse);
    }

    @Override
    public void processRenewQuoteDataFromDataLake() {
        log.info("Renew quote data fetch scheduler started at {}", LocalDateTime.now());
        LocalDate reportedDate = LocalDate.now().minusDays(envVariablesService.getInt(RENEW_QUOTE_FETCH_MINUS_NO_OF_DAYS.name(), 0));
        processRenewQuoteDataFromDataLake(reportedDate);
    }

    @Override
    public void processRenewQuoteDataFromDataLake(LocalDate reportedDate) {

        int fromIndex = 1;

        boolean isRenewQuoteBatchCompleted = renewQuoteBatchDetailRepository.findFirstByDateOrderByCreatedAtDesc(reportedDate.atStartOfDay())
                .map(detail -> RenewQuoteBatchStatus.COMPLETED == detail.getRenewQuoteBatchStatus()).orElse(false);
        if (isRenewQuoteBatchCompleted) {
            log.info("RenewQuoteBatchStatus is already COMPLETED for date : {}", reportedDate.atStartOfDay());
            return;
        }

        Optional<RenewQuoteBatchProgress> latestProgress = getLatestEndIndexForRenewQuote(reportedDate);
        if (latestProgress.isPresent()) {
            var previous = latestProgress.get();
            if (previous.getStatus() == BatchStatus.NO_DATA) {
                log.info("Renewal Quote previous batch had NO_DATA status for {}", reportedDate);
                renewQuoteBatchDetailRepository.findFirstByDateOrderByCreatedAtDesc(reportedDate.atStartOfDay())
                        .ifPresentOrElse(detail -> {
                            detail.setRenewQuoteBatchStatus(RenewQuoteBatchStatus.COMPLETED);
                            log.info("RenewQuoteBatchStatus is marked as COMPLETED for date : {}", reportedDate.atStartOfDay());
                        }, () -> {
                            var renewQuoteBatchDetail = new RenewQuoteBatchDetail();
                            renewQuoteBatchDetail.setDate(reportedDate.atStartOfDay());
                            renewQuoteBatchDetail.setRenewQuoteBatchStatus(RenewQuoteBatchStatus.COMPLETED);
                            renewQuoteBatchDetailRepository.save(renewQuoteBatchDetail);
                        });
                return;

            } else {
                fromIndex = previous.getEndIndex() + 1;
            }
        }
        int toIndex = fromIndex + envVariablesService.getInt(RENEW_QUOTE_FETCH_BATCH_SIZE.name(), 500);
        RenewQuoteBatchProgress finalProgressData;
        finalProgressData = createInitialRenewQuoteBatchProgress(reportedDate, fromIndex, toIndex);
        List<RenewalQuoteEncrypt> responses = fetchRenewQuoteData(fromIndex, toIndex, reportedDate);
        updateProgressStatus(finalProgressData, responses);
        renewQuoteBatchProgressRepository.save(finalProgressData);
    }

    @Override
    public void processRenewQuoteDataToZoho() {
        Pageable pageable = PageRequest.of(0, envVariablesService.getInt(ZOHO_RENEW_QUOTE_BATCH_SIZE.name(), 100));
        List<RenewQuotePayload> results = renewQuotePayloadRepository.findByStatusOrderByCreatedAtAsc(RequestStatus.INITIATED, pageable);
        log.info("No of records fetched for Renew quote sync to zoho {} : ", results.size());
        results.forEach(zohoService::handleRenewQuoteResponse);
    }

    @Override
    public void processRenewQuoteDataToZoho(long startDateEpoch, long endDateEpoch, int batchSize) {
        Instant startInstant = Instant.ofEpochMilli(startDateEpoch);
        Instant endInstant = Instant.ofEpochMilli(endDateEpoch);
        Pageable pageable = PageRequest.of(0, batchSize);
        List<RenewQuotePayload> failedResults = renewQuotePayloadRepository.findByStatusAndCreatedAtBetweenOrderByCreatedAtAsc(
                RequestStatus.FAILED,
                startInstant,
                endInstant,
                pageable
        );
        log.info("Processing {} renew quote FAILED records first for date range: {} to {}",
                failedResults.size(), startInstant, endInstant);
        failedResults.forEach(zohoService::handleRenewQuoteResponse);
    }

    @Override
    public void processRetryableGroupPolicyToMatrix() {
        Instant tenMinsAgo = Instant.now().minus(envVariablesService.getInt(GROUP_POLICY_DATABASE_PULL_DELAY_MIN.name(), 10), ChronoUnit.MINUTES);
        Pageable pageable = PageRequest.of(0, 100);
        List<GroupPolicyPayload> retryPayloads = groupPolicyPayloadRepository
                .findByStatusAndCreatedAtBeforeOrderByCreatedAtDesc(
                        RequestStatus.INITIATED,
                        tenMinsAgo,
                        pageable
                );
        List<String> groupPolicyPayloadRecordIds = retryPayloads.stream().map(GroupPolicyPayload::getRecordId).toList();
        log.info("Group policy numbers found for retry are : {}", retryPayloads.stream().map(GroupPolicyPayload::getPolicyNumber).toList());
        publishListToKafka(groupPolicyPayloadRecordIds);
    }

    @Override
    public void processRetryableZohoRenewalToMatrix() {
        Instant tenMinsAgo = Instant.now().minus(envVariablesService.getInt(RENEW_QUOTE_DATABASE_PULL_DELAY_MIN.name(), 10), ChronoUnit.MINUTES);
        Pageable pageable = PageRequest.of(0, 100);
        List<RenewQuotePayload> retryPayloads = renewQuotePayloadRepository
                .findByStatusAndCreatedAtBeforeOrderByCreatedAtDesc(
                        RequestStatus.INITIATED,
                        tenMinsAgo,
                        pageable
                );
        List<String> renewQuotePayloadRecordIds = retryPayloads.stream().map(RenewQuotePayload::getRecordId).toList();
        log.info("Zoho renewal policy ref numbers found for retry are : {}", retryPayloads.stream().map(RenewQuotePayload::getRenewalPolicyRefNo).toList());
        publishZohoListToKafka(renewQuotePayloadRecordIds);
    }

    void updateProgressStatus(PmsBatchProgress progress, List<MatrixHospitalPayload> responses) {
        if (responses == null) {
            progress.setStatus(BatchStatus.FAILED);
        } else if (responses.isEmpty()) {
            progress.setStatus(BatchStatus.NO_DATA);
        } else {
            saveHospitalPayloads(responses);
            progress.setStatus(BatchStatus.COMPLETED);
        }
    }

    private void updateProgressStatus(PolicyBatchProgress progress, List<PolicyDataResponse> responses) {
        if (Objects.nonNull(tracer) && Objects.nonNull(tracer.currentSpan()))
            progress.setTraceId(tracer.currentSpan().context().traceId());
        if (responses == null) {
            progress.setStatus(BatchStatus.FAILED);
        } else if (responses.isEmpty()) {
            progress.setStatus(BatchStatus.NO_DATA);
        } else {
            savePolicyPayloads(responses);
            progress.setEndIndex(progress.getStartIndex() + responses.size() - 1);
            progress.setStatus(BatchStatus.COMPLETED);
        }
    }

    private void updateProgressStatus(OneTimePolicyBatchProgress progress, List<PolicyDataResponse> responses) {
        if (responses == null) {
            progress.setStatus(BatchStatus.FAILED);
        } else if (responses.isEmpty()) {
            progress.setStatus(BatchStatus.NO_DATA);
        } else {
            progress.setEndIndex(progress.getStartIndex() + responses.size() - 1);
            progress.setStatus(BatchStatus.COMPLETED);
        }
    }

    private void updateProgressStatus(RenewQuoteBatchProgress progress, List<RenewalQuoteEncrypt> responses) {

        if (Objects.nonNull(tracer) && Objects.nonNull(tracer.currentSpan()))
            progress.setTraceId(tracer.currentSpan().context().traceId());
        if (responses == null) {
            progress.setStatus(BatchStatus.FAILED);
        } else if (responses.isEmpty()) {
            progress.setStatus(BatchStatus.NO_DATA);
        } else {
            progress.setStatus(BatchStatus.COMPLETED);

            List<RenewQuotePayload> renewQuotePayload = saveRenewQuotePayloads(responses);

            List<String> renewQuotePayloadRecordIds = renewQuotePayload.stream().map(RenewQuotePayload::getRecordId).toList();

            publishZohoListToKafka(renewQuotePayloadRecordIds);

            progress.setEndIndex(progress.getStartIndex() + responses.size() - 1);
        }
    }

    private PmsBatchProgress createInitialPmsBatchProgress(LocalDateTime fromTime, LocalDateTime toTime) {
        PmsBatchProgress progress = new PmsBatchProgress();
        progress.setFromTime(fromTime);
        progress.setToTime(toTime);
        return progress;
    }

    private RenewQuoteBatchProgress createInitialRenewQuoteBatchProgress(LocalDate date, int fromIndex, int toIndex) {
        RenewQuoteBatchProgress progress = new RenewQuoteBatchProgress();
        progress.setDate(date.atStartOfDay());
        progress.setEndIndex(toIndex);
        progress.setStartIndex(fromIndex);
        return progress;
    }

    public List<MatrixHospitalPayload> fetchPmsData(LocalDateTime from, LocalDateTime to) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
            String fromFormatted = from.format(formatter);
            String toFormatted = to.format(formatter);
            List<HospitalDetail> hospitalDetails = dataLakeService.getUpdatedPmsData(toFormatted, fromFormatted);
            List<MatrixDocumentDetail> matrixDocumentDetails = dataLakeService.getUpdatedhospitalDocumentData(toFormatted, fromFormatted);
            List<MatrixPackageDetail> matrixPackageDetails = dataLakeService.getUpdatedHospitalPackageData(toFormatted, fromFormatted);
            return hospitalDetails.stream().map(hospitalDetail -> {
                MatrixHospitalPayload matrixHospitalPayload = new MatrixHospitalPayload();
                var packageDetails = matrixPackageDetails.stream().filter(matrixPackageDetail -> hospitalDetail.getShaiHospitalId()
                        .equalsIgnoreCase(matrixPackageDetail.getShaiHospitalId())).toList();
                matrixHospitalPayload.setPackageDetails(packageDetails);
                var documentDetails = matrixDocumentDetails.stream().filter(matrixDocumentDetail -> hospitalDetail.getShaiHospitalId()
                        .equalsIgnoreCase(matrixDocumentDetail.getShaiHospitalId())).toList();
                matrixHospitalPayload.setDiscountDetails(hospitalDetail.getDiscountDetails());
                matrixHospitalPayload.setDocumentDetails(documentDetails);
                matrixHospitalPayload.setShaiHospitalId(hospitalDetail.getShaiHospitalId());
                matrixHospitalPayload.setHospitalName(hospitalDetail.getHospitalName());
                matrixHospitalPayload.setHospitalPincode(hospitalDetail.getHospitalPincode());
                matrixHospitalPayload.setHospitalContact(hospitalDetail.getHospitalContact());
                matrixHospitalPayload.setHospitalPhone(hospitalDetail.getHospitalPhone());
                matrixHospitalPayload.setHospitalIsActive(hospitalDetail.getHospitalIsActive());
                matrixHospitalPayload.setHospitalWebsite(hospitalDetail.getHospitalWebsite());
                matrixHospitalPayload.setHospitalEmail(hospitalDetail.getHospitalEmail());
                matrixHospitalPayload.setHospitalPayableToName(hospitalDetail.getHospitalPayableToName());
                matrixHospitalPayload.setHospitalIsPpn(hospitalDetail.getHospitalIsPpn());
                matrixHospitalPayload.setHospitalStdCode(hospitalDetail.getHospitalStdCode());
                matrixHospitalPayload.setHospitalState(hospitalDetail.getHospitalState());
                matrixHospitalPayload.setHospitalDistrict(hospitalDetail.getHospitalDistrict());
                matrixHospitalPayload.setHospitalRegistrationCode(hospitalDetail.getHospitalRegistrationCode());
                matrixHospitalPayload.setRohiniCode(hospitalDetail.getRohiniCode());
                matrixHospitalPayload.setLatitude(hospitalDetail.getLatitude());
                matrixHospitalPayload.setLongitude(hospitalDetail.getLongitude());
                matrixHospitalPayload.setIsNetworkHospital(hospitalDetail.getIsNetworkHospital());
                matrixHospitalPayload.setIfscCode(hospitalDetail.getIfscCode());
                matrixHospitalPayload.setIsBlacklisted(hospitalDetail.getIsBlacklisted());
                matrixHospitalPayload.setIsCaution(hospitalDetail.getIsCaution());
                matrixHospitalPayload.setSpecialityType(hospitalDetail.getSpecialityType());
                matrixHospitalPayload.setHospitalGstinNo(hospitalDetail.getHospitalGstinNo());
                matrixHospitalPayload.setHospitalTanNumber(hospitalDetail.getHospitalTanNumber());
                matrixHospitalPayload.setHospitalPanNumber(hospitalDetail.getHospitalPanNumber());
                matrixHospitalPayload.setBedCount(hospitalDetail.getBedCount());
                matrixHospitalPayload.setAccountHolderName(hospitalDetail.getAccountHolderName());
                matrixHospitalPayload.setAccountNumber(hospitalDetail.getAccountNumber());
                matrixHospitalPayload.setCpuCode(hospitalDetail.getCpuCode());
                matrixHospitalPayload.setDiscountRemarks(hospitalDetail.getDiscountRemarks());
                matrixHospitalPayload.setEmpanelmentEndDate(hospitalDetail.getEmpanelmentEndDate());
                matrixHospitalPayload.setEmpanelmentStartDate(hospitalDetail.getEmpanelmentStartDate());
                matrixHospitalPayload.setEpdAgreedDays(hospitalDetail.getEpdAgreedDays());
                matrixHospitalPayload.setEpdEndDate(hospitalDetail.getEpdEndDate());
                matrixHospitalPayload.setEpdPercentage(hospitalDetail.getEpdPercentage());
                matrixHospitalPayload.setEpdStartDate(hospitalDetail.getEpdStartDate());
                matrixHospitalPayload.setHospHfrCode(hospitalDetail.getHospHfrCode());
                matrixHospitalPayload.setHospIsFaxUpdated(hospitalDetail.getHospIsFaxUpdated());
                matrixHospitalPayload.setHospitalAddr1(hospitalDetail.getHospitalAddr1());
                matrixHospitalPayload.setHospitalAddr2(hospitalDetail.getHospitalAddr2());
                matrixHospitalPayload.setHospitalCityId(hospitalDetail.getHospitalCityId());
                matrixHospitalPayload.setHospitalFlag(hospitalDetail.getHospitalFlag());
                matrixHospitalPayload.setPrathamFlag(hospitalDetail.getPrathamFlag());
                matrixHospitalPayload.setHospitalGrade(hospitalDetail.getHospitalGrade());
                matrixHospitalPayload.setSocFlag(hospitalDetail.getSocFlag());
                matrixHospitalPayload.setNetworkHospType(hospitalDetail.getNetworkHospType());
                return matrixHospitalPayload;
            }).toList();
        } catch (Exception ex) {
            log.error("Error fetching PMS data", ex);
            return Collections.emptyList();
        }

    }

    public List<RenewalQuoteEncrypt> fetchRenewQuoteData(int fromIndex, int toIndex, LocalDate date) {
        try {
            return dataLakeService.getRenewQuoteData(String.valueOf(fromIndex), String.valueOf(toIndex), date);
        } catch (Exception ex) {
            log.error("Failed to fetch renewal policy data from data lake", ex);
            return Collections.emptyList();
        }
    }


    private void saveHospitalPayloads(List<MatrixHospitalPayload> responses) {
        responses.forEach(response -> {
            HospitalPayload payload = new HospitalPayload();
            payload.setMatrixHospitalPayload(response);
            payload.setHospitalID(response.getShaiHospitalId());
            payload.setStatus(RequestStatus.INITIATED);
            payload.setRetryCount(0);
            hospitalPayloadRepository.save(payload);
        });
    }

//    private void saveRenewQuotePayloads(List<RenewalQuoteEncrypt> responses) {
//        responses.forEach(response -> {
//            RenewQuotePayload payload = new RenewQuotePayload();
//            payload.setRenewalQuoteEncrypt(response);
//            payload.setRenewalPolicyRefNo(response.getRenewalPolicyRefNo());
//            payload.setStatus(RequestStatus.INITIATED);
//            payload.setRetryCount(Constants.RETRY_COUNT);
//            renewQuotePayloadRepository.save(payload);
//        });
//    }

    private PolicyBatchProgress createInitialBatchProgress(LocalDate date, int fromIndex, int toIndex) {
        PolicyBatchProgress progress = new PolicyBatchProgress();
        progress.setDate(date.atStartOfDay());
        progress.setEndIndex(toIndex);
        progress.setStartIndex(fromIndex);
        return progress;
    }

    private OneTimePolicyBatchProgress createInitialOneTimeBatchProgress(long fromIndex, long toIndex) {
        OneTimePolicyBatchProgress progress = new OneTimePolicyBatchProgress();
        progress.setEndIndex(toIndex);
        progress.setStartIndex(fromIndex);
        return progress;
    }

    List<PolicyDataResponse> fetchPolicyData(int fromIndex, int toIndex, LocalDate date) {
        try {
            return dataLakeService.getUpdatedMinimumPolicyDateData(String.valueOf(fromIndex), String.valueOf(toIndex), date);
        } catch (Exception ex) {
            log.error("Failed to fetch policy data from data lake", ex);
            return Collections.emptyList();
        }
    }

    List<PolicyDataResponse> fetchOneTimePolicyData(long fromIndex, long toIndex) {
        try {
            log.info("fetchOneTimePolicyData started from : {} , to : {}", fromIndex, toIndex);
            return dataLakeService.getOneTimeMinimumPolicyData(String.valueOf(fromIndex), String.valueOf(toIndex));
        } catch (Exception ex) {
            log.error("Failed to fetch policy data from data lake", ex);
            return null;
        }
    }

    private void savePolicyPayloads(List<PolicyDataResponse> responses) {
        responses.forEach(response -> {
            PolicyPayload payload = new PolicyPayload();
            payload.setPolicyNumber(response.getPolicyInfo().getPolicyNumber());
            payload.setPayload(response);
            payload.setStatus(RequestStatus.INITIATED);
            payload.setRetryCount(Constants.RETRY_COUNT);
            policyPayloadRepository.save(payload);
        });
    }

    private List<PolicyPayload> getPolicyPayloads(List<PolicyDataResponse> responses) {
        return responses.stream().map(response -> {
            PolicyPayload payload = new PolicyPayload();
            payload.setPolicyNumber(response.getPolicyInfo().getPolicyNumber());
            payload.setPayload(response);
            payload.setStatus(RequestStatus.INITIATED);
            payload.setRetryCount(Constants.RETRY_COUNT);
            return payload;
        }).toList();
    }

    public Optional<PolicyBatchProgress> getLatestEndIndex(LocalDate reportedDate) {
        return policyBatchProgressRepository.findFirstByDateOrderByCreatedAtDesc(reportedDate.atStartOfDay());
    }

    public Optional<RenewQuoteBatchProgress> getLatestEndIndexForRenewQuote(LocalDate reportedDate) {
        return renewQuoteBatchProgressRepository.findFirstByDateOrderByCreatedAtDesc(reportedDate.atStartOfDay());
    }

    @Override
    public void processMinimumGroupPolicyDataFromDataLake() {
        log.info("processMinimumGroupPolicyDataFromDataLake scheduler started at {}", LocalDateTime.now());
        LocalDate reportedDate = LocalDate.now().minusDays(envVariablesService.getInt(GROUP_POLICY_MINUS_NO_OF_DAYS.name(), 1));
        processMinimumGroupPolicyDataFromDataLake(reportedDate, false);
    }

    @Override
    public void processMinimumGroupPolicyDataFromDataLake(LocalDate reportedDate, boolean manual) {
        int fromIndex = 1;
        if (!manual) {
            boolean isGroupPolicyBatchCompleted = groupPolicyBatchDetailRepository.findFirstByDateOrderByCreatedAtDesc(reportedDate.atStartOfDay())
                    .map(detail -> GroupPolicyBatchStatus.COMPLETED == detail.getGroupPolicyBatchStatus()).orElse(false);
            if (isGroupPolicyBatchCompleted) {
                log.info("GroupPolicyBatchStatus is already COMPLETED for date : {}", reportedDate.atStartOfDay());
                return;
            }
        }
        Optional<GroupPolicyBatchProgress> latestProgress = getGroupPolicyLatestEndIndex(reportedDate);
        if (latestProgress.isPresent()) {
            var previous = latestProgress.get();
            if (previous.getStatus() == BatchStatus.NO_DATA) {
                if (!manual) {
                    log.info("Previous batch for processMinimumGroupPolicyDataFromDataLake had NO_DATA status for {}", reportedDate);
                    groupPolicyBatchDetailRepository.findFirstByDateOrderByCreatedAtDesc(reportedDate.atStartOfDay())
                            .ifPresentOrElse(detail -> {
                                detail.setGroupPolicyBatchStatus(GroupPolicyBatchStatus.COMPLETED);
                                log.info("GroupPolicyBatch is marked as COMPLETED for date : {}", reportedDate.atStartOfDay());
                            }, () -> {
                                var groupPolicyBatchDetail = new GroupPolicyBatchDetail();
                                groupPolicyBatchDetail.setDate(reportedDate.atStartOfDay());
                                groupPolicyBatchDetail.setGroupPolicyBatchStatus(GroupPolicyBatchStatus.COMPLETED);
                                groupPolicyBatchDetailRepository.save(groupPolicyBatchDetail);
                            });
                    return;
                } else {
                    fromIndex = previous.getStartIndex();
                }
            } else {
                fromIndex = previous.getEndIndex() + 1;
            }
        }
        int toIndex = fromIndex + envVariablesService.getInt(DATABRICKS_GROUP_POLICY_BATCH_SIZE.name(), 500) - 1;
        GroupPolicyBatchProgress groupPolicyBatchProgress;
        groupPolicyBatchProgress = createInitialGroupPolicyBatchProgress(reportedDate, fromIndex, toIndex);
        List<GroupPolicyData> responses = fetchGroupPolicyData(fromIndex, toIndex, reportedDate);
        log.info("Group policy numbers found to push to matrix from {} to {} index are : {}", fromIndex, toIndex, getPolicyNumbersOrDefault(responses));
        updateGroupProgressStatus(groupPolicyBatchProgress, responses);
        groupPolicyBatchProgressRepository.save(groupPolicyBatchProgress);
    }

    public Optional<GroupPolicyBatchProgress> getGroupPolicyLatestEndIndex(LocalDate reportedDate) {
        return groupPolicyBatchProgressRepository.findFirstByDateOrderByCreatedAtDesc(reportedDate.atStartOfDay());
    }

    private GroupPolicyBatchProgress createInitialGroupPolicyBatchProgress(LocalDate date, int fromIndex, int toIndex) {
        GroupPolicyBatchProgress progress = new GroupPolicyBatchProgress();
        progress.setDate(date.atStartOfDay());
        progress.setEndIndex(toIndex);
        progress.setStartIndex(fromIndex);
        return progress;
    }

    List<GroupPolicyData> fetchGroupPolicyData(int fromIndex, int toIndex, LocalDate date) {
        try {
            return dataLakeService.getUpdatedGroupPolicyData(String.valueOf(fromIndex), String.valueOf(toIndex), date);
        } catch (Exception ex) {
            log.error("Failed to fetch group policy data from data lake", ex);
            return Collections.emptyList();
        }
    }

    private void updateGroupProgressStatus(GroupPolicyBatchProgress progress, List<GroupPolicyData> responses) {
        if (Objects.nonNull(tracer) && Objects.nonNull(tracer.currentSpan()))
            progress.setTraceId(tracer.currentSpan().context().traceId());
        if (responses == null) {
            progress.setStatus(BatchStatus.FAILED);
        } else if (responses.isEmpty()) {
            progress.setStatus(BatchStatus.NO_DATA);
        } else {

            progress.setStatus(BatchStatus.COMPLETED);

            List<GroupPolicyPayload> groupPolicyPayloads = saveGroupPolicyPayloads(responses);

            List<String> groupPolicyPayloadRecordIds = groupPolicyPayloads.stream().map(GroupPolicyPayload::getRecordId).toList();

            publishListToKafka(groupPolicyPayloadRecordIds);

            progress.setEndIndex(progress.getStartIndex() + responses.size() - 1);
        }
    }
    private List<GroupPolicyPayload> saveGroupPolicyPayloads(List<GroupPolicyData> responses) {
        List<GroupPolicyPayload> payloads = responses.stream().map(response -> {
            GroupPolicyPayload groupPolicyPayload = new GroupPolicyPayload();
            groupPolicyPayload.setPolicyNumber(response.getPolicyInfo().getPolicyNumber());
            groupPolicyPayload.setRecordId(SequenceGenerator.getNextSequence());
            groupPolicyPayload.setPayload(response);
            groupPolicyPayload.setStatus(RequestStatus.INITIATED);
            groupPolicyPayload.setRetryCount(Constants.RETRY_COUNT);
            return groupPolicyPayload;
        }).toList();
        return groupPolicyPayloadRepository.saveAll(payloads);
    }
    private List<RenewQuotePayload> saveRenewQuotePayloads(List<RenewalQuoteEncrypt> responses) {
        List<RenewQuotePayload> payload = responses.stream().map(response -> {
            //    responses.forEach(response -> {
            RenewQuotePayload renewQuotePayload = new RenewQuotePayload();
            renewQuotePayload.setRecordId(SequenceGenerator.getNextSequence());
            renewQuotePayload.setRenewalQuoteEncrypt(response);
            renewQuotePayload.setRenewalPolicyRefNo(response.getRenewalPolicyRefNo());
            renewQuotePayload.setStatus(RequestStatus.INITIATED);
            renewQuotePayload.setRetryCount(Constants.RETRY_COUNT);
            return renewQuotePayload;
        }).toList();
        return renewQuotePayloadRepository.saveAll(payload);
    }

    private void publishListToKafka(List<String> ids) {
        for(String id : ids){
            try {
                markMinimumGroupPolicyQueued(id);
                kafkaEventPublisherUtil.publishEventToKafkaTopic(applicationProperties.getGroupPolicyTopic(), id);
                log.info("Kafka Success | Group policy recordId : {} sent", id);
            } catch (Exception e) {
                log.error("Kafka Error | Group policy failed for record ID {} to publish", id, e.getMessage());
            }
        }
    }

    private void publishZohoListToKafka(List<String> ids) {
        for(String id : ids){
            try {
                markZohoCrmQueued(id);
                kafkaEventPublisherUtil.publishEventToKafkaTopic(applicationProperties.getZohoCRMTopic(), id);
                log.info("Kafka Success | zoho renewal policy recordId : {} sent", id);
            } catch (Exception e) {
                log.error("Kafka Error | zoho renewal policy failed for record ID {} to publish", id, e.getMessage());
            }
        }
    }
    private void markZohoCrmQueued(String recordId){
        RenewQuotePayload renewQuotePayload = renewQuotePayloadRepository.findByRecordId(recordId).orElse(null);
        if(renewQuotePayload != null){
            renewQuotePayload.setStatus(RequestStatus.QUEUED);
            renewQuotePayloadRepository.save(renewQuotePayload);
            return;
        }

        log.warn("method: markZohoCrmQueued RecordID not Found : {}", recordId );
    }
    private void markMinimumGroupPolicyQueued(String recordId){
        GroupPolicyPayload groupPolicyPayload = groupPolicyPayloadRepository.findByRecordId(recordId).orElse(null);
        if(groupPolicyPayload != null){
            groupPolicyPayload.setStatus(RequestStatus.QUEUED);
            groupPolicyPayloadRepository.save(groupPolicyPayload);
            return;
        }

        log.warn("method: markMinimumGroupPolicyQueued RecordID not Found : {}", recordId );
    }

    @Override
    @Async
    public void processOneTimeMinimumGroupPolicyDataToMatrix(OneTimeGroupBatchUpdateRequest request){
        Optional<OneTimeGroupPolicyStatus> data = oneTimeGroupPolicyStatusRepository.findFirstByOrderByCreatedAtDesc();
        if (STOP.equalsIgnoreCase(request.getCommand())) {
            log.info("stopping one time group policy data sync");
            data.ifPresent(this::stopGroupPolicySync);
        } else if (STOP_RESTART.equalsIgnoreCase(request.getCommand())) {
            validateOrInitializeGroupPolicyBatchStatus();
            data.ifPresent(this::stopRetryGroupPolicySync);
        } else if (START.equalsIgnoreCase(request.getCommand())) {
            log.info("starting one time group data data sync");
            data = startGroupPolicySync(data);
            long fromIndex = determineGroupPolicyStartingIndex();
            BatchStatus finalStatus = processGroupPolicyBatches(fromIndex);
            updateGroupPolicyFinalSyncStatus(data, finalStatus);
        } else if (RETRY.equalsIgnoreCase(request.getCommand())) {
            log.info("retry group policy one time data sync");
            int fromIndex = request.getFromIndex();
            int endIndex = request.getEndIndex();
            startBulkGroupPolicyRetry(data);
            retryGroupPolicyBatches(fromIndex, endIndex, request);
        }
    }

    @Override
    public void processOneTimeMinimumGroupPolicyDataRemovalToMatrix(OneTimeBatchRemoveRequest request){
        if (request.isRemoveProgressCollection()) {
            groupPolicyOneTimeBatchProgressRepository.deleteAll();
        }
        if (request.isRemoveStatusCollection()) {
            oneTimeGroupPolicyStatusRepository.deleteAll();
        }
    }

    private void stopGroupPolicySync(OneTimeGroupPolicyStatus data) {
        data.setStatus(OneTimeStatus.STOPPED);
        oneTimeGroupPolicyStatusRepository.save(data);
    }

    private void stopRetryGroupPolicySync(OneTimeGroupPolicyStatus data) {
        data.setStatus(OneTimeStatus.RETRY_STOPPED);
        oneTimeGroupPolicyStatusRepository.save(data);
    }

    private Optional<OneTimeGroupPolicyStatus> startGroupPolicySync(Optional<OneTimeGroupPolicyStatus> data) {
        if (data.isPresent()) {
            log.info("one time group policy data sync already present");
            if (data.get().getStatus() == OneTimeStatus.IN_PROGRESS) {
                throw new MatrixDataSyncException(ONE_TIME_GROUP_POLICY_SYNC_ALREADY_IN_PROGRESS);
            }
            data.get().setStatus(OneTimeStatus.IN_PROGRESS);
            var status = oneTimeGroupPolicyStatusRepository.save(data.get());
            log.info("one time group policy data sync updated : {}", status);
        } else {
            log.info("creating new one time group policy data sync status entry");
            OneTimeGroupPolicyStatus newStatus = new OneTimeGroupPolicyStatus();
            newStatus.setStatus(OneTimeStatus.IN_PROGRESS);
            var status = oneTimeGroupPolicyStatusRepository.save(newStatus);
            log.info("new group policy data sync status entry created: {}", status);
            data = Optional.of(newStatus);
        }
        return data;
    }

    private void updateGroupPolicyFinalSyncStatus(Optional<OneTimeGroupPolicyStatus> data, BatchStatus status) {
        if (data.isPresent()) {
            if (status == BatchStatus.NO_DATA) {
                data.get().setStatus(OneTimeStatus.COMPLETED);
            } else if (status == BatchStatus.FAILED) {
                data.get().setStatus(OneTimeStatus.FAILED);
            }
            oneTimeGroupPolicyStatusRepository.save(data.get());
        }
    }

    private void startBulkGroupPolicyRetry(Optional<OneTimeGroupPolicyStatus> data) {
        if (data.isPresent()) {
            log.info("one time group policy data retry sync already present");
            if (data.get().getStatus() == OneTimeStatus.IN_PROGRESS) {
                throw new MatrixDataSyncException(ONE_TIME_GROUP_POLICY_SYNC_ALREADY_IN_PROGRESS);
            }
            data.get().setStatus(OneTimeStatus.RETRY_INITIATED);
            var status = oneTimeGroupPolicyStatusRepository.save(data.get());
            log.info("one time group policy retry data sync updated : {}", status);
            return;
        }
        throw new MatrixDataSyncException(ONE_TIME_GROUP_POLICY_SYNC_STATUS_NOT_FOUND);
    }

    private void validateOrInitializeGroupPolicyBatchStatus() {
        Optional<OneTimeGroupPolicyStatus> statusOpt = oneTimeGroupPolicyStatusRepository.findFirstByOrderByCreatedAtDesc();
        if (statusOpt.isPresent()) {
            if (OneTimeStatus.IN_PROGRESS == statusOpt.get().getStatus()) {
                throw new MatrixDataSyncException(ONE_TIME_BATCH_ALREADY_IN_PROGRESS);
            }
        } else {
            OneTimeGroupPolicyStatus entity = new OneTimeGroupPolicyStatus();
            entity.setStatus(OneTimeStatus.IN_PROGRESS);
            oneTimeGroupPolicyStatusRepository.save(entity);
        }
    }

    private long determineGroupPolicyStartingIndex() {
        return groupPolicyOneTimeBatchProgressRepository.findFirstByOrderByCreatedAtDesc().map(progress -> {
            if (progress.getStatus() == BatchStatus.NO_DATA) {
                log.info("Previous batch had NO_DATA status for group policy");
                return progress.getStartIndex();
            } else {
                return progress.getEndIndex() + 1;
            }
        }).orElse(1l);
    }

    private BatchStatus processGroupPolicyBatches(long fromIndex) {
        AtomicLong atomicFromIndex = new AtomicLong(fromIndex);
        while (true) {
            var response = tracingUtils.runWithSpanSupplier("process-group-policy", () -> {
                ensureGroupPolicySyncNotStopped();
                long toIndex = calculateToIndexGroupPolicy(atomicFromIndex.get());
                OneTimeGroupPolicyBatchProgress progress = createInitialOneTimeGroupPolicyBatchProgress(atomicFromIndex.get(), toIndex);
                log.info("Start and end index for one time group policy data : {} {}", atomicFromIndex.get(), toIndex);
                var responses = fetchOneTimeGroupPolicyData(atomicFromIndex.get(), toIndex);
                updateProgressStatus(progress, responses);
                if (responses != null && !responses.isEmpty()) {
                    log.info("Bulk Policy numbers found for migration. {}", getPolicyNumbersOrDefault(responses));
                    boolean isSuccess = matrixService.pushBulkGroupPolicy(responses);
                    progress.setMatrixSuccess(isSuccess);
                }
                progress.setTraceId(tracer.currentSpan().context().traceId());
                groupPolicyOneTimeBatchProgressRepository.save(progress);
                return progress;
            });
            if (isProcessingComplete(response)) {
                return response.getStatus();
            }
            atomicFromIndex.set(response.getEndIndex() + 1);
        }
    }

    private static List<String> getPolicyNumbersOrDefault(List<GroupPolicyData> responses) {
        try{
            return responses.stream().map(policyData -> policyData.getPolicyInfo().getPolicyNumber()).toList();
        } catch (Exception e){
            log.error("Error occurred while listing policy Numbers from {} . Message : {}", ObjectMapperUtil.convertObjectToString(responses), e.getMessage(), e);
            return Collections.emptyList();
        }
    }

    private void ensureGroupPolicySyncNotStopped() {
        var currentStatus = oneTimeGroupPolicyStatusRepository.findFirstByOrderByCreatedAtDesc();
        if (currentStatus.isPresent() && OneTimeStatus.STOPPED == currentStatus.get().getStatus()) {
            throw new MatrixDataSyncException(ONE_TIME_GROUP_POLICY_SYNC_STOPPED);
        }
    }

    private OneTimeGroupPolicyBatchProgress createInitialOneTimeGroupPolicyBatchProgress(long fromIndex, long toIndex) {
        OneTimeGroupPolicyBatchProgress progress = new OneTimeGroupPolicyBatchProgress();
        progress.setEndIndex(toIndex);
        progress.setStartIndex(fromIndex);
        return progress;
    }

    List<GroupPolicyData> fetchOneTimeGroupPolicyData(long fromIndex, long toIndex) {
        try {
            log.info("fetchOneTimeGroupPolicyData started from : {} , to : {}", fromIndex, toIndex);
            return dataLakeService.getOneTimeGroupPolicyData(String.valueOf(fromIndex), String.valueOf(toIndex));
        } catch (Exception ex) {
            log.error("Failed to fetch group policy data from data lake", ex);
            return null;
        }
    }

    private void updateProgressStatus(OneTimeGroupPolicyBatchProgress progress, List<GroupPolicyData> responses) {
        if (responses == null) {
            progress.setStatus(BatchStatus.FAILED);
        } else if (responses.isEmpty()) {
            progress.setStatus(BatchStatus.NO_DATA);
        } else {
            progress.setEndIndex(progress.getStartIndex() + responses.size() - 1);
            progress.setStatus(BatchStatus.COMPLETED);
        }
    }

    private boolean isProcessingComplete(OneTimeGroupPolicyBatchProgress progress) {
        BatchStatus status = progress.getStatus();
        return status == BatchStatus.NO_DATA;
    }

    private long calculateToIndexGroupPolicy(long fromIndex) {
        long batchSize = envVariablesService.getLong(ONE_TIME_GROUP_POLICY_MONGO_BATCH_SIZE.name(), 200L);
        return fromIndex + batchSize - 1;
    }
}
