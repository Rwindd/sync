package com.star.matrix.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.star.matrix.DataLakeService;
import com.star.matrix.EnvVariablesService;
import com.star.matrix.client.DataLakeClient;
import com.star.matrix.dto.*;
import com.star.matrix.dto.common.*;
import com.star.matrix.dto.postgres.*;
import com.star.matrix.dto.request.MatrixDocumentDetail;
import com.star.matrix.dto.request.MatrixPackageDetail;
import com.star.matrix.dto.request.StatementIDRequest;
import com.star.matrix.dto.response.DataBricksResponse;
import com.star.matrix.dto.response.PolciyInsuredDetailsResponse;
import com.star.matrix.dto.response.DataLakeResponseDto;
import com.star.matrix.dto.zoho.RenewalQuoteEncrypt;
import com.star.matrix.entity.CustomerDetail;
import com.star.matrix.dto.zoho.UpsellPremiumRenewQuote;
import com.star.matrix.entity.DataLakeSourceEntity;
import com.star.matrix.entity.HospitalFlag;
import com.star.matrix.entity.HospitalFlagName;
import com.star.matrix.exception.MatrixDataSyncException;
import com.star.matrix.exception.MatrixErrorCode;
import com.star.matrix.repository.DataLakeRepository;
import com.star.matrix.repository.PostgresRepository;
import com.star.matrix.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import com.starhealth.encryption.service.FieldEncryptionService;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.star.matrix.constant.EnvVariableConstant.*;
import static com.star.matrix.constant.EnvVariableConstant.POSTGRES_FLAG;
import static com.star.matrix.constant.EnvVariableConstant.POSTGRES_POLICY_CLAIM_DOCUMENT_QUERY;
import static com.star.matrix.constant.EnvVariableConstant.POSTGRES_POLICY_CLAIM_HISTORY_QUERY;
import static com.star.matrix.constant.EnvVariableConstant.POSTGRES_POLICY_DOCUMENT_QUERY;
import static com.star.matrix.constant.EnvVariableConstant.POSTGRES_POLICY_MEMBER_QUERY;
import static com.star.matrix.exception.MatrixErrorCode.*;
import static com.star.matrix.util.ApplicationUtil.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class DataLakeServiceImpl implements DataLakeService {

    private final DataLakeClient dataLakeClient;
    private final EnvVariablesService envVariablesService;
    public static final String POLICY_NUMBER_STRING = "{policyNumber}";
    private static final String SUCCEEDED = "SUCCEEDED";
    private static final String HOSPITAL_FLAG_PRESENT = "YES";
    private final PostgresRepository postgresRepository;
    private final FieldEncryptionService fieldEncryptionService;
    private final DataLakeRepository repository;


    @Override
    public List<PolicyMemberDetailSummary> getPolicyAndMemberDetails(String policyNumber) {
        log.info("Request received to call policy and member details for policy Number: {}", policyNumber);
        boolean postgresFlag = envVariablesService.getBool(POSTGRES_FLAG.name(), true);
        if(postgresFlag){
            String postgresQuery = envVariablesService.getValueByKey(POSTGRES_POLICY_MEMBER_QUERY.name());
            log.info("Postgres getPolicyAndMemberDetails query : {}", postgresQuery);
            List<PostgresPolicyDetail> postgresResult = postgresRepository.getPolicyAndMemberDetails(postgresQuery, policyNumber);
            log.info("Response received from Postgres for executing policy and member data query for policy no :{}, {} ",
                    policyNumber, ObjectMapperUtil.convertObjectToJson(postgresResult));
            List<PolicyDetail> policyDetails = postgresResult.stream()
                    .map(this::toPolicyDetail)
                    .toList();
            return groupByPolicyNo(policyDetails);
        }
        String query = envVariablesService.getValueByKey(POLICY_MEMBER_QUERY.name()).replace(POLICY_NUMBER_STRING, policyNumber);
        var statementIDRequest = new StatementIDRequest();
        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID.name()));
        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
        statementIDRequest.setStatement(query);
        var response = dataLakeClient.getDataBricksResponse(statementIDRequest);
        log.info("Response received from Datalake for executing policy and member data query for policy no :{}, {} ", policyNumber, ObjectMapperUtil.convertObjectToJson(response));
        var result = Optional.ofNullable(response.getStatus()).map(DataBricksResponse.Status::getState)
                .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
                .flatMap(state -> Optional.ofNullable(response.getResult()))
                .flatMap(state -> Optional.ofNullable(response.getManifest()))
                .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));
        log.info("Response from Data Lake Client for Policy  Member Detail Summary {} ", result);
        List<PolicyDetail> policyDetails = new ArrayList<>();
        if (Objects.nonNull(response.getResult().getDataArray())) {
            for (var list : response.getResult().getDataArray()) {
                var policyDetail = getPolicyDetail(list);
                policyDetails.add(policyDetail);
            }
        }
        return groupByPolicyNo(policyDetails);
    }

    @Override
    public List<PolicyDocumentSummary> getPolicyDocuments(Set<String> policyNumbers) {
        log.info("Request received to call policy documents query for policy Number: {}", policyNumbers);
        boolean postgresFlag = envVariablesService.getBool(POSTGRES_FLAG.name(), false);
        if(postgresFlag){
            String postgresQuery = envVariablesService.getValueByKey(POSTGRES_POLICY_DOCUMENT_QUERY.name());
            log.info("Postgres getPolicyDocuments Query : {}", postgresQuery);
            List<PostgresPolicyDocument> postgresResult = postgresRepository.getPolicyDocuments(postgresQuery, policyNumbers);
            log.info("Response received from Postgres for executing policy documents query for policy no :{}, {} ",
                    policyNumbers, ObjectMapperUtil.convertObjectToJson(postgresResult));
            List<PolicyDocument> policyDocument = postgresResult.stream()
                    .map(this::toPolicyDocument)
                    .toList();
            return groupByPolicyDocument(policyDocument);
        }
        var statementIDRequest = new StatementIDRequest();
        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID.name()));
        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
        try {
            String replacePolicyNumbers = getInClauseForPolicyNumber(policyNumbers);
            String query = envVariablesService.getValueByKey(POLICY_DOCUMENT_QUERY.name()).replace(POLICY_NUMBER_STRING, replacePolicyNumbers);
            statementIDRequest.setStatement(query);
            var response = dataLakeClient.getDataBricksResponse(statementIDRequest);
            log.info("Response received from Datalake for executing policy document query for policyno :{}, {} ", policyNumbers, ObjectMapperUtil.convertObjectToJson(response));
            var result = Optional.ofNullable(response.getStatus()).map(DataBricksResponse.Status::getState)
                    .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
                    .flatMap(state -> Optional.ofNullable(response.getResult()))
                    .flatMap(state -> Optional.ofNullable(response.getManifest()))
                    .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));
            log.info("Response from Data Lake Client for Policy  Document Summary {} ", result);
            List<PolicyDocument> policyDocuments = new ArrayList<>();
            if (Objects.nonNull(response.getResult().getDataArray())) {
                for (var list : response.getResult().getDataArray()) {
                    var policyDocument = getPolicyDocumentDetail(list);
                    policyDocuments.add(policyDocument);
                }
            }
            return groupByPolicyDocument(policyDocuments);
        } catch (Exception exception) {
            log.error("Error while fetching policy documents ", exception);
            throw exception;
        }
    }

    @Override
    public List<ClaimHistorySummary> getPolicyClaimHistory(Set<String> policyNumbers) {
        log.info("Request received to call policy claim history query for policy Number: {}", policyNumbers);
        boolean postgresFlag = envVariablesService.getBool(POSTGRES_FLAG.name(), false);
        if(postgresFlag){
            String postgresQuery = envVariablesService.getValueByKey(POSTGRES_POLICY_CLAIM_HISTORY_QUERY.name());
            log.info("Postgres getPolicyClaimHistory Query : {}", postgresQuery);
            List<PostgresClaimHistory> postgresResult = postgresRepository.getPolicyClaimHistory(postgresQuery,policyNumbers);
            log.info("Response received from Postgres for executing policy claim history query for policy no :{}, {} ",
                    policyNumbers, ObjectMapperUtil.convertObjectToJson(postgresResult));
            List<ClaimHistory> result = postgresResult.stream()
                    .map(this::mapToClaimHistory)
                    .toList();
            return groupByPolicyClaimHistory(result);
        }
        var statementIDRequest = new StatementIDRequest();
        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID.name()));
        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
        try {
            String replacePolicyNumbers = getInClauseForPolicyNumber(policyNumbers);
            String query = envVariablesService.getValueByKey(POLICY_CLAIM_HISTORY_QUERY.name()).replace(POLICY_NUMBER_STRING,
                    replacePolicyNumbers);
            statementIDRequest.setStatement(query);
            var response = dataLakeClient.getDataBricksResponse(statementIDRequest);
            log.info("Response received from Datalake for executing policy claim history query for policy no :{}, {} ", policyNumbers, ObjectMapperUtil.convertObjectToJson(response));
            var result = Optional.ofNullable(response.getStatus()).map(DataBricksResponse.Status::getState)
                    .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
                    .flatMap(state -> Optional.ofNullable(response.getResult()))
                    .flatMap(state -> Optional.ofNullable(response.getManifest()))
                    .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));
            log.info("Response from Data Lake Client for Claim History Summary {} ", result);
            List<ClaimHistory> claimHistories = new ArrayList<>();
            if (Objects.nonNull(response.getResult().getDataArray())) {
                for (var list : response.getResult().getDataArray()) {
                    var claimHistory = getPolicyClaimHistoryDetail(list);
                    claimHistories.add(claimHistory);
                }
            }
            return groupByPolicyClaimHistory(claimHistories);
        } catch (Exception exception) {
            log.error("Error while fetching policy claim history ", exception);
            throw exception;
        }
    }

    @Override
    public List<ClaimDocumentSummary> getPolicyClaimDocuments(Set<String> policyNumbers) {
        log.info("Request received to call policy claim documents query for policy Number: {}", policyNumbers);
        boolean postgresFlag = envVariablesService.getBool(POSTGRES_FLAG.name(), false);
        if(postgresFlag){
            String postgresQuery = envVariablesService.getValueByKey(POSTGRES_POLICY_CLAIM_DOCUMENT_QUERY.name());
            log.info("Postgres getPolicyClaimDocuments Query : {}", postgresQuery);
            List<PostgresClaimDocument> postgresResult = postgresRepository.getPolicyClaimDocuments(postgresQuery, policyNumbers);
            log.info("Response received from Postgres for executing policy claims document query for policy no :{}, {} ",
                    policyNumbers, ObjectMapperUtil.convertObjectToJson(postgresResult));
            List<ClaimDocument> claimDocuments = postgresResult.stream()
                    .map(this::toClaimDocument)
                    .toList();
            return groupByPolicyClaimDocuments(claimDocuments);
        }
        var statementIDRequest = new StatementIDRequest();
        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID.name()));
        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
        try {
            String replacePolicyNumbers = getInClauseForPolicyNumber(policyNumbers);
            String query = envVariablesService.getValueByKey(POLICY_CLAIM_DOCUMENT_QUERY.name()).replace(POLICY_NUMBER_STRING,
                    replacePolicyNumbers);
            statementIDRequest.setStatement(query);
            var response = dataLakeClient.getDataBricksResponse(statementIDRequest);
            log.info("Response received from Datalake for executing policy claims document query for policy no :{}, {} ", policyNumbers, ObjectMapperUtil.convertObjectToJson(response));
            var result = Optional.ofNullable(response.getStatus()).map(DataBricksResponse.Status::getState)
                    .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
                    .flatMap(state -> Optional.ofNullable(response.getManifest()))
                    .flatMap(state -> Optional.ofNullable(response.getResult()))
                    .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));
            log.info("Response from Data Lake Client for Claim Document Summary {} ", result);
            List<ClaimDocument> claimDocuments = new ArrayList<>();
            if (Objects.nonNull(response.getResult().getDataArray())) {
                for (var list : response.getResult().getDataArray()) {
                    var claimDocument = getPolicyClaimDocument(list);
                    claimDocuments.add(claimDocument);
                }
            }
            return groupByPolicyClaimDocuments(claimDocuments);
        } catch (Exception exception) {
            log.error("Error while fetching policy claim documents ", exception);
            throw exception;
        }
    }

    @Override
    public List<HospitalDetail> getUpdatedPmsData(String endTime, String startTime) {
        var response = new ArrayList<HospitalDetail>();
        var statementIDRequest = new StatementIDRequest();
        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID_BATCH.name()));
        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
        log.info("Request received to call pms update query with startTime: {} , endTime: {}", startTime, endTime);
        try {
            String query = envVariablesService.getValueByKey(PMS_UPDATED_QUERY.name()).replace("{currentTime}", endTime)
                    .replace("{oneHourAgoTime}", startTime);
            statementIDRequest.setStatement(query);
            var dataBricksResponse = dataLakeClient.getDataBricksResponse(statementIDRequest);
            log.info("Response received from Datalake for executing query for fetching pms data :{}", ObjectMapperUtil.convertObjectToJson(dataBricksResponse));
            var result = Optional.ofNullable(dataBricksResponse.getStatus()).map(DataBricksResponse.Status::getState)
                    .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getManifest()))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getResult()))
                    .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));
            log.info("Response from Data Lake Client for  Hospital Data {} ", result);
            if (Objects.nonNull(dataBricksResponse.getResult().getDataArray())) {
                for (var list : dataBricksResponse.getResult().getDataArray()) {
                    log.info("PMS data fetched from : {} to : {} Data : {}", startTime, endTime, list);
                    HospitalDetail details = mapRowToHospitalDetails(list);
                    response.add(details);
                }
            }
        } catch (Exception exception) {
            log.error("Error while fetching pms updated data for start: {}, end : {} ", startTime, endTime, exception);
            throw new MatrixDataSyncException(FAILURE_WHILE_FETCHING_DATA_FROM_DATABRICKS);
        }
        return response;
    }

    @Override
    public List<MatrixDocumentDetail> getUpdatedhospitalDocumentData(String endTime, String startTime) {
        var response = new ArrayList<MatrixDocumentDetail>();
        var statementIDRequest = new StatementIDRequest();
        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID_BATCH.name()));
        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
        log.info("Request received to call pms update query with startTime: {} , endTime: {}", startTime, endTime);
        try {
            String query = envVariablesService.getValueByKey(PMS_UPDATED_HOSPITAL_DOCUMENT_QUERY.name()).replace("{currentTime}", endTime)
                    .replace("{oneHourAgoTime}", startTime);
            statementIDRequest.setStatement(query);
            var dataBricksResponse = dataLakeClient.getDataBricksResponse(statementIDRequest);
            log.info("Response received from Datalake for executing query for fetching hospital document data :{}", ObjectMapperUtil.convertObjectToJson(dataBricksResponse));
            var result = Optional.ofNullable(dataBricksResponse.getStatus()).map(DataBricksResponse.Status::getState)
                    .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getManifest()))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getResult()))
                    .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));
            log.info("Response from Data Lake Client for  Hospital Data {} ", result);
            if (Objects.nonNull(dataBricksResponse.getResult().getDataArray())) {
                for (var list : dataBricksResponse.getResult().getDataArray()) {
                    log.info("PMS document fetched from : {} to : {} Data : {}", startTime, endTime, list);
                    MatrixDocumentDetail matrixDocumentDetail = mapRowToHospitalDocumentDetails(list);
                    response.add(matrixDocumentDetail);
                }
            }
        } catch (Exception exception) {
            log.error("Error while fetching pms updated data for start: {}, end : {} ", startTime, endTime, exception);
            throw new MatrixDataSyncException(FAILURE_WHILE_FETCHING_DATA_FROM_DATABRICKS);
        }
        return response;
    }

    @Override
    public List<MatrixPackageDetail> getUpdatedHospitalPackageData(String endTime, String startTime) {
        var response = new ArrayList<MatrixPackageDetail>();
        var statementIDRequest = new StatementIDRequest();
        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID_BATCH.name()));
        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
        log.info("Request received to call pms update query with startTime: {} , endTime: {}", startTime, endTime);
        try {
            String query = envVariablesService.getValueByKey(PMS_UPDATED_HOSPITAL_PACKAGE_QUERY.name()).replace("{currentTime}", endTime)
                    .replace("{oneHourAgoTime}", startTime);
            statementIDRequest.setStatement(query);
            var dataBricksResponse = dataLakeClient.getDataBricksResponse(statementIDRequest);
            log.info("Response received from Datalake for executing query for fetching hospital package data :{}", ObjectMapperUtil.convertObjectToJson(dataBricksResponse));
            var result = Optional.ofNullable(dataBricksResponse.getStatus()).map(DataBricksResponse.Status::getState)
                    .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getManifest()))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getResult()))
                    .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));
            log.info("Response from Data Lake Client for  Hospital Data {} ", result);
            if (Objects.nonNull(dataBricksResponse.getResult().getDataArray())) {
                for (var list : dataBricksResponse.getResult().getDataArray()) {
                    log.info("PMS package data fetched from : {} to : {} Data : {}", startTime, endTime, list);
                    MatrixPackageDetail matrixPackageDetail = mapRowToHospitalPackageDetails(list);
                    response.add(matrixPackageDetail);
                }
            }
        } catch (Exception exception) {
            log.error("Error while fetching pms updated data for start: {}, end : {} ", startTime, endTime, exception);
            throw new MatrixDataSyncException(FAILURE_WHILE_FETCHING_DATA_FROM_DATABRICKS);
        }
        return response;
    }

    @Override
    public List<PolicyDataResponse> getUpdatedMinimumPolicyDateData(String startIndex, String endIndex, LocalDate date) {
        String formattedDate = date.format(DateTimeFormatter.ISO_DATE);
        var response = new ArrayList<PolicyDataResponse>();
        var statementIDRequest = new StatementIDRequest();
        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID_BATCH.name()));
        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
        try {
            String query = envVariablesService.getValueByKey(POLICY_UPDATED_QUERY.name()).replace("{latestIndex}", String.valueOf(startIndex))
                    .replace("{nextIndex}", String.valueOf(endIndex)).replace("{reportDate}", formattedDate);
            statementIDRequest.setStatement(query);
            var dataBricksResponse = dataLakeClient.getDataBricksResponse(statementIDRequest);
            log.info("Response received from Datalake for executing query for fetching minimum policy data :{}", ObjectMapperUtil.convertObjectToJson(response));
            var result = Optional.ofNullable(dataBricksResponse.getStatus()).map(DataBricksResponse.Status::getState)
                    .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getManifest()))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getResult()))
                    .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));
            log.info("Response from Data Lake Client for Policy Data {} ", result);
            if (Objects.nonNull(dataBricksResponse.getResult().getDataArray())) {
                for (var list : dataBricksResponse.getResult().getDataArray()) {
                    log.info("UpdatedMinimumPolicyDateData fetched from : {} to : {} Data : {}",
                            startIndex, endIndex, list);
                    response.add(mapRowToPolicyDetails(list));
                }
            }
        } catch (Exception exception) {
            log.error("Error while fetching pms updated data for startIndex: {}, endIndex : {} and date : {}", startIndex, endIndex, date, exception);
            throw new MatrixDataSyncException(FAILURE_WHILE_FETCHING_DATA_FROM_DATABRICKS);
        }
        return response;
    }

    @Override
    public List<PolicyDataResponse> getOneTimeMinimumPolicyData(String startIndex, String endIndex) {
        var response = new ArrayList<PolicyDataResponse>();
        var statementIDRequest = new StatementIDRequest();
        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID.name()));
        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
        try {
            String query = envVariablesService.getValueByKey(ONE_TIME_POLICY_UPDATED_QUERY.name()).replace("{latestIndex}", String.valueOf(startIndex))
                    .replace("{nextIndex}", String.valueOf(endIndex));
            statementIDRequest.setStatement(query);
            var dataBricksResponse = dataLakeClient.getDataBricksResponse(statementIDRequest);
            log.info("Response received from Datalake for executing query for fetching minimum policy data :{}", ObjectMapperUtil.convertObjectToJson(response));
            var result = Optional.ofNullable(dataBricksResponse.getStatus()).map(DataBricksResponse.Status::getState)
                    .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getManifest()))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getResult()))
                    .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));
            log.info("Response from Data Lake Client for Policy Data {} ", result);
            if (Objects.nonNull(dataBricksResponse.getResult().getDataArray())) {
                for (var list : dataBricksResponse.getResult().getDataArray()) {
                    log.info("OneTimeMinimumPolicyData fetched from : {} to : {} Data : {}", startIndex, endIndex, list);
                    response.add(mapRowToPolicyDetails(list));
                }
            }
        } catch (Exception exception) {
            log.error("Error while fetching data from datalake for startIndex: {}, endIndex : {} ", startIndex, endIndex, exception);
            throw new MatrixDataSyncException(FAILURE_WHILE_FETCHING_DATA_FROM_DATABRICKS);
        }
        return response;
    }

//    @Override
//    public List<RenewalQuoteEncrypt> getRenewQuoteData(String startIndex, String endIndex,
//                                                    LocalDate date) {
//        String formattedDate = date.format(DateTimeFormatter.ISO_DATE);
//        var response = new ArrayList<RenewalQuoteEncrypt>();
//        var statementIDRequest = new StatementIDRequest();
//        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID_BATCH.name()));
//        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
//        log.info("Request received to call renew policy update query with startIndex: {} , endIndex: {}", startIndex, endIndex);
//        try {
//            String query = envVariablesService.getValueByKey(ZOHO_RENEW_QUOTE_QUERY.name())
//                    .replace("{reportDate}", formattedDate)
//                    .replace("{latestIndex}", startIndex)
//                    .replace("{nextIndex}", endIndex);
//            statementIDRequest.setStatement(query);
//            var dataBricksResponse = dataLakeClient.getCRMDataBricksResponse(statementIDRequest);
//            log.info("Response received from Datalake for executing query for fetching renew policy data :{}", ObjectMapperUtil.convertObjectToJson(dataBricksResponse));
//            var result = Optional.ofNullable(dataBricksResponse.getStatus()).map(DataBricksResponse.Status::getState)
//                    .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
//                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getManifest()))
//                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getResult()))
//                    .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));
//            log.info("Response from Data Lake Client for renew policy Data {} ", result);
//            if (Objects.nonNull(dataBricksResponse.getResult().getDataArray())) {
//                for (var list : dataBricksResponse.getResult().getDataArray()) {
//                    log.info("Renew policy data fetched from : {} to : {} Data : {}", startIndex, endIndex, list);
//                    RenewalQuoteEncrypt details = mapRowToRenewQuoteDetails(list);
//                    response.add(details);
//                }
//            }
//        } catch (Exception exception) {
//            log.error("Error while fetching renew policy data for start: {}, end : {} ", startIndex, endIndex, exception);
//            throw new MatrixDataSyncException(FAILURE_WHILE_FETCHING_DATA_FROM_DATABRICKS);
//        }
//        return response;
//    }
@Override
public List<RenewalQuoteEncrypt> getRenewQuoteData(String startIndex, String endIndex, LocalDate date) {
    log.info("Dummy implementation called for renew policy update query with startIndex: {} , endIndex: {}", startIndex, endIndex);

    List<RenewalQuoteEncrypt> response = new ArrayList<>();

    try {
        // Build a dummy DataBricksResponse
        DataBricksResponse dataBricksResponse = new DataBricksResponse();

        DataBricksResponse.Status status = new DataBricksResponse.Status();
        status.setState("SUCCEEDED");
        dataBricksResponse.setStatus(status);

        DataBricksResponse.Manifest manifest = new DataBricksResponse.Manifest();
        manifest.setFormat("JSON_ARRAY");
        manifest.setTotalRowCount(2);
        manifest.setTotalChunkCount(1);
        manifest.setTruncated(false);

        DataBricksResponse.Manifest.Schema schema = new DataBricksResponse.Manifest.Schema();
        schema.setColumnCount(89);
        manifest.setSchema(schema);

        dataBricksResponse.setManifest(manifest);

        DataBricksResponse.Result result = new DataBricksResponse.Result();
        result.setChunkIndex(0);
        result.setRowOffset(0);
        result.setRowCount(2);

        List<List<Object>> dataArray = new ArrayList<>();

        // Dummy row 1
        List<Object> row1 = Arrays.asList(
                null,
                "EncryptedKey1",
                0,
                "EncryptedKey2",
                "2020-04-26",
                "2021-05-25",
                "700001",
                "HSCRIND3",
                "BANCS",
                "ONLINE",
                "P/700001/01/2021/003445",
                3240.0,
                "OD700001",
                "SO700001",
                3240.0,
                "Senior Citizens Red Carpet Insurance - 2018"
        );

        // Dummy row 2
        List<Object> row2 = Arrays.asList(
                null,
                null,
                0,
                "EncryptedKey3",
                "2021-03-31",
                "2022-07-28",
                "111130",
                "HFHOSTD5",
                "BANCS",
                "ONLINE",
                "P/111130/01/2021/002589",
                5150.0,
                "SD111130",
                "SH6600",
                6666.0,
                "Family Health Optima Insurance Plan - 2021"
        );

        dataArray.add(row1);
        dataArray.add(row2);

        result.setDataArray(dataArray);
        dataBricksResponse.setResult(result);

        // Map dummy rows to your domain object
        for (var list : dataBricksResponse.getResult().getDataArray()) {
            RenewalQuoteEncrypt details = mapRowToRenewQuoteDetails(list);
            response.add(details);
        }

    } catch (Exception exception) {
        log.error("Error while building dummy renew policy data for start: {}, end : {}", startIndex, endIndex, exception);
        throw new MatrixDataSyncException(MatrixErrorCode.valueOf("FAILURE_WHILE_FETCHING_DUMMY_DATA"));
    }

    return response;
}
    @Override
    public boolean closeDataLakeConnection() {
        boolean response = false;
        try {
            response = dataLakeClient.stopDBConnection();
        } catch (Exception exception) {
            log.error("Error while stopping the connection ", exception);
        }
        return response;
    }

    private ClaimDocument toClaimDocument(PostgresClaimDocument postgresDoc) {
        if (postgresDoc == null) {
            return null;
        }

        ClaimDocument claimDoc = new ClaimDocument();
        claimDoc.setIntimationNumber(postgresDoc.getIntimationNumber());
        claimDoc.setDocumentName(postgresDoc.getDocumentName());
        claimDoc.setDocumentToken(postgresDoc.getDocumentToken());
        claimDoc.setDocumentType(postgresDoc.getDocumentType());
        claimDoc.setDocumentSource(postgresDoc.getDocumentSource());
        return claimDoc;
    }

    private List<ClaimDocumentSummary> groupByPolicyClaimDocuments(List<ClaimDocument> claimDocuments) {
        return claimDocuments.stream().collect(Collectors.groupingBy(ClaimDocument::getIntimationNumber)).entrySet()
                .stream().map(entry -> {
                    String intimationNumber = entry.getKey();
                    var summary = new ClaimDocumentSummary();
                    summary.setIntimationNumber(intimationNumber);
                    summary.setClaimDocuments(entry.getValue());
                    return summary;
                }).toList();
    }

    private List<ClaimHistorySummary> groupByPolicyClaimHistory(List<ClaimHistory> claimHistories) {
        return claimHistories.stream().collect(Collectors.groupingBy(ClaimHistory::getPolicyNumber)).entrySet().stream()
                .map(entry -> {
                    String policyNo = entry.getKey();
                    var summary = new ClaimHistorySummary();
                    summary.setPolicyNumber(policyNo);
                    summary.setClaimHistories(entry.getValue());
                    return summary;
                }).toList();
    }

    private ClaimHistory mapToClaimHistory(PostgresClaimHistory postgres) {
        ClaimHistory common = new ClaimHistory();
        common.setPolicyNumber(String.valueOf(postgres.getPolicyNumber()));
        common.setHealthId(String.valueOf(postgres.getHeathId()));
        common.setPolicyYear(String.valueOf(postgres.getPolicyYear()));
        common.setClaimNumber(String.valueOf(postgres.getClaimNumber()));
        common.setClaimType(String.valueOf(postgres.getClaimType()));
        common.setIntimationNumber(String.valueOf(postgres.getIntimationNumber()));
        common.setPatientName(String.valueOf(postgres.getPatientName()));
        common.setDiagnosis(String.valueOf(postgres.getDiagnosis()));
        common.setAdmissionDate(String.valueOf(postgres.getAdmissionDate()));
        common.setClaimStatus(String.valueOf(postgres.getClaimStatus()));
        common.setClaimedAmount(String.valueOf(postgres.getClaimedAmount()));
        common.setSiRestrictionFlag(String.valueOf(postgres.getSiRestrictionFlag()));
        common.setApprovedAmount(String.valueOf(postgres.getApprovedAmount()));
        common.setCopay(String.valueOf(postgres.getCopay()));
        common.setHospitalName(String.valueOf(postgres.getHospitalName()));
        common.setPedName(String.valueOf(postgres.getPedName()));
        common.setIcdCode(String.valueOf(postgres.getIcdCode()));
        common.setSublimitCategory(String.valueOf(postgres.getSublimitCategory()));
        common.setSurrogacyOocyteCover(String.valueOf(postgres.getSurrogacyOocyteCover()));
        common.setCataractDetails(String.valueOf(postgres.getCataractDetails()));
        common.setSublimitName(String.valueOf(postgres.getSublimitName()));
        common.setSublimitAmount(String.valueOf(postgres.getSublimitAmont()));
        return common;
    }

    public PolicyDetail toPolicyDetail(PostgresPolicyDetail postgresDetail) {
        PolicyDetail policyDetail = new PolicyDetail();

        policyDetail.setPolicyNo(String.valueOf(postgresDetail.getPolicyNo()));
        policyDetail.setPolicyFromDate(String.valueOf(postgresDetail.getPolicyFromDate()));
        policyDetail.setPolicyToDate(String.valueOf(postgresDetail.getPolicyToDate()));
        policyDetail.setUwYear(String.valueOf(postgresDetail.getUwYear()));
        policyDetail.setPolicySumInsured(postgresDetail.getPolicySumInsured());
        policyDetail.setPreviousPolicyNo(String.valueOf(postgresDetail.getPreviousPolicyNo()));
        policyDetail.setInsuredName(String.valueOf(postgresDetail.getInsuredName()));
        policyDetail.setGender(String.valueOf(postgresDetail.getGender()));
        policyDetail.setDob(String.valueOf(postgresDetail.getDob()));
        policyDetail.setRelation(String.valueOf(postgresDetail.getRelation()));
        policyDetail.setMemberSumInsured(postgresDetail.getMemberSumInsured());
        policyDetail.setPed(String.valueOf(postgresDetail.getPed()));
        policyDetail.setHealthId(String.valueOf(postgresDetail.getHealthId()));
        policyDetail.setPolicyInceptionDate(String.valueOf(postgresDetail.getPolicyInceptionDate()));
        policyDetail.setPolicyType(String.valueOf(postgresDetail.getPolicyType()));
        policyDetail.setEffectiveFrom(String.valueOf(postgresDetail.getEffectiveFrom()));
        policyDetail.setEffectiveTo(String.valueOf(postgresDetail.getEffectiveTo()));
        policyDetail.setInsuredInceptionDate(String.valueOf(postgresDetail.getInsuredInceptionDate()));
        policyDetail.setProductName(String.valueOf(postgresDetail.getProductName()));

        return policyDetail;
    }

    private static ClaimDocument getPolicyClaimDocument(List<Object> list) {
        var claimDocument = new ClaimDocument();
        claimDocument.setIntimationNumber(String.valueOf(list.get(0)));
        claimDocument.setDocumentName(String.valueOf(list.get(1)));
        claimDocument.setDocumentToken(String.valueOf(list.get(2)));
        claimDocument.setDocumentType(String.valueOf(list.get(3)));
        claimDocument.setDocumentSource(String.valueOf(list.get(4)));
        return claimDocument;
    }

    private static ClaimHistory getPolicyClaimHistoryDetail(List<Object> list) {
        var claimHistory = new ClaimHistory();
        claimHistory.setPolicyNumber(String.valueOf(list.get(0)));
        claimHistory.setHealthId(String.valueOf(list.get(1)));
        claimHistory.setPolicyYear(String.valueOf(list.get(2)));
        claimHistory.setClaimNumber(String.valueOf(list.get(3)));
        claimHistory.setClaimType(String.valueOf(list.get(4)));
        claimHistory.setIntimationNumber(String.valueOf(list.get(5)));
        claimHistory.setPatientName(String.valueOf(list.get(6)));
        claimHistory.setDiagnosis(String.valueOf(list.get(7)));
        claimHistory.setAdmissionDate(String.valueOf(list.get(8)));
        claimHistory.setClaimStatus(String.valueOf(list.get(9)));
        claimHistory.setClaimedAmount(String.valueOf(list.get(10)));
        claimHistory.setSiRestrictionFlag(String.valueOf(list.get(11)));
        claimHistory.setApprovedAmount(String.valueOf(list.get(12)));
        claimHistory.setCopay(String.valueOf(list.get(13)));
        claimHistory.setHospitalName(String.valueOf(list.get(14)));
        claimHistory.setPedName(String.valueOf(list.get(15)));
        claimHistory.setIcdCode(String.valueOf(list.get(16)));
        claimHistory.setSublimitCategory(String.valueOf(list.get(17)));
        claimHistory.setSurrogacyOocyteCover(String.valueOf(list.get(18)));
        claimHistory.setCataractDetails(String.valueOf(list.get(19)));
        claimHistory.setSublimitName(String.valueOf(list.get(20)));
        claimHistory.setSublimitAmount(String.valueOf(list.get(21)));
        return claimHistory;
    }

    private static PolicyDocument getPolicyDocumentDetail(List<Object> list) {
        var policyDocument = new PolicyDocument();
        policyDocument.setPolicyNo(String.valueOf(list.get(0)));
        policyDocument.setProposalNo(String.valueOf(list.get(1)));
        policyDocument.setDocumentType(String.valueOf(list.get(2)));
        policyDocument.setDocumentName(String.valueOf(list.get(3)));
        policyDocument.setDocumentSource(String.valueOf(list.get(4)));
        policyDocument.setApiDocumentType(String.valueOf(list.get(5)));
        return policyDocument;
    }

    public PolicyDocument toPolicyDocument(PostgresPolicyDocument postgresDocument) {
        PolicyDocument policyDocument = new PolicyDocument();

        policyDocument.setPolicyNo(String.valueOf(postgresDocument.getPolicyNo()));
        policyDocument.setProposalNo(String.valueOf(postgresDocument.getProposalNo()));
        policyDocument.setDocumentType(String.valueOf(postgresDocument.getDocumentType()));
        policyDocument.setDocumentName(String.valueOf(postgresDocument.getDocumentName()));
        policyDocument.setDocumentSource(String.valueOf(postgresDocument.getDocumentSource()));
        policyDocument.setApiDocumentType(String.valueOf(postgresDocument.getApiDocumentType()));

        return policyDocument;
    }

    public List<PolicyDocumentSummary> groupByPolicyDocument(List<PolicyDocument> policyDocuments) {
        return policyDocuments.stream().collect(Collectors.groupingBy(PolicyDocument::getPolicyNo)).entrySet().stream()
                .map(entry -> {
                    String policyNo = entry.getKey();
                    List<PolicyDocument> details = entry.getValue();
                    var summary = new PolicyDocumentSummary();
                    summary.setPolicyNo(policyNo);
                    List<PolicyDocumentSummary.DocumentDetail> members = details.stream().map(detail -> {
                        var documentDetail = new PolicyDocumentSummary.DocumentDetail();
                        documentDetail.setDocumentName(detail.getDocumentName());
                        documentDetail.setDocumentType(detail.getDocumentType());
                        documentDetail.setDocumentSource(detail.getDocumentSource());
                        documentDetail.setProposalNo(detail.getProposalNo());
                        documentDetail.setApiDocumentType(detail.getApiDocumentType());
                        return documentDetail;
                    }).toList();
                    summary.setDocumentDetails(members);
                    return summary;
                }).toList();
    }

    public List<PolicyMemberDetailSummary> groupByPolicyNo(List<PolicyDetail> policyDetails) {
        return policyDetails.stream().collect(Collectors.groupingBy(PolicyDetail::getPolicyNo)).entrySet().stream()
                .map(entry -> {
                    List<PolicyDetail> details = entry.getValue();
                    PolicyDetail policyDetail = details.getFirst();
                    var summary = new PolicyMemberDetailSummary();
                    summary.setPolicyNo(policyDetail.getPolicyNo());
                    summary.setPolicyFromDate(policyDetail.getPolicyFromDate());
                    summary.setPolicyToDate(policyDetail.getPolicyToDate());
                    summary.setUwYear(policyDetail.getUwYear());
                    summary.setSumInsured(policyDetail.getPolicySumInsured());
                    summary.setProductName(policyDetail.getProductName());
                    summary.setPreviousPolicyNo(policyDetail.getPreviousPolicyNo());
                    summary.setPolicySource(""); // Set this value as needed
                    summary.setPolicyInceptionDate(policyDetail.getPolicyInceptionDate());
                    summary.setPolicyType(policyDetail.getPolicyType());
                    List<PolicyMemberDetailSummary.Member> members = details.stream().map(detail -> {
                        var member = new PolicyMemberDetailSummary.Member();
                        member.setInsuredName(detail.getInsuredName());
                        member.setHealthId(detail.getHealthId());
                        member.setGender(detail.getGender());
                        member.setDob(detail.getDob());
                        member.setRelation(detail.getRelation());
                        member.setSumInsured(detail.getMemberSumInsured());
                        member.setPed(detail.getPed());
                        member.setEffectiveFrom(detail.getEffectiveFrom());
                        member.setEffectiveTo(detail.getEffectiveTo());
                        member.setInsuredInceptionDate(detail.getInsuredInceptionDate());
                        return member;
                    }).toList();
                    summary.setMembers(members);
                    return summary;
                }).toList();
    }

    private static PolicyDetail getPolicyDetail(List<Object> list) {
        var policyDetail = new PolicyDetail();
        policyDetail.setPolicyNo(String.valueOf(list.get(0)));
        policyDetail.setPolicyFromDate(String.valueOf(list.get(1)));
        policyDetail.setPolicyToDate(String.valueOf(list.get(2)));
        policyDetail.setUwYear(String.valueOf(list.get(3)));
        policyDetail.setPolicySumInsured(String.valueOf(list.get(4)));
        policyDetail.setPreviousPolicyNo(String.valueOf(list.get(5)));
        policyDetail.setInsuredName(String.valueOf(list.get(6)));
        policyDetail.setGender(String.valueOf(list.get(7)));
        policyDetail.setDob(String.valueOf(list.get(8)));
        policyDetail.setRelation(String.valueOf(list.get(9)));
        policyDetail.setMemberSumInsured(String.valueOf(list.get(10)));
        policyDetail.setPed(String.valueOf(list.get(11)));
        policyDetail.setHealthId(String.valueOf(list.get(12)));
        policyDetail.setPolicyInceptionDate(String.valueOf(list.get(13)));
        policyDetail.setPolicyType(String.valueOf(list.get(14)));
        policyDetail.setEffectiveFrom(String.valueOf(list.get(15)));
        policyDetail.setEffectiveTo(String.valueOf(list.get(16)));
        policyDetail.setInsuredInceptionDate(String.valueOf(list.get(17)));
        policyDetail.setProductName(String.valueOf(list.get(18)));
        return policyDetail;
    }

    private MatrixPackageDetail mapRowToHospitalPackageDetails(List<Object> row) {
        MatrixPackageDetail matrixPackageDetail = new MatrixPackageDetail();
        log.info("Inside the mapRowToHospitalDetails Method");
        matrixPackageDetail.setShaiHospitalId(getSafe(row, 0));
        matrixPackageDetail.setPackageName(getSafe(row, 1));
        matrixPackageDetail.setPackageStartdate(getSafe(row, 2));
        matrixPackageDetail.setPackageExpirydate(getSafe(row, 3));
        matrixPackageDetail.setPcs(getSafe(row, 4));
        matrixPackageDetail.setIcd(getSafe(row, 5));
        matrixPackageDetail.setRoomCategory(getSafe(row, 6));
        matrixPackageDetail.setPackageRate(getSafe(row, 7));
        matrixPackageDetail.setInclusions(getSafe(row, 8));
        matrixPackageDetail.setExclusions(getSafe(row, 9));
        matrixPackageDetail.setLos(getSafe(row, 10));
        matrixPackageDetail.setRemarks(getSafe(row, 11));
        matrixPackageDetail.setInsurerProcedureCode(getSafe(row, 12));
        matrixPackageDetail.setProcedureMapping(getSafe(row, 13));
        return matrixPackageDetail;
    }

    private MatrixDocumentDetail mapRowToHospitalDocumentDetails(List<Object> row) {
        MatrixDocumentDetail matrixDocumentDetail = new MatrixDocumentDetail();
        log.info("Inside the mapRowToHospitalDetails Method");
        matrixDocumentDetail.setShaiHospitalId(getSafe(row, 0));
        matrixDocumentDetail.setDocumentID(getSafe(row, 1));
        matrixDocumentDetail.setDocumentType(getSafe(row, 2));
        return matrixDocumentDetail;
    }

    private HospitalDetail mapRowToHospitalDetails(List<Object> row) {
        HospitalDetail details = new HospitalDetail();
        log.info("Inside the mapRowToHospitalDetails Method");

        details.setShaiHospitalId(getSafe(row, 0));
        details.setHospitalName(getSafe(row, 1));
        details.setHospitalAddr1(getSafe(row, 2));
        details.setHospitalAddr2(getSafe(row, 3));
        details.setHospitalCityId(getSafe(row, 4));
        details.setHospitalPincode(getSafe(row, 5));
        details.setHospitalContact(getSafe(row, 6));
        details.setHospitalPhone(getSafe(row, 7));
        details.setHospitalIsActive(getBooleanSafe(row, 8));
        details.setHospitalWebsite(getSafe(row, 9));
        details.setHospitalEmail(getSafe(row, 10));
        details.setHospitalPayableToName(getSafe(row, 11));
        details.setHospitalIsPpn(getBooleanSafe(row, 12));
        details.setHospitalStdCode(getSafe(row, 13));
        details.setHospIsFaxUpdated(getSafe(row, 14));
        details.setHospitalState(getSafe(row, 15));
        details.setHospitalDistrict(getSafe(row, 16));
        details.setHospitalRegistrationCode(getSafe(row, 17));
        details.setRohiniCode(getSafe(row, 18));
        details.setLatitude(getSafe(row, 19));
        details.setLongitude(getSafe(row, 20));
        details.setCpuCode(getSafe(row, 22));
        details.setEpdPercentage(getSafe(row, 23));
        details.setEpdStartDate(getSafe(row, 24));
        details.setEpdEndDate(getSafe(row, 25));
        details.setEpdAgreedDays(getSafe(row, 26));
        details.setIsNetworkHospital(getBooleanSafe(row, 27));
        details.setEmpanelmentStartDate(getSafe(row, 28));
        details.setEmpanelmentEndDate(getSafe(row, 29));
        details.setAccountHolderName(getSafe(row, 30));
        details.setAccountNumber(getSafe(row, 31));
        details.setIfscCode(getSafe(row, 32));
        details.setHospitalGstinNo(getSafe(row, 33));
        details.setHospitalTanNumber(getSafe(row, 34));
        details.setHospitalPanNumber(getSafe(row, 35));
        details.setHospHfrCode(getSafe(row, 36));
        details.setDiscountRemarks(getSafe(row, 37));
        details.setIsBlacklisted(getBooleanSafe(row, 39));
        details.setIsCaution(getBooleanSafe(row, 40));
        details.setBedCount(getSafe(row, 41));
        details.setSpecialityType(getSafe(row, 42));
        DiscountDetails discountDetails = new DiscountDetails();
        Double discount = getDoubleSafe(row, 38);
        if (discount != null) {
            discountDetails.setClaimAmountPercentage(discount);
        }
        List<HospitalFlag> hospitalFlags = new ArrayList<>();
        Optional.ofNullable(getSafe(row, 43))
                .ifPresent(flag -> {
                    if(flag.equalsIgnoreCase(HOSPITAL_FLAG_PRESENT)){
                        HospitalFlag suspiciousFlagDetail = new HospitalFlag();
                        suspiciousFlagDetail.setFlag(HospitalFlagName.SUSPICIOUS);
                        suspiciousFlagDetail.setDate(getSafe(row, 44));
                        suspiciousFlagDetail.setReason(getSafe(row, 45));
                        hospitalFlags.add(suspiciousFlagDetail);
                    }
                });
        Optional.ofNullable(getSafe(row, 46))
                .ifPresent(flag ->{
                    if(flag.equalsIgnoreCase(HOSPITAL_FLAG_PRESENT)){
                        HospitalFlag rawFlagDetail = new HospitalFlag();
                        rawFlagDetail.setFlag(HospitalFlagName.RAW);
                        rawFlagDetail.setReason(getSafe(row, 47));
                        hospitalFlags.add(rawFlagDetail);
                    }
                });

        Optional.ofNullable(getSafe(row, 48))
                .ifPresent(flag ->{
                    if (flag.equalsIgnoreCase(HOSPITAL_FLAG_PRESENT)){
                        HospitalFlag excludedFlagDetail = new HospitalFlag();
                        excludedFlagDetail.setFlag(HospitalFlagName.EXCLUDED);
                        excludedFlagDetail.setDate(getSafe(row, 49));
                        excludedFlagDetail.setReason(getSafe(row, 50));
                        hospitalFlags.add(excludedFlagDetail);
                    }
                });

        details.setHospitalFlag(hospitalFlags);
        details.setPrathamFlag(getSafe(row, 51));
        details.setHospitalGrade(getSafe(row, 52));
        details.setSocFlag(getSafe(row, 53));
        details.setNetworkHospType(getSafe(row, 54));
        log.info("PMS Hospital Details Received for -HospitalId --{}", details.getShaiHospitalId());
        return details;
    }

    private PolicyDataResponse mapRowToPolicyDetails(List<Object> row) {
        log.info("Inside the mapRowToPolicyDetails Method");
        PolicyDetails details = new PolicyDetails();
        details.setPolicyNumber(getSafe(row, 0));
        details.setPolicyType(getSafe(row, 1));
        details.setIssuingOfficeNumber(getSafe(row, 2));
        details.setProductCode(getSafe(row, 3));
        details.setPolicyStartDate(getSafe(row, 4));
        details.setPolicyEndDate(getSafe(row, 5));
        details.setProposerPolicyHolder(getSafe(row, 6));
        details.setPolicyHolderPinCode(getSafe(row, 7));
        details.setPreviousYearPolicyNumber(getSafe(row, 8));
        details.setPolicyStatus(getSafe(row, 9));
        details.setFloaterSumInsured(getSafe(row, 10));
        List<BeneficiariesInfo> beneficiariesInfoList = new ArrayList<>();
        String beneficiaryJson = getSafe(row, 11);
        try {
            if (beneficiaryJson != null) {
                List<BeneficiariesInfo> discounts = ObjectMapperUtil.convertJsonToObject(beneficiaryJson, new TypeReference<List<BeneficiariesInfo>>() {
                }).stream().filter(doc -> doc.getInsurerBeneficiaryUniqueID() != null).toList();
                if (!discounts.isEmpty()) {
                    beneficiariesInfoList.addAll(discounts);
                }
            }
        } catch (Exception e) {
            log.error("Error while parsing beneficiary details: {} for row : {}", beneficiaryJson, row);
        }
        PolicyDataResponse response = new PolicyDataResponse();
        response.setPolicyInfo(details);
        response.setBeneficiaryInfo(beneficiariesInfoList);
        log.info("Policy Details Received for - PolicyId --{}", details.getPolicyNumber());
        return response;
    }

    private String getInClauseForPolicyNumber(Set<String> policyNumbers){
        Set<String> uniquePolicyNumbers = policyNumbers.stream()
                .filter(p -> p != null && !p.trim().isEmpty())
                .collect(Collectors.toSet());

        String inClause = uniquePolicyNumbers.stream()
                .map(p -> "'" + p + "'")
                .collect(Collectors.joining(", "));
        return inClause;
    }

    private RenewalQuoteEncrypt mapRowToRenewQuoteDetails(List<Object> row) {
        log.info("Inside the mapRowToRenewQuoteDetails Method : {}", row);

        RenewalQuoteEncrypt quoteEncrypt = new RenewalQuoteEncrypt();
        quoteEncrypt.setIntermediatorEmailE(getSafe(row, 1));
        quoteEncrypt.setNumberOfYear(getIntegerSafe(row, 2));
        quoteEncrypt.setProposerEmailIdE(getSafe(row, 3));
        quoteEncrypt.setPolicyFromDate(getSafe(row, 4));
        quoteEncrypt.setGracePeriodEndDate(getSafe(row, 5));
        quoteEncrypt.setPremiaConvertedPolicyTotalPremium(getSafe(row, 6));
        quoteEncrypt.setSalesManagerPhoneE(getSafe(row, 7));
        quoteEncrypt.setInstallmentPremiumAmount(getSafe(row, 8));
        quoteEncrypt.setOfficeCode(getSafe(row, 9));

        quoteEncrypt.setProductCode(getSafe(row, 10));
        quoteEncrypt.setBranchManagerName(getSafe(row, 11));
        quoteEncrypt.setPaymentDate(getSafe(row, 12));
        quoteEncrypt.setInstallmentTax(getSafe(row, 13));
        quoteEncrypt.setSource(getSafe(row, 14));
        quoteEncrypt.setProposalType(getSafe(row, 15));
        quoteEncrypt.setPreviousPolicyNumber(getSafe(row, 16));
        quoteEncrypt.setCurrencyPolicyPremiumGst(getSafe(row, 17));
        quoteEncrypt.setRenewalPaymentType(getSafe(row, 18));
        quoteEncrypt.setIntermediaryCode(getSafe(row, 19));
        quoteEncrypt.setFulfillerCode(getSafe(row, 20));
        quoteEncrypt.setCurrentPremiumTax(getSafe(row, 21));
        quoteEncrypt.setPinCode(getSafe(row, 22));
        quoteEncrypt.setPolicyConvertedDate(getSafe(row, 23));
        quoteEncrypt.setPremiaCurrentPolicySumInsured(getSafe(row, 24));
        quoteEncrypt.setRenewalStatus(getSafe(row, 25));
        quoteEncrypt.setInstallmentTotalPremium(getSafe(row, 26));
        quoteEncrypt.setNcb(getSafe(row, 27));
        quoteEncrypt.setIntermediaryName(getSafe(row, 28));
        quoteEncrypt.setBranchManagerPhNo(getSafe(row, 29));
        quoteEncrypt.setEnvironment(getSafe(row, 30));
        quoteEncrypt.setBranchManagerCode(getSafe(row, 31));
        quoteEncrypt.setIntermediatorPhoneE(getSafe(row, 32));
        quoteEncrypt.setSecondaryEmail(getSafe(row, 33));
        quoteEncrypt.setEmiPolicy(getSafe(row, 34));
        quoteEncrypt.setDivisonCode(getSafe(row, 35));
        quoteEncrypt.setRecordReceivedFromSystem(getSafe(row, 36));
        quoteEncrypt.setProposerContactNoE(getSafe(row, 37));
        quoteEncrypt.setRenewalLocation(getSafe(row, 38));
        quoteEncrypt.setWorkflowTrigger(getSafe(row, 39));
        quoteEncrypt.setPaymentStatus(getSafe(row, 40));
        quoteEncrypt.setRenewalId(getSafe(row, 41));
        quoteEncrypt.setPolicyToDate(getSafe(row, 42));
        quoteEncrypt.setRenewalPolicyRefNo(getSafe(row, 43));
        quoteEncrypt.setPolicyRenewed(getSafe(row, 44));
        quoteEncrypt.setPremiaCurrentPolicyNo(getSafe(row, 45));
        quoteEncrypt.setPaymentMode(getSafe(row, 46));
        quoteEncrypt.setInstallmentYear(getSafe(row, 47));
        quoteEncrypt.setSumInsured(getSafe(row, 48));
        quoteEncrypt.setCurrentPolicyPremiumTotalAmount(getSafe(row, 49));
        quoteEncrypt.setPremiaConvertedPremiumAmount(getSafe(row, 50));
        quoteEncrypt.setContactName(getSafe(row, 51));
        quoteEncrypt.setPremiaConvertedPolicyNo(getSafe(row, 52));
        quoteEncrypt.setPremiumAmount(getSafe(row, 53));
        quoteEncrypt.setClaimStatus(getSafe(row, 54));
        quoteEncrypt.setPremiaContactCode(getSafe(row, 55));
        quoteEncrypt.setCurrentPolicyPremiumAmount(getSafe(row, 56));
        quoteEncrypt.setCurrentPolicyNumber(getSafe(row, 57));
        quoteEncrypt.setProductName(getSafe(row, 58));
        quoteEncrypt.setCurrentPremiumTotal(getSafe(row, 59));
        quoteEncrypt.setPremiaConvertedPolicyGst(getSafe(row, 60));
        quoteEncrypt.setRenewalAddress3(getSafe(row, 61));
        quoteEncrypt.setRenewalAddress1(getSafe(row, 62));
        quoteEncrypt.setNcdIssued(getSafe(row, 63));
        quoteEncrypt.setSalesManagerName(getSafe(row, 64));
        quoteEncrypt.setNoOfInstallment(getSafe(row, 65));
        quoteEncrypt.setRenewalAddress2(getSafe(row, 66));

        quoteEncrypt.setUpsellSumInsured1(getSafe(row, 67));
        quoteEncrypt.setUpsellPremium1(getSafe(row, 68));
        quoteEncrypt.setUpsellGst1(getSafe(row, 69));
        quoteEncrypt.setUpsellTotal1(getSafe(row, 70));

        quoteEncrypt.setUpsellSumInsured2(getSafe(row, 71));
        quoteEncrypt.setUpsellPremium2(getSafe(row, 72));
        quoteEncrypt.setUpsellGst2(getSafe(row, 73));
        quoteEncrypt.setUpsellTotal2(getSafe(row, 74));

        quoteEncrypt.setUpsellSumInsured3(getSafe(row, 75));
        quoteEncrypt.setUpsellPremium3(getSafe(row, 76));
        quoteEncrypt.setUpsellGst3(getSafe(row, 77));
        quoteEncrypt.setUpsellTotal3(getSafe(row, 78));

        quoteEncrypt.setUpsellSumInsured4(getSafe(row, 79));
        quoteEncrypt.setUpsellPremium4(getSafe(row, 80));
        quoteEncrypt.setUpsellGst4(getSafe(row, 81));
        quoteEncrypt.setUpsellTotal4(getSafe(row, 82));

        quoteEncrypt.setUpsellSumInsured5(getSafe(row, 83));
        quoteEncrypt.setUpsellPremium5(getSafe(row, 84));
        quoteEncrypt.setUpsellGst5(getSafe(row, 85));
        quoteEncrypt.setUpsellTotal5(getSafe(row, 86));
        log.info("Renew policy Details Received for -RenewalPolicyRefNo --{}", quoteEncrypt.getRenewalPolicyRefNo());


        return quoteEncrypt;
    }

    private void addUpsell(List<UpsellPremiumRenewQuote> list, String sumInsuredObj, String premiumObj, String gstObj, String totalObj) {

        if (sumInsuredObj == null && premiumObj == null && gstObj == null && totalObj == null) return;
        UpsellPremiumRenewQuote upsellPremiumRenewQuote = new UpsellPremiumRenewQuote();
        upsellPremiumRenewQuote.setUpsellSumInsured(sumInsuredObj);
        upsellPremiumRenewQuote.setUpsellPremiumAmount(premiumObj);
        upsellPremiumRenewQuote.setGst(gstObj);
        upsellPremiumRenewQuote.setUpsellTotal(totalObj);
        list.add(upsellPremiumRenewQuote);
    }

    @Override
    public DataLakeResponseDto processIntimation(String intimation) {
        try {
            log.error("[DataLakeServiceImpl]- processIntimation() - request{}",intimation);
            String query = envVariablesService.getValueByKey(POSTGRES_INTIMATION_PROCESSING_SYSTEM_QUERY.name());
            List<DataLakeSourceEntity> entity = repository.findByIntimationNumber(intimation, query);
            log.info("ProcessingSystem responsev{}", entity);
            if(!CollectionUtils.isEmpty(entity)){
                return new DataLakeResponseDto(
                        entity.getFirst().getIntimationNumber(),
                        entity.getFirst().getProcessingApplication()
                );
            }else{
                throw new MatrixDataSyncException(CLAIM_NUMBER_IS_NOT_VALID);
            }
        } catch (Exception e) {
            log.error("[DataLakeServiceImpl]- processIntimation - Error while hitting intimation source {}",intimation);
            throw new MatrixDataSyncException(CLAIM_NUMBER_IS_NOT_VALID);
        }
    }

    public PolciyInsuredDetailsResponse getPolicyDetails(String policyNumber) {
        try {
            log.info("[DataLakeServiceImpl]- getCustomerDetails- Request received to call policy and member details for policy Number: {}", policyNumber);
            String query = envVariablesService.getValueByKey(POSTGRES_POLICY_DETAILS_QUERY.name());
            List<CustomerDetail> customerDetails = repository.findByPolicyNumber(policyNumber, query);
            log.info("[DataLakeServiceImpl]- getCustomerDetails- Response received from Postgres for executing policy and member data query for policy no :{}, {} ",
                    policyNumber, customerDetails);
            PolciyInsuredDetailsResponse polciyInsuredDetailsResponse = new PolciyInsuredDetailsResponse();
            if (!CollectionUtils.isEmpty(customerDetails)) {
                polciyInsuredDetailsResponse.setProposerName(customerDetails.getFirst().getProposerName());
                polciyInsuredDetailsResponse.setNumberOfAdult(customerDetails.getFirst().getAdultCount());
                polciyInsuredDetailsResponse.setNumberOfChildren(customerDetails.getFirst().getChildrenCount());
                polciyInsuredDetailsResponse.setPincode(customerDetails.getFirst().getProposerPincode());
                polciyInsuredDetailsResponse.setPlanType(customerDetails.getFirst().getPlanType());
                polciyInsuredDetailsResponse.setPolicyType(customerDetails.getFirst().getPolicyType());
                polciyInsuredDetailsResponse.setSumInsured(customerDetails.getFirst().getSumInsured());
                polciyInsuredDetailsResponse.setPremiumAmount(customerDetails.getFirst().getPremiumAmount());
                List<PolciyInsuredDetailsResponse.DetailsOfAdult> detailsOfAdults = new ArrayList<>();
                List<PolciyInsuredDetailsResponse.DetailsOfChildren> detailsOfChildren = new ArrayList<>();
                for (CustomerDetail customerDetail : customerDetails) {
                    if (customerDetail.getAgeType().equals("ADULT")) {
                        PolciyInsuredDetailsResponse.DetailsOfAdult detailsOfAdult = new PolciyInsuredDetailsResponse.DetailsOfAdult();
                        detailsOfAdult.setAge(customerDetail.getInsuredAge());
                        detailsOfAdult.setAdultName(customerDetail.getInsuredName());
                        detailsOfAdult.setHealthId(customerDetail.getHealthId());
                        detailsOfAdult.setSumInsured(customerDetail.getSumInsured());
                        if (StringUtils.hasText(customerDetail.getInsuredMobileNoE())) {
                            var insuredMobileNoE = fieldEncryptionService.decryptFieldString(customerDetail.getInsuredMobileNoE());
                            detailsOfAdult.setInsuredMobileNumber(insuredMobileNoE);
                        }
                        if (StringUtils.hasText(customerDetail.getProposerMobileNoE())) {
                            var proposerMobileNumber = fieldEncryptionService.decryptFieldString(customerDetail.getProposerMobileNoE());
                            detailsOfAdult.setProposerMobileNumber(proposerMobileNumber);
                        }
                        detailsOfAdults.add(detailsOfAdult);

                    } else if (customerDetail.getAgeType().equals("CHILDREN")) {
                        PolciyInsuredDetailsResponse.DetailsOfChildren detailsOfChild = new PolciyInsuredDetailsResponse.DetailsOfChildren();
                        detailsOfChild.setAge(customerDetail.getInsuredAge());
                        detailsOfChild.setChildName(customerDetail.getInsuredName());
                        detailsOfChild.setHealthId(customerDetail.getHealthId());
                        detailsOfChild.setSumInsured(customerDetail.getSumInsured());
                        if (StringUtils.hasText(customerDetail.getInsuredMobileNoE())) {
                            var insuredMobileNo = fieldEncryptionService.decryptFieldString(customerDetail.getInsuredMobileNoE());
                            detailsOfChild.setInsuredMobileNumber(insuredMobileNo);
                        }
                        if (StringUtils.hasText(customerDetail.getProposerMobileNoE())) {
                            var proposerMobileNo = fieldEncryptionService.decryptFieldString(customerDetail.getProposerMobileNoE());
                            detailsOfChild.setProposerMobileNumber(proposerMobileNo);
                        }
                        detailsOfChildren.add(detailsOfChild);
                    }
                }
                polciyInsuredDetailsResponse.setDetailsOfAdult(detailsOfAdults);
                polciyInsuredDetailsResponse.setDetailsOfChildren(detailsOfChildren);
                PolciyInsuredDetailsResponse.AgentDetails agentDetails = new PolciyInsuredDetailsResponse.AgentDetails();
                agentDetails.setAgentCode(customerDetails.getFirst().getAgentCode());
                agentDetails.setAgentName(customerDetails.getFirst().getAgentName());
                agentDetails.setAdvisorName(customerDetails.getFirst().getAdvisorName());
                agentDetails.setAdvisorContact(customerDetails.getFirst().getAdvisorContact());
                agentDetails.setIntermediaryType(customerDetails.getFirst().getIntermediaryType());
                final List<String> AGENT_TYPES = List.of("AGENT", "CORP-AGENT");
                String intermediaryType = customerDetails.getFirst().getIntermediaryType();
                boolean isAgent = true;
                if (StringUtils.hasText(intermediaryType)) {
                     isAgent = AGENT_TYPES.contains(intermediaryType);
                }
                if (isAgent) {
                    agentDetails.setAgentCode(customerDetails.getFirst().getAgentCode());
                    agentDetails.setAgentName(customerDetails.getFirst().getAgentName());
                    if (StringUtils.hasText(customerDetails.getFirst().getAgentMobileNoE())) {
                        String agentMobileNo =
                                fieldEncryptionService.decryptFieldString(
                                        customerDetails.getFirst().getAgentMobileNoE()
                                );
                        agentDetails.setAgentMobileNo(agentMobileNo);
                    }
                } else {
                    agentDetails.setAgentName(customerDetails.getFirst().getAdvisorName());
                    agentDetails.setAgentMobileNo(customerDetails.getFirst().getAdvisorContact());
                }
                polciyInsuredDetailsResponse.setAgentDetails(agentDetails);


                if (StringUtils.hasText(customerDetails.getFirst().getAgentMobileNoE())) {
                    var agentMobileNo = fieldEncryptionService.decryptFieldString(customerDetails.getFirst().getAgentMobileNoE());
                    agentDetails.setAgentMobileNo(agentMobileNo);
                }
                polciyInsuredDetailsResponse.setAgentDetails(agentDetails);
                return polciyInsuredDetailsResponse;
            } else {
                log.info("Customer details in Null");
                throw new MatrixDataSyncException(POLICY_NUMBER_IS_NOT_VALID);
            }
        } catch (Exception e) {
            log.error("[DataLakeServiceImpl]- getCustomerDetails - Error while getting the policy details for policyNumber{}, exception ", policyNumber, e);
            throw new MatrixDataSyncException(POLICY_NUMBER_IS_NOT_VALID);
        }
    }

    @Override
    public List<GroupPolicyData> getUpdatedGroupPolicyData(String startIndex, String endIndex,
                                                            LocalDate date){
        log.info("getUpdatedGroupPolicyData fetched from : {} to : {} Data : {}", startIndex, endIndex, date);
        String formattedDate = date.format(DateTimeFormatter.ISO_DATE);
        var response = new ArrayList<GroupPolicyDataResponse>();
        List<GroupPolicyData> groupPolicyData = new ArrayList<>();
        var statementIDRequest = new StatementIDRequest();
        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID_BATCH.name()));
        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
        try {
            String query = envVariablesService.getValueByKey(GROUP_POLICY_QUERY.name()).replace("{latestIndex}", String.valueOf(startIndex))
                    .replace("{nextIndex}", String.valueOf(endIndex)).replace("{reportDate}", formattedDate);
            statementIDRequest.setStatement(query);
            var dataBricksResponse = dataLakeClient.getDataBricksResponse(statementIDRequest);
            Optional.ofNullable(dataBricksResponse.getStatus()).map(DataBricksResponse.Status::getState)
                    .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getManifest()))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getResult()))
                    .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));

            if (Objects.nonNull(dataBricksResponse.getResult().getDataArray())) {
                log.info("Response size from Data Lake Client for Group Policy for startIndex {} :  {} ",
                        startIndex ,dataBricksResponse.getResult().getDataArray().size());
                for (var list : dataBricksResponse.getResult().getDataArray()) {
                    response.add(mapRowToGroupPolicyDetails(list));
                }
                log.info("Group Policy numbers found from DataLake : {} ", response.stream().map(GroupPolicyDataResponse::getPolicyNumber).toList());
            }
            groupPolicyData = transformToGroupPolicyData(response);
        } catch (Exception exception) {
            log.error("Error while getUpdatedGroupPolicyData startIndex: {}, endIndex : {} and date : {}", startIndex, endIndex, date, exception);
            throw new MatrixDataSyncException(FAILURE_WHILE_FETCHING_DATA_FROM_DATABRICKS);
        }
        return groupPolicyData;

    }

    private GroupPolicyDataResponse mapRowToGroupPolicyDetails(List<Object> row) {
        log.info("Mapping GroupPolicyDataResponse row | Position 0: {}", getSafe(row, 0));
        GroupPolicyDataResponse details = new GroupPolicyDataResponse();

        details.setPolicyNumber(getSafe(row, 0));
        details.setPolicyType(getSafe(row, 1));
        details.setIssuingOfficeNumber(getSafe(row, 2));
        details.setProductCode(getSafe(row, 3));

        details.setPolicyStartDate(getSafe(row, 4));
        details.setPolicyEndDate(getSafe(row, 5));

        details.setProposerPolicyHolder(getSafe(row, 6));
        details.setPolicyHolderPinCode(getSafe(row, 7));
        details.setPreviousYearPolicyNumber(getSafe(row, 8));
        details.setPolicyStatus(getSafe(row, 9));
        details.setSumInsured(parseLongSafe(getSafe(row, 10)));

        details.setName(getSafe(row, 11));
        details.setEmployeeCode(getSafe(row, 12));
        details.setDateOfJoining(getSafe(row, 13));
        details.setFloaterSumInsured(parseLongSafe(getSafe(row, 14)));
        details.setGrade(getSafe(row, 15));
        details.setInsuredRiskId(getSafe(row, 16));
        details.setMasterPolicyNumber(getSafe(row, 17));
        details.setMasterPolicyStartDate(getSafe(row, 18));
        details.setMasterPolicyEndDate(getSafe(row, 19));

        details.setBeneficiariesInfo(parseBeneficiaries(getSafe(row, 20)));

        return details;
    }

    private List<GroupPolicyBeneficiaryInfo> parseBeneficiaries(String json) {
        if (json == null || json.isEmpty()) return Collections.emptyList();
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(json, new TypeReference<List<GroupPolicyBeneficiaryInfo>>() {});
        } catch (Exception e) {
            log.error("Failed to parse BeneficiariesInfo JSON: {}", json, e);
            return Collections.emptyList();
        }
    }

    private Long parseLongSafe(String value) {
        if (value == null || value.trim().isEmpty() || "null".equalsIgnoreCase(value)) {
            return null;
        }
        try {
            return Long.parseLong(value.trim());
        } catch (NumberFormatException e) {
            log.warn("Invalid Long format: {}", value);
            return null;
        }
    }

public List<GroupPolicyData> transformToGroupPolicyData (List<GroupPolicyDataResponse> flatData) {
    if (flatData == null || flatData.isEmpty()) return Collections.emptyList();

    // group by policy number
    Map<String, List<GroupPolicyDataResponse>> byPolicy = flatData.stream()
            .collect(Collectors.groupingBy(
                    GroupPolicyDataResponse::getPolicyNumber,
                    LinkedHashMap::new,
                    Collectors.toList()
            ));

    List<GroupPolicyData> result = new ArrayList<>();

    byPolicy.forEach((policyNo, policyRows) -> {


        List<GroupPolicyMember> groupMembers = policyRows.stream()
                .map(row -> {
                    GroupPolicyMember member = new GroupPolicyMember();
                    member.setPrimaryBeneficiaryInfo(mapToPrimaryInfo(row));
                    member.setBeneficiaryInfo(
                            row.getBeneficiariesInfo() == null
                                    ? Collections.emptyList()
                                    : row.getBeneficiariesInfo().stream()
                                    .map(this::mapToBeneficiary)
                                    .toList()
                    );
                    return member;
                })
                .toList();

        int chunkSize = envVariablesService.getInt(GROUP_POLICY_MEMBER_SPLIT_SIZE.name(), 50);
        for (int i = 0; i < groupMembers.size(); i += chunkSize) {
            int end = Math.min(i + chunkSize, groupMembers.size());

            GroupPolicyData chunk = new GroupPolicyData();
            chunk.setPolicyInfo(mapToPolicyInfo(policyRows.get(0)));
            chunk.setGroupMembers(new ArrayList<>(groupMembers.subList(i, end)));
            result.add(chunk);
        }
    });

    return result;
}

    private GroupPolicyInfo mapToPolicyInfo(GroupPolicyDataResponse row) {
        GroupPolicyInfo info = new GroupPolicyInfo();
        info.setPolicyNumber(String.valueOf(row.getPolicyNumber()));
        info.setPolicyType(row.getPolicyType());
        info.setIssuingOfficeNumber(String.valueOf(row.getIssuingOfficeNumber()));
        info.setProductCode(row.getProductCode());
        info.setPolicyStartDate(row.getPolicyStartDate());
        info.setPolicyEndDate(row.getPolicyEndDate());
        info.setProposerPolicyHolder(row.getProposerPolicyHolder());
        info.setPolicyHolderPinCode(row.getPolicyHolderPinCode());
        info.setPreviousYearPolicyNumber(row.getPreviousYearPolicyNumber());
        info.setPolicyStatus(row.getPolicyStatus());
        info.setFloaterSumInsured(String.valueOf(row.getSumInsured()));
        info.setMasterPolicyNumber(row.getMasterPolicyNumber());
        info.setMasterPolicyStartDate(row.getMasterPolicyStartDate());
        info.setMasterPolicyEndDate(row.getMasterPolicyEndDate());
        return info;
    }

    private PrimaryBeneficiaryInfo mapToPrimaryInfo(GroupPolicyDataResponse row) {
        PrimaryBeneficiaryInfo info = new PrimaryBeneficiaryInfo();
        info.setName(row.getName());
        info.setEmployeeCode(row.getEmployeeCode());
        info.setDateOfJoining(row.getDateOfJoining());
        info.setFloaterSumInsured(String.valueOf(row.getFloaterSumInsured()));
        info.setGrade(row.getGrade());
        info.setRiskId(row.getInsuredRiskId());
        return info;
    }

    private GroupPolicyBeneficiary mapToBeneficiary(GroupPolicyBeneficiaryInfo b) {
        GroupPolicyBeneficiary beneficiary = new GroupPolicyBeneficiary();
        beneficiary.setRelation(b.getRelation());
        beneficiary.setName(b.getName());
        beneficiary.setDateOfBirth(b.getDateOfBirth());
        beneficiary.setGender(b.getGender());
        beneficiary.setEffectiveFrom(b.getEffectiveFrom());
        beneficiary.setEffectiveTo(b.getEffectiveTo());
        beneficiary.setZoneForMember(b.getZoneForMember());
        beneficiary.setActive(b.getActive());
        beneficiary.setIndividualSumInsured(b.getIndividualSumInsured());
        beneficiary.setInsurerBeneficiaryUniqueID(b.getInsurerBeneficiaryUniqueID());
        beneficiary.setInception(b.getInception());
        beneficiary.setRiskId(b.getRiskId());
        return beneficiary;
    }

    public List<GroupPolicyData> getOneTimeGroupPolicyData(String startIndex, String endIndex){
        var response = new ArrayList<GroupPolicyDataResponse>();
        List<GroupPolicyData> groupPolicyData = new ArrayList<>();

        var statementIDRequest = new StatementIDRequest();
        statementIDRequest.setWarehouseId(envVariablesService.getValueByKey(WAREHOUSE_ID.name()));
        statementIDRequest.setWaitTimeout(envVariablesService.getValueByKey(WAIT_TIMEOUT.name()));
        try {
            String query = envVariablesService.getValueByKey(ONE_TIME_GROUP_POLICY_UPDATED_QUERY.name()).replace("{latestIndex}", String.valueOf(startIndex))
                    .replace("{nextIndex}", String.valueOf(endIndex));
            statementIDRequest.setStatement(query);
            log.info("Onetime Group Policy | Prepared Query for Datalake call is : {}", query);
            var dataBricksResponse = dataLakeClient.getDataBricksResponse(statementIDRequest);
            var result = Optional.ofNullable(dataBricksResponse.getStatus()).map(DataBricksResponse.Status::getState)
                    .filter(state -> state.equalsIgnoreCase(SUCCEEDED))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getManifest()))
                    .flatMap(state -> Optional.ofNullable(dataBricksResponse.getResult()))
                    .orElseThrow(() -> new MatrixDataSyncException(FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE));
            log.info("Response from Data Lake Client for one time group Policy Data {} ", result);//TODO

            if (Objects.nonNull(dataBricksResponse.getResult().getDataArray())) {
                log.info("Response size from Data Lake Client for one type Group Policy for startIndex {} :  {} ",
                        startIndex ,dataBricksResponse.getResult().getDataArray().size());
                for (var list : dataBricksResponse.getResult().getDataArray()) {
                    response.add(mapRowToGroupPolicyDetails(list));
                }
                log.info("OneTime Group Policy | Policy Numbers found are : {}", response.stream().map(GroupPolicyDataResponse::getPolicyNumber).toList());
            }
            groupPolicyData = transformToGroupPolicyData(response);
        } catch (Exception exception) {
            log.error("Error while getUpdatedGroupPolicyData startIndex: {}, endIndex : {}", startIndex, endIndex, exception);
            throw new MatrixDataSyncException(FAILURE_WHILE_FETCHING_DATA_FROM_DATABRICKS);
        }
        return groupPolicyData;
    }
}
