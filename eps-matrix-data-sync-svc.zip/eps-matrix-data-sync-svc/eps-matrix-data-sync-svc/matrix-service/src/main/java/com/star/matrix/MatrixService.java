package com.star.matrix;


import com.star.matrix.dto.GroupPolicyData;
import com.star.matrix.entity.HospitalPayload;
import com.star.matrix.entity.PolicyPayload;
import com.star.matrix.entity.grouppolicy.GroupPolicyPayload;

import java.util.List;

public interface MatrixService {

    void handleHospitalResponse(HospitalPayload hospitalPayload);

    void handlePolicyResponse(PolicyPayload policyPayload);

    boolean pushBulkPolicy(List<PolicyPayload> policyPayloads);

    boolean pushGroupPolicyDetails(GroupPolicyData payload);

    void handleRetryableGroupPolicyToMatrix(List<GroupPolicyPayload> retryableGroupPolicyPayloads);

    boolean pushBulkGroupPolicy(List<GroupPolicyData> policyPayloads);

}
