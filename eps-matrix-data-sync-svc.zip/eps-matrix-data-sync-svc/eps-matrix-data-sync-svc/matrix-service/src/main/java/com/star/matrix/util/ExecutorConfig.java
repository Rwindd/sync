package com.star.matrix.util;

import com.star.matrix.EnvVariablesService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

import static com.star.matrix.constant.EnvVariableConstant.*;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class ExecutorConfig {

    private final EnvVariablesService envVariablesService;

    @Bean(name = "policyHistoryExecutor")
    public Executor customExecutor() {
        int policyCorePoolSize = envVariablesService.getInt(HISTORY_THREADPOOL_CORE_SIZE.name(), 20);
        int policyMaxPoolSize = envVariablesService.getInt(HISTORY_THREADPOOL_MAX_POOL_SIZE.name(), 50);
        int policyQueueCapacity = envVariablesService.getInt(HISTORY_THREADPOOL_QUEUE_CAPACITY.name(), 20);
        log.info("CorePoolSize : {} ", policyCorePoolSize);
        log.info("MaxPoolSize : {} ", policyMaxPoolSize);
        log.info("QueueCapacity : {} ", policyQueueCapacity);
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(policyCorePoolSize);
        executor.setMaxPoolSize(policyMaxPoolSize);
        executor.setQueueCapacity(policyQueueCapacity);
        executor.setThreadNamePrefix("policyHistoryExecutor-");
        executor.initialize();
        return executor;
    }
}