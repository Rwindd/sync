package com.star.matrix.impl;

import com.star.matrix.client.ZohoClient;
import com.star.matrix.dto.response.zoho.ZohoTokenResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Slf4j
@Component
@RequiredArgsConstructor
public class ZohoTokenManager {

    private static final long SAFETY_MARGIN_SECONDS = 20L;
    private static final long MIN_TTL_SECONDS = 5L;

    private final ZohoClient zohoClient;

    private volatile String token;
    private volatile Instant expiryTime;

    public String getValidToken() {
        if (isExpired()) {
            synchronized (this) {
                if (isExpired()) {
                    refreshTokenInternal();
                }
            }
        }
        return token;
    }

    private boolean isExpired() {
        final Instant now = Instant.now();
        return token == null || expiryTime == null || now.isAfter(expiryTime);
    }

    private void refreshTokenInternal() {
        log.info("Refreshing Zoho access token...");
        ZohoTokenResponse res = zohoClient.getAuthToken();
        if (res == null || res.getAccessToken() == null) {
            throw new IllegalStateException("Zoho token response is null or missing access token");
        }

        long expiresInSeconds = res.getExpiresIn();
        long effectiveTtl = Math.max(expiresInSeconds - SAFETY_MARGIN_SECONDS, MIN_TTL_SECONDS);

        this.token = res.getAccessToken();
        this.expiryTime = Instant.now().plus(effectiveTtl, ChronoUnit.SECONDS);

        log.info("Zoho token refreshed. Expires at: {}", expiryTime);
    }



}