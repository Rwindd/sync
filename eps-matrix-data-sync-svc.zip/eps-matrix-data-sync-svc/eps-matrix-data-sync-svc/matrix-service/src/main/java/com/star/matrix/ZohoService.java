package com.star.matrix;

import com.star.matrix.entity.zoho.RenewQuotePayload;

public interface ZohoService {
    void handleRenewQuoteResponse(RenewQuotePayload renewQuotePayload);
    void pushZohoCRMToMatrix(String recordId);
}
