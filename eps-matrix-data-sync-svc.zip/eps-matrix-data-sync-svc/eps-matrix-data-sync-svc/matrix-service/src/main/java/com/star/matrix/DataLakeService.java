package com.star.matrix;

import com.star.matrix.dto.GroupPolicyData;
import com.star.matrix.dto.GroupPolicyDataResponse;
import com.star.matrix.dto.HospitalDetail;
import com.star.matrix.dto.PolicyDataResponse;
import com.star.matrix.dto.common.*;
import com.star.matrix.dto.request.MatrixDocumentDetail;
import com.star.matrix.dto.request.MatrixPackageDetail;
import com.star.matrix.dto.response.PolciyInsuredDetailsResponse;
import com.star.matrix.dto.zoho.RenewQuoteDetail;
import com.star.matrix.dto.response.PolciyInsuredDetailsResponse;
import com.star.matrix.dto.response.DataLakeResponseDto;
import com.star.matrix.dto.zoho.RenewalQuoteEncrypt;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public interface DataLakeService {


    List<PolicyMemberDetailSummary> getPolicyAndMemberDetails(String policyNumber);

    List<PolicyDocumentSummary> getPolicyDocuments(Set<String> policyNumbers);

    List<ClaimHistorySummary> getPolicyClaimHistory(Set<String> policyNumbers);

    List<ClaimDocumentSummary> getPolicyClaimDocuments(Set<String> policyNumbers);

    List<HospitalDetail> getUpdatedPmsData(String endTime, String startTime);

    List<MatrixDocumentDetail> getUpdatedhospitalDocumentData(String endTime, String startTime);

    List<MatrixPackageDetail> getUpdatedHospitalPackageData(String endTime, String startTime);

    List<PolicyDataResponse> getUpdatedMinimumPolicyDateData(String startIndex, String endIndex,
                                                             LocalDate date);

    List<PolicyDataResponse> getOneTimeMinimumPolicyData(String startIndex, String endIndex);

    List<RenewalQuoteEncrypt> getRenewQuoteData(String startIndex, String endIndex, LocalDate date);

    DataLakeResponseDto processIntimation(String intimation);

    boolean closeDataLakeConnection();

    PolciyInsuredDetailsResponse getPolicyDetails(String policyNumber);

    List<GroupPolicyData> getUpdatedGroupPolicyData(String startIndex, String endIndex,
                                                    LocalDate date);

    List<GroupPolicyData> getOneTimeGroupPolicyData(String startIndex, String endIndex);
}
