package com.star.matrix;

import java.util.List;

public interface GroupPolicyMigrationService {
    void pushGroupPolicyToMatrix(String recordId);
}
