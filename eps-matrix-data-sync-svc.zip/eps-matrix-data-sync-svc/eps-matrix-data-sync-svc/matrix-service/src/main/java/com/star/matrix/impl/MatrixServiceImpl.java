package com.star.matrix.impl;

import com.star.matrix.EnvVariablesService;
import com.star.matrix.MatrixService;
import com.star.matrix.client.MediAssistClient;
import com.star.matrix.client.ZohoClient;
import com.star.matrix.dto.GroupPolicyData;
import com.star.matrix.dto.request.MatrixBulkGroupPolicyRequest;
import com.star.matrix.dto.request.MatrixBulkPolicyRequest;
import com.star.matrix.dto.response.MatrixPmsResponse;
import com.star.matrix.dto.response.MatrixPolicyResponse;
import com.star.matrix.entity.*;
import com.star.matrix.entity.grouppolicy.GroupPolicyPayload;
import com.star.matrix.entity.zoho.RenewQuotePayload;
import com.star.matrix.enumeration.RequestStatus;
import com.star.matrix.properties.ApplicationProperties;
import com.star.matrix.repository.HospitalFailedPayloadRepository;
import com.star.matrix.repository.HospitalPayloadRepository;
import com.star.matrix.repository.PolicyFailedPayloadRepository;
import com.star.matrix.repository.PolicyPayloadRepository;
import com.star.matrix.util.KafkaEventPublisherUtil;
import com.star.matrix.util.ObjectMapperUtil;
import com.star.matrix.util.SequenceGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.star.matrix.constant.EnvVariableConstant.MATRIX_MAX_RETRY_COUNT;
import static com.star.matrix.constant.EnvVariableConstant.MATRIX_ONE_TIME_PARALLEL_THREADS;
import static com.star.matrix.util.ApplicationUtil.supply;
import static com.star.matrix.util.ApplicationUtil.wrapWithTrace;
import static java.util.concurrent.Executors.newFixedThreadPool;
import static org.springframework.messaging.rsocket.PayloadUtils.createPayload;

@Slf4j
@Service
@RequiredArgsConstructor
public class MatrixServiceImpl implements MatrixService {

    private final HospitalPayloadRepository hospitalPayloadRepository;
    private final PolicyPayloadRepository policyPayloadRepository;
    private final PolicyFailedPayloadRepository policyFailedPayloadRepository;
    private final HospitalFailedPayloadRepository hospitalFailedPayloadRepository;
    private final MediAssistClient mediAssistClient;
    private final EnvVariablesService envVariablesService;
    private final KafkaEventPublisherUtil kafkaEventPublisherUtil;
    private final ApplicationProperties applicationProperties;

    @Override
    public void handleHospitalResponse(HospitalPayload hospitalPayload) {
        MatrixPmsResponse matrixResponse = mediAssistClient.hospitalPush(ObjectMapperUtil.convertObjectToJson(hospitalPayload.getMatrixHospitalPayload()));
        if (Objects.nonNull(matrixResponse) && Boolean.TRUE.equals(matrixResponse.getIsSuccess())) {
            log.info("EPS call success for hospital payload : {} ", hospitalPayload);
            hospitalPayload.setStatus(RequestStatus.SUCCESS);
        } else {
            log.info("Eps call failed for hospital payload : {} ", hospitalPayload);
            hospitalPayload.setRetryCount(hospitalPayload.getRetryCount() + 1);
            if (hospitalPayload.getRetryCount() >= envVariablesService.getInt(MATRIX_MAX_RETRY_COUNT.name(), 3)) {
                log.info("Max retry count reached for hospital payload : {} ", hospitalPayload);
                hospitalPayload.setStatus(RequestStatus.FAILED);
                HospitalFailedPayload hospitalFailedPayload = new HospitalFailedPayload();
                hospitalFailedPayload.setHospitalID(hospitalPayload.getHospitalID());
                hospitalFailedPayload.setPayload(hospitalPayload.getMatrixHospitalPayload());
                hospitalFailedPayloadRepository.save(hospitalFailedPayload);
            }
        }
        hospitalPayloadRepository.save(hospitalPayload);
    }

    @Override
    public void handlePolicyResponse(PolicyPayload policyPayload) {
        MatrixPolicyResponse matrixResponse = mediAssistClient.policyPush(policyPayload.getPayload());
        if (Objects.nonNull(matrixResponse) && Boolean.TRUE.equals(matrixResponse.getIsSuccess())) {
            log.info("EPS call success for policy payload : {} ", policyPayload);
            policyPayload.setStatus(RequestStatus.SUCCESS);
        } else {
            log.info("Eps call failed for policy payload : {} ", policyPayload);
            policyPayload.setRetryCount(policyPayload.getRetryCount() + 1);
            if (policyPayload.getRetryCount() >= envVariablesService.getInt(MATRIX_MAX_RETRY_COUNT.name(), 3)) {
                log.info("Max retry count reached for policy payload : {} ", policyPayload);
                policyPayload.setStatus(RequestStatus.FAILED);
                PolicyFailedPayload policyFailedPayload = new PolicyFailedPayload();
                policyFailedPayload.setPolicyNumber(policyPayload.getPolicyNumber());
                policyFailedPayload.setPayload(policyPayload.getPayload());
                policyFailedPayloadRepository.save(policyFailedPayload);
            }
        }
        policyPayloadRepository.save(policyPayload);
    }

    @Override
    public boolean pushBulkPolicy(List<PolicyPayload> policyPayloads) {
        log.info("method: pushBulkPolicy");
        int threadCount = envVariablesService.getInt(MATRIX_ONE_TIME_PARALLEL_THREADS.name(), 2);
        int totalSize = policyPayloads.size();
        int chunkSize = (int) Math.ceil((double) totalSize / threadCount);
        Executor executor = newFixedThreadPool(threadCount);
        List<CompletableFuture<Boolean>> futures = new ArrayList<>();
        for (int i = 0; i < totalSize; i += chunkSize) {
            List<PolicyPayload> chunk = policyPayloads.subList(i, Math.min(i + chunkSize, totalSize));
            futures.add(processChunkAsync(chunk, executor));
        }
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        return futures.stream().allMatch(CompletableFuture::join);
    }

    @Override
    public boolean pushGroupPolicyDetails(GroupPolicyData payload) {
        log.info("Group policy Number {} pushing to Matrix", payload.getPolicyInfo().getPolicyNumber());
        var response = mediAssistClient.groupPolicyPush(payload);
        return response.getIsSuccess();
    }

    @Override
    public void handleRetryableGroupPolicyToMatrix(List<GroupPolicyPayload> retryableGroupPolicyPayloads) {
        List<String> retryableGroupPolicyRecordIds= retryableGroupPolicyPayloads.stream().map(GroupPolicyPayload::getRecordId).toList();
        publishListToKafka(retryableGroupPolicyRecordIds);
      }

    private void publishListToKafka(List<String> ids) {
        for(String id : ids){
            try {
                kafkaEventPublisherUtil.publishEventToKafkaTopic(applicationProperties.getGroupPolicyTopic(), id);
                log.info("Kafka Success | Group policy mongoId message sent with ID {}", id);
            } catch (Exception e) {
                log.error("Kafka Error | Group policy failed for record ID {} to publish", id, e.getMessage());
            }
        }
    }

    private CompletableFuture<Boolean> processChunkAsync(List<PolicyPayload> chunk, Executor executor) {
        return supply("push bulk policy to matrix",
                wrapWithTrace(() -> {
                    log.info("Thread " + Thread.currentThread().getName() + " processing " + chunk.size() + " records");
                    MatrixBulkPolicyRequest request = new MatrixBulkPolicyRequest();
                    request.setTraceId(SequenceGenerator.getNextSequence());
                    List<MatrixBulkPolicyRequest.Batch> batches = chunk.stream()
                            .map(policyPayload -> {
                                MatrixBulkPolicyRequest.Batch b = new MatrixBulkPolicyRequest.Batch();
                                b.setPolicyInfo(policyPayload.getPayload().getPolicyInfo());
                                b.setBeneficiaryInfo(policyPayload.getPayload().getBeneficiaryInfo());
                                return b;
                            })
                            .toList();
                    request.setBatches(batches);
                    var response = mediAssistClient.bulkPolicyPush(request);
                    return response.isSuccess;
                }), executor).exceptionally(ex -> {
            log.error("Error processing batch in thread " + Thread.currentThread().getName(), ex);
            return false;
        });
    }

    @Override
    public boolean pushBulkGroupPolicy(List<GroupPolicyData> policyPayloads) {
        int threadCount = envVariablesService.getInt(MATRIX_ONE_TIME_PARALLEL_THREADS.name(), 2);
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        int totalSize = policyPayloads.size();
        int chunkSize = (int) Math.ceil((double) totalSize / threadCount);
        try {
            List<CompletableFuture<Boolean>> futures = new ArrayList<>();

            for (int i = 0; i < totalSize; i += chunkSize) {
                List<GroupPolicyData> chunk = policyPayloads.subList(i, Math.min(i + chunkSize, totalSize));
                log.info("Group policy chunk push to Matrix. Policy numbers : {}", getPolicyNumbersOrDefault(chunk));
                futures.add(processGroupPolicyChunkAsync(chunk, executor));
            }

            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
            return futures.stream().allMatch(CompletableFuture::join);
        } finally {
            executor.shutdown();
        }
    }

    private static List<String> getPolicyNumbersOrDefault(List<GroupPolicyData> responses) {
        try{
            return responses.stream().map(policyData -> policyData.getPolicyInfo().getPolicyNumber()).toList();
        } catch (Exception e){
            log.error("Error occurred while listing policy Numbers from {} . Message : {}", ObjectMapperUtil.convertObjectToString(responses), e.getMessage(), e);
            return Collections.emptyList();
        }
    }

    private CompletableFuture<Boolean> processGroupPolicyChunkAsync(List<GroupPolicyData> chunk, Executor executor) {
        return supply("push bulk group policy to matrix",
                wrapWithTrace(() -> {
                    log.info("Group Policy : Thread " + Thread.currentThread().getName() + " processing " + chunk.size() + " records");
                    MatrixBulkGroupPolicyRequest request = new MatrixBulkGroupPolicyRequest();
                    List<MatrixBulkGroupPolicyRequest.Batch> batches = chunk.stream()
                            .map(policyPayload -> {
                                MatrixBulkGroupPolicyRequest.Batch b = new MatrixBulkGroupPolicyRequest.Batch();
                                b.setPolicyInfo(policyPayload.getPolicyInfo());
                                b.setGroupMembers(policyPayload.getGroupMembers());
                                return b;
                            })
                            .toList();
                    request.setBatches(batches);
                    var response = mediAssistClient.bulkGroupPolicyPush(request);
                    return response.isSuccess;
                }), executor).exceptionally(ex -> {
            log.error("Error processing batch in thread " + Thread.currentThread().getName(), ex);
            return false;
        });
    }
}
