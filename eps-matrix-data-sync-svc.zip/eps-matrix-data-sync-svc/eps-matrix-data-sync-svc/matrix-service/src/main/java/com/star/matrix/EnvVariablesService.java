package com.star.matrix;

import com.star.matrix.dto.request.EnvVariableDeleteRequestDto;
import com.star.matrix.dto.request.EnvironmentVariablesRequestDto;
import com.star.matrix.dto.response.EnvVariablesResponse;
import jakarta.annotation.PostConstruct;

import java.util.List;

public interface EnvVariablesService {

    @PostConstruct
    void refreshCache();

    Integer getInt(String key, Integer defaultVal);

    Long getLong(String key, long defaultVal);

    boolean getBool(String key, boolean defaultVal);

    String getValueByKey(String key);

    List<EnvVariablesResponse> getEnvironmentVariables(String key);

    String updateEnvironmentVariables(String key, boolean delete, EnvironmentVariablesRequestDto environmentVariablesRequestDto);

    String createEnvironmentVariables(EnvironmentVariablesRequestDto environmentVariablesRequestDto);

    String deleteEnvironmentVariables(EnvVariableDeleteRequestDto deleteRequestDto);

}