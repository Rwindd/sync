package com.star.matrix.impl;

import com.star.matrix.EnvVariablesService;
import com.star.matrix.ZohoService;
import com.star.matrix.client.ZohoClient;
import com.star.matrix.dto.request.zoho.RenewQuotePushRequest;
import com.star.matrix.dto.response.zoho.ZohoRenewQuoteResponse;
import com.star.matrix.dto.zoho.RenewQuoteDetail;
import com.star.matrix.dto.zoho.RenewalQuoteEncrypt;
import com.star.matrix.dto.zoho.UpsellPremiumRenewQuote;
//import com.star.matrix.entity.grouppolicy.GroupPolicyFailedPayload;
//import com.star.matrix.entity.grouppolicy.renewQuotePayload;
import com.star.matrix.entity.zoho.RenewQuoteFailedPayload;
import com.star.matrix.entity.zoho.RenewQuotePayload;
import com.star.matrix.enumeration.RequestStatus;
import com.star.matrix.repository.*;
import com.star.matrix.util.ObjectMapperUtil;
import com.starhealth.encryption.service.FieldEncryptionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.star.matrix.constant.EnvVariableConstant.MATRIX_GROUP_POLICY_MAX_RETRY_COUNT;
import static com.star.matrix.constant.EnvVariableConstant.ZOHO_MAX_RETRY_COUNT;
import static com.star.matrix.util.ApplicationUtil.isZohoRenewQuoteSuccess;
import static org.springframework.messaging.rsocket.PayloadUtils.createPayload;

@Slf4j
@Service
@RequiredArgsConstructor
public class ZohoServiceImpl implements ZohoService {

    private static final String SUCCEEDED = "SUCCESS";

    private final RenewQuotePayloadRepository renewQuotePayloadRepository;
    private final RenewQuoteFailedPayloadRepository renewQuoteFailedPayloadRepository;
    private final ZohoClient zohoClient;
    private final EnvVariablesService envVariablesService;
    private final ZohoTokenManager zohoTokenManager;
    private final FieldEncryptionService fieldEncryptionService;

    @Override
    public void handleRenewQuoteResponse(RenewQuotePayload renewQuotePayload) {
        try {
            String token = zohoTokenManager.getValidToken();

            ZohoRenewQuoteResponse renewQuoteResponse = zohoClient.renewQuotePush(
                    ObjectMapperUtil.convertObjectToJson(createPayload(renewQuotePayload)),
                    token
            );

            if (isZohoRenewQuoteSuccess(renewQuoteResponse)) {
                log.info("EPS call success for renew quote payload : {} ", renewQuotePayload);
                renewQuotePayload.setStatus(RequestStatus.SUCCESS);
            } else {
                log.info("EPS call failed for renew quote payload : {} ", renewQuotePayload);
                handleFailure(renewQuotePayload);
            }

        } catch (Exception ex) {
            log.error("Exception while processing renew quote payload: {} ", renewQuotePayload, ex);
            handleFailure(renewQuotePayload);
        } finally {
            renewQuotePayloadRepository.save(renewQuotePayload);
        }
    }

    private void handleFailure(RenewQuotePayload renewQuotePayload) {
        int currentRetry = renewQuotePayload.getRetryCount() == null ? 0 : renewQuotePayload.getRetryCount();
        renewQuotePayload.setRetryCount(currentRetry + 1);

        int maxRetry = envVariablesService.getInt(ZOHO_MAX_RETRY_COUNT.name(), 3);

        if (renewQuotePayload.getRetryCount() >= maxRetry) {
            log.info("Max retry count reached for renew quote payload : {} ", renewQuotePayload);
            renewQuotePayload.setStatus(RequestStatus.FAILED);

            RenewQuoteFailedPayload renewQuoteFailedPayload = RenewQuoteFailedPayload.builder()
                    .payload(renewQuotePayload.getRenewalQuoteEncrypt())
                    .renewalPolicyRefNo(renewQuotePayload.getRenewalPolicyRefNo())
                    .build();
            renewQuoteFailedPayloadRepository.save(renewQuoteFailedPayload);
        }
    }

    private RenewQuotePushRequest createPayload(RenewQuotePayload renewQuotePayload){
        return RenewQuotePushRequest.builder()
                .data(List.of(decryptAndMapToRenewalQuoteDetail(renewQuotePayload.getRenewalQuoteEncrypt())))
                .duplicateCheckFields(List.of("Renewal_Policy_Ref_No"))
                .trigger(List.of("workflow"))
                .build();
    }

    private RenewQuoteDetail decryptAndMapToRenewalQuoteDetail(RenewalQuoteEncrypt encrypt){
        RenewQuoteDetail renewQuoteDetail = toRenewQuoteDetail(encrypt);

        renewQuoteDetail.setIntermediatorEmail(decryptString(encrypt.getIntermediatorEmailE()));
        renewQuoteDetail.setEmail(decryptString(encrypt.getProposerEmailIdE()));
        renewQuoteDetail.setSalesManagerPhone(decryptString(encrypt.getSalesManagerPhoneE()));
        renewQuoteDetail.setIntermediatorPhone(decryptString(encrypt.getIntermediatorPhoneE()));
        renewQuoteDetail.setProposerContactNo(decryptString(encrypt.getProposerContactNoE()));

        return renewQuoteDetail;
    }


    public static RenewQuoteDetail toRenewQuoteDetail(RenewalQuoteEncrypt src) {
        if (src == null) return null;
        RenewQuoteDetail dst = new RenewQuoteDetail();

        dst.setNumberOfYear(src.getNumberOfYear());
        dst.setFromDate(src.getPolicyFromDate());
        dst.setGracePeriodEndDate(src.getGracePeriodEndDate());
        dst.setPremiaConvertedPolicyTotalPremium(src.getPremiaConvertedPolicyTotalPremium());
        dst.setInstallmentPremiumamount(src.getInstallmentPremiumAmount());
        dst.setPremiaDivisionName(src.getOfficeCode());
        dst.setPremiaProductCode(src.getProductCode());
        dst.setBranchManagerName(src.getBranchManagerName());
        dst.setPaymentDate(src.getPaymentDate());
        dst.setInstallmentTax(src.getInstallmentTax());
        dst.setPolicySource(src.getSource());
        dst.setRenewalPolicyType(src.getProposalType());
        dst.setPreviousPolicyNo(src.getPreviousPolicyNumber());
        dst.setCurrencyPolicyPremiumGST(src.getCurrencyPolicyPremiumGst());
        dst.setRenewalPaymentType(src.getRenewalPaymentType());
        dst.setIntermediatorCode(src.getIntermediaryCode());
        dst.setSalesManagerCode(src.getFulfillerCode());
        dst.setServiceTax(src.getCurrentPremiumTax());
        dst.setRenewalPolicyPincode(src.getPinCode());
        dst.setPolicyConvertedDate(src.getPolicyConvertedDate());
        dst.setPremiaCurrentPolicySumInsured(src.getPremiaCurrentPolicySumInsured());
        dst.setRenewalStatus(src.getRenewalStatus());
        dst.setInstallmentTotalPremium(src.getInstallmentTotalPremium());
        dst.setNcb(src.getNcb());
        dst.setIntermediatorName(src.getIntermediaryName());
        dst.setBranchManagerMobile(src.getBranchManagerPhNo());
        dst.setBranchManagerPhone(src.getBranchManagerPhNo());
        dst.setEnvironment(src.getEnvironment());
        dst.setBranchManagerCode(src.getBranchManagerCode());
        dst.setSecondaryEmail(src.getSecondaryEmail());
        dst.setEmiPolicy(src.getEmiPolicy());
        dst.setDivisonCode(src.getDivisonCode());
        dst.setRecordReceivedFromSystem(src.getRecordReceivedFromSystem());
        dst.setRenewalLocation(src.getRenewalLocation());
        dst.setWorkflowTrigger(src.getWorkflowTrigger());
        dst.setPaymentStatus(src.getPaymentStatus());
        dst.setRenewalID(src.getRenewalId());
        dst.setExpireDate(src.getPolicyToDate());
        dst.setRenewalPolicyRefNo(src.getRenewalPolicyRefNo());
        dst.setPolicyRenewed(src.getPolicyRenewed());
        dst.setPremiaCurrentPolicyNo(src.getPremiaCurrentPolicyNo());
        dst.setPaymentMode(src.getPaymentMode());
        dst.setInstallmentYear(src.getInstallmentYear());
        dst.setSumInsured(src.getSumInsured());
        dst.setCurrentPolicyPremiumTotalAmount(src.getCurrentPolicyPremiumTotalAmount());
        dst.setPremiaConvertedPremiumAmount(src.getPremiaConvertedPremiumAmount());
        dst.setContactName(src.getContactName());
        dst.setPremiaConvertedPolicyNo(src.getPremiaConvertedPolicyNo());
        dst.setPremiumAmount(src.getPremiumAmount());
        dst.setClaimStatus(src.getClaimStatus());
        dst.setPremiaContactCode(src.getPremiaContactCode());
        dst.setCurrentPolicyPremiumAmount(src.getCurrentPolicyPremiumAmount());
        dst.setPremiaProductName(src.getProductName());
        dst.setTotal(src.getCurrentPremiumTotal());
        dst.setPremiaConvertedPolicyGST(src.getPremiaConvertedPolicyGst());
        dst.setRenewalAddress3(src.getRenewalAddress3());
        dst.setRenewalAddress1(src.getRenewalAddress1());
        dst.setNcdIssued(src.getNcdIssued());
        dst.setSalesManagerName(src.getSalesManagerName());
        dst.setNoOfInstallment(src.getNoOfInstallment());
        dst.setRenewalAddress2(src.getRenewalAddress2());

        List<UpsellPremiumRenewQuote> upsellList = new ArrayList<>();
        addUpsellIfPresent(upsellList, src.getUpsellSumInsured1(), src.getUpsellPremium1(), src.getUpsellGst1(), src.getUpsellTotal1());
        addUpsellIfPresent(upsellList, src.getUpsellSumInsured2(), src.getUpsellPremium2(), src.getUpsellGst2(), src.getUpsellTotal2());
        addUpsellIfPresent(upsellList, src.getUpsellSumInsured3(), src.getUpsellPremium3(), src.getUpsellGst3(), src.getUpsellTotal3());
        addUpsellIfPresent(upsellList, src.getUpsellSumInsured4(), src.getUpsellPremium4(), src.getUpsellGst4(), src.getUpsellTotal4());
        addUpsellIfPresent(upsellList, src.getUpsellSumInsured5(), src.getUpsellPremium5(), src.getUpsellGst5(), src.getUpsellTotal5());
        dst.setUpsellPremium(upsellList);

        return dst;
    }

    private static void addUpsellIfPresent(List<UpsellPremiumRenewQuote> list,
                                           String sumInsured, String premium, String gst, String total) {
        if (isBlank(sumInsured) && isBlank(premium) && isBlank(gst) && isBlank(total)) {
            return;
        }
        UpsellPremiumRenewQuote upsellPremiumRenewQuote = new UpsellPremiumRenewQuote();
        upsellPremiumRenewQuote.upsellSumInsured  = sumInsured;
        upsellPremiumRenewQuote.upsellPremiumAmount = premium;
        upsellPremiumRenewQuote.gst               = gst;
        upsellPremiumRenewQuote.upsellTotal       = total;
        list.add(upsellPremiumRenewQuote);
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private String decryptString(String encryptedValue) {
        if (encryptedValue == null || encryptedValue.isEmpty()) return "";
        return fieldEncryptionService.decryptFieldString(encryptedValue);
    }

    @Override
    public void pushZohoCRMToMatrix(String recordId) {
        log.info("[@ZohoServiceImpl]. Push ZOHO CRM record Id : {}", recordId);
        var renewQuotePayload = renewQuotePayloadRepository.findByRecordId(recordId).orElse(null);
        if (renewQuotePayload != null && renewQuotePayload.getStatus().name().equalsIgnoreCase(RequestStatus.QUEUED.name())) {
            updaterenewQuotePayloadStatus(renewQuotePayload, RequestStatus.IN_PROGRESS);
            String token = zohoTokenManager.getValidToken();
            ZohoRenewQuoteResponse response =
                    zohoClient.renewQuotePush(
                ObjectMapperUtil.convertObjectToJson(createPayload(renewQuotePayload)
                ), token);
            if (!isZohoRenewQuoteSuccess(response)) {
                renewQuotePayload.setStatus(RequestStatus.SUCCESS);
            }else {
                renewQuotePayload.setStatus(RequestStatus.INITIATED);
                renewQuotePayload.setRetryCount(renewQuotePayload.getRetryCount() + 1);
                if(renewQuotePayload.getRetryCount() >= envVariablesService.getInt(MATRIX_GROUP_POLICY_MAX_RETRY_COUNT.name(), 3)){
                    renewQuotePayload.setStatus(RequestStatus.FAILED);
                    RenewQuoteFailedPayload renewQuoteFailedPayload = RenewQuoteFailedPayload.builder()
                            .payload(renewQuotePayload.getRenewalQuoteEncrypt())
                            .renewalPolicyRefNo(renewQuotePayload.getRenewalPolicyRefNo())
                            .build();
                    renewQuoteFailedPayloadRepository.save(renewQuoteFailedPayload);
                }
            }
            renewQuotePayloadRepository.save(renewQuotePayload);
        } else {
            log.error("RecordId not found : {}", recordId);
        }
    }

    private void updaterenewQuotePayloadStatus(RenewQuotePayload renewQuotePayload, RequestStatus status) {
        renewQuotePayload.setStatus(status);
        renewQuotePayloadRepository.save(renewQuotePayload);
    }
}
