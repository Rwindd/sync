package com.star.matrix.impl;

import com.star.matrix.DataLakeService;
import com.star.matrix.PolicyDetailService;
import com.star.matrix.dto.common.*;
import com.star.matrix.dto.response.PolicyHistoryResponse;
import com.star.matrix.exception.MatrixDataSyncException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

import static com.star.matrix.exception.MatrixErrorCode.FAILED_TO_FETCH_POLICY_CLAIM_HISTORY_DATA;
import static com.star.matrix.util.ApplicationUtil.supply;
import static com.star.matrix.util.ApplicationUtil.wrapWithTrace;

@Service
@Slf4j
@RequiredArgsConstructor
public class PolicyDetailServiceImpl implements PolicyDetailService {

	private final DataLakeService dataLakeService;
	private final Executor policyHistoryExecutor;

	@Override
	public PolicyHistoryResponse getPolicyHistoryDetails(String policyNumber) {
		try {
			List<PolicyMemberDetailSummary> pmd = dataLakeService.getPolicyAndMemberDetails(policyNumber);
			if(pmd.isEmpty()){
				return new PolicyHistoryResponse();
			}
			Set<String> uniquePolicyNumbers = pmd.stream().map(PolicyMemberDetailSummary::getPolicyNo).collect(Collectors.toSet());
			var docs = supply("getPolicyDocuments",
					wrapWithTrace(() -> dataLakeService.getPolicyDocuments(uniquePolicyNumbers)), policyHistoryExecutor);
			var history = supply("getPolicyClaimHistory",
					wrapWithTrace(() -> dataLakeService.getPolicyClaimHistory(uniquePolicyNumbers)), policyHistoryExecutor);
			var claims = supply("getPolicyClaimDocuments",
					wrapWithTrace(() -> dataLakeService.getPolicyClaimDocuments(uniquePolicyNumbers)), policyHistoryExecutor);
            List<CompletableFuture<?>> futures = List.of(docs, history, claims);
            CompletableFuture<Void> failFast = new CompletableFuture<>();
            for (CompletableFuture<?> future : futures) {
                future.whenComplete((result, ex) -> {
                    if (ex != null) {
                        failFast.completeExceptionally(ex);
                    }
                });
            }
            CompletableFuture.allOf(docs, history, claims)
                    .thenAcceptAsync(r -> failFast.complete(null), policyHistoryExecutor);
            failFast.join();
            var combined = new PolicyClaimHistoryCombined(pmd, docs.join(), history.join(), claims.join());
            return sanitizeResponse(combined);
		} catch (Exception e) {
			log.error("Failed to fetch Policy and claim History information", e);
			throw new MatrixDataSyncException(FAILED_TO_FETCH_POLICY_CLAIM_HISTORY_DATA);
		}
	}

	PolicyHistoryResponse sanitizeResponse(PolicyClaimHistoryCombined combined) {
		var policyMemberDetailSummaries = combined.getPolicyMemberDetailSummaries();
		var policyDocumentSummaries = combined.getPolicyDocumentSummaries();
		var claimHistorySummaries = combined.getClaimHistorySummaries();
		var claimDocumentSummaries = combined.getClaimDocumentSummaries();
		var policyHistoryResponse = new PolicyHistoryResponse();
		policyMemberDetailSummaries.forEach(policyMemberDetailSummary -> {
			var policyNumber = policyMemberDetailSummary.getPolicyNo();
			var policy = new PolicyHistoryResponse.Policy();
			addPolicyMemberDetails(policyMemberDetailSummary, policy);
			addPolicyDocuments(policyDocumentSummaries, policyNumber, policy);
			addPolicyClaimHistory(claimHistorySummaries, claimDocumentSummaries, policyNumber, policy);
			policyHistoryResponse.getPolicies().add(policy);
		});
		return policyHistoryResponse;
	}

	static void addPolicyClaimHistory(List<ClaimHistorySummary> claimHistorySummaries,
                                      List<ClaimDocumentSummary> claimDocumentSummaries, String policyNumber,
                                      PolicyHistoryResponse.Policy policy) {
		claimHistorySummaries.stream().filter(summary -> policyNumber.equalsIgnoreCase(summary.getPolicyNumber()))
				.findFirst().ifPresent(summary ->
					policy.setClaim(summary.getClaimHistories().stream().map(history -> {
						var claim = new PolicyHistoryResponse.Claim();
						claim.setClaimAmount(history.getClaimedAmount());
						claim.setClaimNumber(history.getClaimNumber());
						claim.setClaimStatus(history.getClaimStatus());
						claim.setClaimType(history.getClaimType());
						claim.setPed(history.getPedName());
						claim.setCataractDetails(history.getCataractDetails());
						claim.setDiagnosis(history.getDiagnosis());
						claim.setCopay(history.getCopay());
						claim.setHealthId(history.getHealthId());
						claim.setPolicyYear(history.getPolicyYear());
						claim.setIntimationNumber(history.getIntimationNumber());
						claim.setInsuredPatientName(history.getPatientName());
						claim.setApprovedAmount(history.getApprovedAmount());
						claim.setHospitalDetails(history.getHospitalName());
						claim.setDiagnosis(history.getDiagnosis());
						claim.setSublimitName(history.getSublimitName());
						claim.setSublimitAmount(history.getSublimitAmount());
						claim.setIcdCode(history.getIcdCode());
						claim.setSublimitCategory(history.getSublimitCategory());
						claim.setSiRegistration(history.getSiRestrictionFlag());
						claim.setClaimStatus(history.getClaimStatus());
						claimDocumentSummaries.stream()
								.filter(documentSummary -> history.getIntimationNumber()
										.equalsIgnoreCase(documentSummary.getIntimationNumber()))
								.findFirst().ifPresent(documentSummary ->
									claim.setDocuments(documentSummary.getClaimDocuments().stream().map(doc -> {
										var document = new PolicyHistoryResponse.ClaimDocument();
										document.setDocumentType(doc.getDocumentType());
										document.setDocumentToken(doc.getDocumentToken());
										document.setDocumentName(doc.getDocumentName());
										return document;
									}).toList())
								);
						return claim;
					}).toList())
				);
	}

	static void addPolicyDocuments(List<PolicyDocumentSummary> policyDocumentSummaries, String policyNumber,
                                   PolicyHistoryResponse.Policy policy) {
		policyDocumentSummaries.stream().filter(summary -> policyNumber.equalsIgnoreCase(summary.getPolicyNo()))
				.findFirst().ifPresent(summary ->
						policy.setDocument(summary.getDocumentDetails().stream().map(doc -> {
							var document = new PolicyHistoryResponse.Document();
							document.setDocumentType(doc.getDocumentType());
							document.setDocumentSource(doc.getDocumentSource());
							document.setDocumentName(doc.getDocumentName());
							document.setPolicyNo(policyNumber);
							document.setProposalNo(doc.getProposalNo());
							document.setApiDocumentType(doc.getApiDocumentType());
							return document;
						}).toList())
				);

	}

	static void addPolicyMemberDetails(PolicyMemberDetailSummary policyMemberDetailSummary,
                                       PolicyHistoryResponse.Policy policy) {
		policy.setPolicyNo(policyMemberDetailSummary.getPolicyNo());
		policy.setPolicyFromDate(policyMemberDetailSummary.getPolicyFromDate());
		policy.setPolicyToDate(policyMemberDetailSummary.getPolicyToDate());
		policy.setUwYear(policyMemberDetailSummary.getUwYear());
		policy.setSumInsured(policyMemberDetailSummary.getSumInsured());
		policy.setProductName(policyMemberDetailSummary.getProductName());
		policy.setPreviousPolicyNo(policyMemberDetailSummary.getPreviousPolicyNo());
		policy.setPolicySource(policyMemberDetailSummary.getPolicySource());
		policy.setPolicyInceptionDate(policyMemberDetailSummary.getPolicyInceptionDate());
		policy.setPolicyType(policyMemberDetailSummary.getPolicyType());
		policy.setMember(policyMemberDetailSummary.getMembers().stream().map(member -> {
			var mem = new PolicyHistoryResponse.Member();
			mem.setDob(member.getDob());
			mem.setPed(member.getPed());
			mem.setGender(member.getGender());
			mem.setRelation(member.getRelation());
			mem.setSumInsured(member.getSumInsured());
			mem.setHealthId(member.getHealthId());
			mem.setInsuredName(member.getInsuredName());
			mem.setEffectiveFrom(member.getEffectiveFrom());
			mem.setEffectiveTo(member.getEffectiveTo());
			mem.setInsuredInceptionDate(member.getInsuredInceptionDate());
			return mem;
		}).toList());
	}
}
