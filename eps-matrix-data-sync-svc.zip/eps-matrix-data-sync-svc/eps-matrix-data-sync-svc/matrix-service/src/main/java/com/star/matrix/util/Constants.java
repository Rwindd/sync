package com.star.matrix.util;

import org.springframework.stereotype.Component;

@Generated
@Component
public class Constants {

	private Constants(){

	}
	public static final Integer RETRY_COUNT = 0;
	public static final String COMPLETED = "COMPLETED";
	public static final String NO_DATA = "NO_DATA";
	public static final String FAILURE = "FAILURE";
	public static final String POLICY_DATA_FETCH = "Policy_Data_Fetch";
	public static final String CREATED_DATE = "created_date";
	public static final String POLICY_INDEX_RANGE = "policy_Index_Ranges";
	public static final String HOSPITAL_DATA_FETCH = "Hospital_Data_Fetch";

}
