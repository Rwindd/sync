package com.star.matrix.impl;

import com.star.matrix.EnvVariablesService;
import com.star.matrix.GroupPolicyMigrationService;
import com.star.matrix.MatrixService;
import com.star.matrix.entity.grouppolicy.GroupPolicyFailedPayload;
import com.star.matrix.entity.grouppolicy.GroupPolicyPayload;
import com.star.matrix.enumeration.RequestStatus;
import com.star.matrix.repository.GroupPolicyFailedPayloadRepository;
import com.star.matrix.repository.GroupPolicyPayloadRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import static com.star.matrix.constant.EnvVariableConstant.MATRIX_GROUP_POLICY_MAX_RETRY_COUNT;
import static com.star.matrix.constant.EnvVariableConstant.MATRIX_MAX_RETRY_COUNT;

@Service
@RequiredArgsConstructor
@Slf4j
public class GroupPolicyMigrationServiceImpl implements GroupPolicyMigrationService {

    private final GroupPolicyPayloadRepository groupPolicyPayloadRepository;
    private final GroupPolicyFailedPayloadRepository groupPolicyFailedPayloadRepository;
    private final MatrixService matrixService;
    private final EnvVariablesService envVariablesService;

    @Override
    public void pushGroupPolicyToMatrix(String recordId) {
        log.info("[@GroupPolicyMigrationServiceImpl].pushGroupPolicies. Push Group policy record Id : {}", recordId);
        var groupPolicyPayload = groupPolicyPayloadRepository.findByRecordId(recordId).orElse(null);
        if (groupPolicyPayload != null && groupPolicyPayload.getStatus().name().equalsIgnoreCase(RequestStatus.QUEUED.name())) {
            updateGroupPolicyPayloadStatus(groupPolicyPayload, RequestStatus.IN_PROGRESS);
            boolean isPushedToMatrix = matrixService.pushGroupPolicyDetails(groupPolicyPayload.getPayload());
            if (isPushedToMatrix) {
                groupPolicyPayload.setStatus(RequestStatus.SUCCESS);
            }else {
                // increase retry count
                groupPolicyPayload.setStatus(RequestStatus.INITIATED);
                groupPolicyPayload.setRetryCount(groupPolicyPayload.getRetryCount() + 1);
                if(groupPolicyPayload.getRetryCount() >= envVariablesService.getInt(MATRIX_GROUP_POLICY_MAX_RETRY_COUNT.name(), 3)){
                    groupPolicyPayload.setStatus(RequestStatus.FAILED);
                    GroupPolicyFailedPayload groupPolicyFailedPayload = GroupPolicyFailedPayload.builder()
                            .payload(groupPolicyPayload.getPayload())
                            .policyNumber(groupPolicyPayload.getPolicyNumber())
                            .build();
                    groupPolicyFailedPayloadRepository.save(groupPolicyFailedPayload);
                }
            }
            groupPolicyPayloadRepository.save(groupPolicyPayload);
        } else {
            log.error("RecordId not found : {}", recordId);
        }
    }

    private void updateGroupPolicyPayloadStatus(GroupPolicyPayload groupPolicyPayload, RequestStatus status) {
        groupPolicyPayload.setStatus(status);
        groupPolicyPayloadRepository.save(groupPolicyPayload);
    }
}
