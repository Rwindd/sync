package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;

@Generated
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class PrevPolicyClaimDocument {

	@JsonProperty("INTIMATIONNO")
	private String intimationNo;

	@JsonProperty("DOCUMENTNAME")
	private String documentName;

	@JsonProperty("DOCUMENTTOKEN")
	private String documentToken;

	@JsonProperty("DOCUMENTTYPE")
	private String documentType;

	@JsonProperty("DOCUMENTCATEGORY")
	private String documentCategory;

}
