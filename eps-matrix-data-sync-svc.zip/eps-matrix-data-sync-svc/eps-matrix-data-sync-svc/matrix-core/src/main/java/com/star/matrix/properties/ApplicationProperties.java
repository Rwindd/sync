package com.star.matrix.properties;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
public class ApplicationProperties {

	@Value("${databricks.url}")
	private String databricksUrl;

	@Value("${databricks.token}")
	private String token;

	@Value("${matrix.hospitalPushUrl}")
	private String matrixHospitalPushUrl;

	@Value("${matrix.policyPushUrl}")
	private String matrixPolicyPushUrl;

	@Value("${matrix.bulkPolicyPushUrl}")
	private String matrixBulkPolicyPushUrl;

    @Value("${matrix.groupPolicyPushUrl}")
    private String matrixGroupPolicyPushUrl;
	
	@Value("${databricks.stop-url}")
	private String connectionStopUrl;

	@Value("${spring.application.name}")
	private String applicationName;

    @Value("${zoho.token.url}")
    private String zohoTokenGenerateUrl;

    @Value("${zoho.token.refreshToken}")
    private String zohoRefreshToken;

    @Value("${zoho.token.clientId}")
    private String zohoClientId;

    @Value("${zoho.token.clientSecret}")
    private String zohoClientSecret;

    @Value("${zoho.token.grantType}")
    private String zohoGrantType;

    @Value("${zoho.renewQuotePush.url}")
    private String renewQuotePushUrl;

    @Value("${databricks.crm-token}")
    private String crmToken;

    @Value("${kafka.topic.group-policy}")
    private String groupPolicyTopic;

    @Value("${kafka.topic.zoho-crm}")
    private String zohoCRMTopic;

    @Value("${matrix.bulkGroupPolicyPushUrl}")
    private String matrixBulkGroupPolicyPushUrl;

}
