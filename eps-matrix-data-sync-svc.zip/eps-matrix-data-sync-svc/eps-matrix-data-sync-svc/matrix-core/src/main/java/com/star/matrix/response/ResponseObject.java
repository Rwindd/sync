package com.star.matrix.response;

import com.star.matrix.exception.MatrixErrorCode;

public record ResponseObject<T>(Meta meta, T data) {

    public ResponseObject(String displayMessage, T data) {
        this(new Meta("200", "SUCCESS", displayMessage), data);
    }

    public ResponseObject(MatrixErrorCode errorCode) {
        this(new Meta(errorCode.getCode(), errorCode.name(), errorCode.getDisplayMessage()), null);
    }

    public ResponseObject(String displayMessage) {
        this(new Meta("200", "SUCCESS", displayMessage), null);

    }
}