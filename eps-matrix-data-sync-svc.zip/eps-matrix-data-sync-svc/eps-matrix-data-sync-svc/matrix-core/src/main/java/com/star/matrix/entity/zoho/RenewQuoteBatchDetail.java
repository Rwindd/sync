package com.star.matrix.entity.zoho;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.time.LocalDateTime;

@Data
@Document(collection = "renew_quote_batch_detail")
public class RenewQuoteBatchDetail {
    private RenewQuoteBatchStatus renewQuoteBatchStatus;
    private LocalDateTime date;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;
}
