package com.star.matrix.dto;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;

@Generated
@Data
public class PolicyDetails {

	@JsonProperty("PolicyNumber")
	private String policyNumber;

	@JsonProperty("PolicyType")
	private String policyType;

	@JsonProperty("IssuingOfficeNumber")
	private String issuingOfficeNumber;

	@JsonProperty("ProductCode")
	private String productCode;

	@JsonProperty("PolicyStartDate")
	private String policyStartDate;

	@JsonProperty("PolicyEndDate")
	private String policyEndDate;

	@JsonProperty("ProposerPolicyHolder")
	private String proposerPolicyHolder;

	@JsonProperty("PolicyHolderPinCode")
	private String policyHolderPinCode;

	@JsonProperty("PreviousYearPolicyNumber")
	private String previousYearPolicyNumber;

	@JsonProperty("PolicyStatus")
	private String policyStatus;

	@JsonProperty("FloaterSumInsured")
	private String floaterSumInsured;

}
