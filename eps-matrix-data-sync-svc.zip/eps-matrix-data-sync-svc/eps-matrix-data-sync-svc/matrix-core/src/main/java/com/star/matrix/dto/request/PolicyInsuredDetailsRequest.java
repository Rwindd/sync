package com.star.matrix.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class PolicyInsuredDetailsRequest {
    @NotBlank
    private String policyNumber;
}
