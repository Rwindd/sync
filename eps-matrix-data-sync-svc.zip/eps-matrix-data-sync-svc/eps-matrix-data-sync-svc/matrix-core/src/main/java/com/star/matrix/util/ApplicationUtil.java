package com.star.matrix.util;

import com.star.matrix.dto.response.zoho.ZohoRenewQuoteResponse;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.MDC;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Supplier;

@Slf4j
@UtilityClass
public class ApplicationUtil {

    private static final String TRACE_ID= "traceId";

    public static <T> CompletableFuture<T> supply(String label, Supplier<T> task, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            log.info("Calling " + label);
            return task.get();
        }, executor);
    }



    public static <T> Supplier<T> wrapWithTrace(Supplier<T> task) {
        String traceId = MDC.get(TRACE_ID);
        return () -> {
            try {
                if (traceId != null) {
                    MDC.put(TRACE_ID, traceId);
                }
                return task.get();
            } finally {
                MDC.remove(TRACE_ID);
            }
        };
    }

    public static String getSafe(List<Object> row, int index) {
        if (index < row.size() && row.get(index) != null) {
            return row.get(index).toString();
        }
        return null;
    }

    public static Double getDoubleSafe(List<Object> row, int index) {
        if (index < row.size() && row.get(index) != null) {
            return Double.valueOf(row.get(index).toString());
        }
        return null;
    }

    public static Boolean getBooleanSafe(List<Object> row, int index) {
        if (index < row.size() && row.get(index) != null) {
            return Boolean.valueOf(row.get(index).toString());
        }
        return null;
    }

    public static LocalDateTime convertToDateTime(Long epochMillis) {
        return Instant.ofEpochMilli(epochMillis)
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();
    }

    public static LocalDate convertToDate(Long epochMillis) {
        return Instant.ofEpochMilli(epochMillis)
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }

    public static Integer getIntegerSafe(List<Object> row, int index) {
        if (row != null && index < row.size() && row.get(index) != null) {
            try {
                String s = row.get(index).toString();
                if (s.isEmpty()) return null;
                int dot = s.indexOf('.');
                if (dot >= 0) {
                    s = s.substring(0, dot);
                    if (s.isEmpty()) s = "0";
                }
                return Integer.valueOf(s);
            } catch (NumberFormatException ex) {
                return null;
            }
        }
        return null;
    }

    public static boolean isZohoRenewQuoteSuccess(ZohoRenewQuoteResponse resp) {
        if (resp == null || resp.getData() == null || resp.getData().isEmpty()) return false;

        return resp.getData().stream()
                .filter(java.util.Objects::nonNull)
                .findFirst()
                .map(d -> "SUCCESS".equalsIgnoreCase(d.getCode()))
                .orElse(false);
    }
}
