package com.star.matrix.entity;

import com.star.matrix.dto.PolicyDataResponse;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Document(collection = "policyError_payloads")
public class PolicyFailedPayload {

    @Id
    private String id;
    private String policyNumber;
    private PolicyDataResponse payload;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;
}
