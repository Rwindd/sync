package com.star.matrix.dto.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MatrixBulkGroupPolicyResponse {
    @JsonProperty("Guid")
    public String guid;
    @JsonProperty("isSuccess")
    @JsonAlias({"isSuccess", "IsSuccess"})
    public boolean isSuccess;
    @JsonProperty("ValidationErrors")
    public List<MatrixBulkPolicyResponse.ValidationError> validationErrors;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ValidationError{
        @JsonProperty("PolicyNumber")
        public String policyNumber;
        @JsonProperty("Errors")
        public String errors;
    }
}
