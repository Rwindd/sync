package com.star.matrix.client;

import com.star.matrix.dto.request.StatementIDRequest;
import com.star.matrix.dto.response.DataBricksResponse;

public interface DataLakeClient {
    DataBricksResponse getDataBricksResponse(StatementIDRequest requestPayload);
    DataBricksResponse getCRMDataBricksResponse(StatementIDRequest requestPayload);

    boolean stopDBConnection();
}
