package com.star.matrix.client;

import com.star.matrix.dto.GroupPolicyData;
import com.star.matrix.dto.PolicyDataResponse;
import com.star.matrix.dto.request.MatrixBulkGroupPolicyRequest;
import com.star.matrix.dto.request.MatrixBulkPolicyRequest;
import com.star.matrix.dto.response.*;

public interface MediAssistClient {

    MatrixPmsResponse hospitalPush(String object);

    MatrixPolicyResponse policyPush(PolicyDataResponse object);

    MatrixBulkPolicyResponse bulkPolicyPush(MatrixBulkPolicyRequest matrixBulkPolicyRequest);

    MatrixGroupPolicyResponse groupPolicyPush(GroupPolicyData matrixGroupPolicyRequest);

    MatrixBulkGroupPolicyResponse bulkGroupPolicyPush(MatrixBulkGroupPolicyRequest matrixBulkPolicyRequest);

}

