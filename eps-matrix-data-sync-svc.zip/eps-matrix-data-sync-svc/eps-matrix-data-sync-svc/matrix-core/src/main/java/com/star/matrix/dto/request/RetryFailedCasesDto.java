package com.star.matrix.dto.request;

import lombok.Data;

@Data
public class RetryFailedCasesDto {
    private boolean policyFlag = true;
    private long startDate;
    private long endDate;
    private int batchSize = 100;
}
