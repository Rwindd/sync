package com.star.matrix.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EnvVariablesResponse {

    private String key;
    private String value;
}
