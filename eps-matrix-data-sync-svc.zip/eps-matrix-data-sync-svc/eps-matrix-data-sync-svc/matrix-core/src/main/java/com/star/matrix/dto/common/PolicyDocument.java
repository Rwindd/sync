package com.star.matrix.dto.common;

import lombok.Data;

@Data
public class PolicyDocument {

    private String policyNo;
    private String proposalNo;
    private String documentType;
    private String documentName;
    private String documentSource;
    private String apiDocumentType;
}
