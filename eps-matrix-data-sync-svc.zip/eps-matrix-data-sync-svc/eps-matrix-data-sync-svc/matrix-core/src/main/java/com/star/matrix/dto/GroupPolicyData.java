package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class GroupPolicyData {
    private String displayIdentifier = "Star_Group_Enrollment";
    private GroupPolicyInfo policyInfo;
    @JsonProperty("GroupMembers")
    private List<GroupPolicyMember> groupMembers;
}
