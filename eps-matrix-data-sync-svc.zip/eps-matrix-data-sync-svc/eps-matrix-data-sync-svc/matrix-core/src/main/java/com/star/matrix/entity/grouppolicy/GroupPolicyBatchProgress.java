package com.star.matrix.entity.grouppolicy;

import com.star.matrix.entity.BatchStatus;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;

import java.time.Instant;
import java.time.LocalDateTime;

@Data
@Document(collection = "group_policy_batch_progress")
public class GroupPolicyBatchProgress {
    @MongoId
    private String id;
    private LocalDateTime date;
    private BatchStatus status;
    private String traceId;
    private int startIndex;
    private int endIndex;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;
}
