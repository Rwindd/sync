package com.star.matrix.dto;

import lombok.Data;

import java.util.List;

@Data
public class GroupPolicyDataResponse {
    private String policyNumber;
    private String policyType;
    private String issuingOfficeNumber;
    private String productCode;
    private String policyStartDate;
    private String policyEndDate;
    private String proposerPolicyHolder;
    private String policyHolderPinCode;
    private String previousYearPolicyNumber;
    private String policyStatus;
    private Long sumInsured;
    private String name;
    private String employeeCode;
    private String dateOfJoining;
    private Long floaterSumInsured;
    private String grade;
    private String insuredRiskId;
    private String masterPolicyNumber;
    private String MasterPolicyStartDate;
    private String MasterPolicyEndDate;

    private List<GroupPolicyBeneficiaryInfo> beneficiariesInfo;

}
