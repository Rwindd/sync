package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;

import java.util.List;

@Data
@Generated
public class PolicyDataResponse {

	@JsonProperty("PolicyInfo")
	private PolicyDetails policyInfo;

	@JsonProperty("BeneficiaryInfo")
	private List<BeneficiariesInfo> beneficiaryInfo;

}
