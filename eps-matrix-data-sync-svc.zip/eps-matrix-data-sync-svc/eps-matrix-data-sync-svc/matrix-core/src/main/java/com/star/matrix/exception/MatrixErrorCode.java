package com.star.matrix.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;

import static com.star.matrix.exception.MatrixErrorCode.ErrorCategory.TECHNICAL;
import static org.springframework.http.HttpStatus.*;

@Getter
@AllArgsConstructor
public enum MatrixErrorCode {
    TECHNICAL_FAILURE(TECHNICAL, "4001", "Something went wrong technically. Please reach out to the team for assistance", INTERNAL_SERVER_ERROR),
    JSON_PARSE_FAILURE(TECHNICAL, "4002", "failed to parse json", INTERNAL_SERVER_ERROR),
    INVALID_PAYLOAD(TECHNICAL, "4003", "Invalid Payload and Failed to parse", BAD_REQUEST),
    DOWNSTREAM_SOCKET_TIMEOUT_ERROR(TECHNICAL, "4004", "Downstream socket timeout", INTERNAL_SERVER_ERROR),
    DOWNSTREAM_HOST_CONNECT_ERROR(TECHNICAL, "4005", "Downstream host connect timeout", INTERNAL_SERVER_ERROR),
    DOWNSTREAM_CONNECT_TIMEOUT_ERROR(TECHNICAL, "4006", "Downstream connect timeout", INTERNAL_SERVER_ERROR),
    DOWNSTREAM_SERVICE_NOT_AVAILABLE(TECHNICAL, "4007", "Downstream service not available", INTERNAL_SERVER_ERROR),
    FAILED_TO_GET_RESPONSE_FROM_DOWN_SYSTEM(TECHNICAL, "4008", "Failed to get response from down stream system", INTERNAL_SERVER_ERROR),
    RESOURCE_NOT_FOUND(TECHNICAL, "805", "Resource not found", NOT_FOUND),
    FAILED_TO_FETCH_STATEMENT_ID_RESPONSE_FROM_DATALAKE(TECHNICAL, "4009", "Failed to get statement id response from datalake", INTERNAL_SERVER_ERROR),
    FAILED_TO_EXECUTE_STATEMENT_FROM_DATALAKE(TECHNICAL, "4009", "Failed to execute statement from datalake", INTERNAL_SERVER_ERROR),
    FAILED_TO_FETCH_POLICY_CLAIM_HISTORY_DATA(TECHNICAL, "4009", "Failed to fetch policy and claim history data", INTERNAL_SERVER_ERROR),
    FAILURE_WHILE_FETCHING_DATA_FROM_DATABRICKS(TECHNICAL, "5001", "Failure while fetching data from databricks", INTERNAL_SERVER_ERROR),
    ERROR_DESERIALIZING_JSON(TECHNICAL, "5002", "Error deserializing JSON", INTERNAL_SERVER_ERROR),
    NO_ENVIRONMENT_VARIABLES_FOUND_FOR_GIVEN_KEY(TECHNICAL, "5003", "No Environment variables found for given key", BAD_REQUEST),
    ENVIRONMENT_VARIABLES_ALREADY_EXISTS_FOR_GIVEN_KEY(TECHNICAL, "5004", "Environment variables already exists for given key", BAD_REQUEST),
    REPORTED_DATE_NOT_FOUND_IN_ENV_VARIABLES(TECHNICAL, "5005", "Reported date not found in env variabled", BAD_REQUEST),
    ONE_TIME_BATCH_ALREADY_IN_PROGRESS(TECHNICAL, "5006", "Batch Already in progress", BAD_REQUEST),
    ONE_TIME_POLICY_SYNC_STOPPED(TECHNICAL, "5007", "One time data sync stopped", BAD_REQUEST),
    ONE_TIME_POLICY_SYNC_ALREADY_IN_PROGRESS(TECHNICAL, "5008", "One time data sync already in progress", BAD_REQUEST),
    ONE_TIME_POLICY_SYNC_STATUS_NOT_FOUND(TECHNICAL, "5009", "One time data status data not found", BAD_REQUEST),
    CONTENTS_MISSING_FOR_CREATING_ENVIRONMENT_VARIABLE(TECHNICAL, "5010", "Contents missing for creating environment variable", BAD_REQUEST),
    CLAIM_NUMBER_IS_NOT_VALID(TECHNICAL,"5012","Claim number is not valid",BAD_REQUEST),
    POLICY_NUMBER_IS_NOT_VALID(TECHNICAL,"5013","Policy number is not valid",BAD_REQUEST),
    FAILED_TO_GENERATE_ZOHO_TOKEN(TECHNICAL, "4001", "Failed to generate ZOHO auth token", INTERNAL_SERVER_ERROR),
    PUBLISHING_FAILED(TECHNICAL, "1004", "failed Publishing  ", HttpStatus.INTERNAL_SERVER_ERROR),
    ONE_TIME_GROUP_POLICY_SYNC_ALREADY_IN_PROGRESS(TECHNICAL, "6001", "One time group policy data sync already in progress", BAD_REQUEST),
    ONE_TIME_GROUP_POLICY_SYNC_STATUS_NOT_FOUND(TECHNICAL, "6002", "One time group policy data status data not found", BAD_REQUEST),
    ONE_TIME_GROUP_POLICY_SYNC_STOPPED(TECHNICAL, "6003", "One time GROUP POLICY data sync stopped", BAD_REQUEST);



    private final ErrorCategory category;
    private final String code;
    private final String displayMessage;
    private final HttpStatus httpStatus;


    public enum ErrorCategory {
        TECHNICAL,
        BUSINESS
    }
}
