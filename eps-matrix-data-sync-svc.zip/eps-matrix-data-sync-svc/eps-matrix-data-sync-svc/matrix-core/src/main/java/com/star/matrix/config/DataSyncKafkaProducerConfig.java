package com.star.matrix.config;

import com.star.matrix.properties.KafkaConfigurationProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Configuration
@RequiredArgsConstructor
@ConditionalOnProperty(value = "kafka.producer.enabled", havingValue = "true")
public class DataSyncKafkaProducerConfig {

    private final KafkaConfigurationProperties kafkaConfigurationProperties;

    private Map<String, Object> producerConfigs() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,   kafkaConfigurationProperties.getBootstrapServers());
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,   StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, kafkaConfigurationProperties.getDeliveryTimeout());
        props.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG,  kafkaConfigurationProperties.getRequestTimeout());
        props.put(ProducerConfig.RETRY_BACKOFF_MS_CONFIG,    kafkaConfigurationProperties.getRetryBackoffMs());
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "data-sync-producer");
        return props;
    }

    @Bean
    public ProducerFactory<String, String> dataSyncProducerFactory() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, String> dataSyncKafkaTemplate() {
        return new KafkaTemplate<>(dataSyncProducerFactory());
    }
}