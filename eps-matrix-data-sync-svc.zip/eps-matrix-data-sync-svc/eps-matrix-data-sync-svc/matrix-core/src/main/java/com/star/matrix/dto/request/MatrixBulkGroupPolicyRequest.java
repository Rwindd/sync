package com.star.matrix.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.dto.GroupPolicyInfo;
import com.star.matrix.dto.GroupPolicyMember;
import lombok.Data;

import java.util.List;

@Data
public class MatrixBulkGroupPolicyRequest {
    private String partnerDisplayName = "Star_Group_Enrollment";
    public List<MatrixBulkGroupPolicyRequest.Batch> batches;

    @Data
    public static class Batch{
        private GroupPolicyInfo policyInfo;
        @JsonProperty("GroupMembers")
        private List<GroupPolicyMember> groupMembers;
    }
}
