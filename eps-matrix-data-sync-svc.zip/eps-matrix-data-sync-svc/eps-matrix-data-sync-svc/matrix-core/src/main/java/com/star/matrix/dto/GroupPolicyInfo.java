package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class GroupPolicyInfo {
    private String policyNumber;
    private String policyType;
    private String issuingOfficeNumber;
    private String productCode;
    private String policyStartDate;
    private String policyEndDate;
    private String proposerPolicyHolder;
    private String policyHolderPinCode;
    private String previousYearPolicyNumber;
    private String policyStatus;
    private String floaterSumInsured;
    @JsonProperty("MasterPolicyNumber")
    private String masterPolicyNumber;
    @JsonProperty("MasterPolicyStartDate")
    private String masterPolicyStartDate;
    @JsonProperty("MasterPolicyEndDate")
    private String masterPolicyEndDate;
}
