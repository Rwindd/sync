package com.star.matrix.entity.zoho;

import com.star.matrix.entity.BatchStatus;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.time.LocalDateTime;

@Data
@Document(collection = "renew_quote_batch_progress")
public class RenewQuoteBatchProgress {
    @Id
    private String id;
    private LocalDateTime date;
    private String traceId;
    private int startIndex;
    private int endIndex;
    private BatchStatus status;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;

}
