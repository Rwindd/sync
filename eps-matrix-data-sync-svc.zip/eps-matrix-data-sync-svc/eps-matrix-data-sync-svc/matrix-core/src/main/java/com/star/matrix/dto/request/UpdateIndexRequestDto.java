package com.star.matrix.dto.request;

import lombok.Data;

@Data
public class UpdateIndexRequestDto {

    private long pullingDate;
    private int startIndex;
    private int endIndex;
}
