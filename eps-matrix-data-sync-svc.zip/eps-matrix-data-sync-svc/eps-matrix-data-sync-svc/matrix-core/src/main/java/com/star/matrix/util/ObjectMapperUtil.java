package com.star.matrix.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.star.matrix.exception.MatrixDataSyncException;
import com.star.matrix.exception.MatrixErrorCode;
import lombok.Getter;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

import static com.star.matrix.util.ApplicationConstant.OBJECT_MAPPING_FAILED;

@Slf4j
@UtilityClass
public class ObjectMapperUtil {

    @Getter
    private final ObjectMapper objectMapper;

    static {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

    }

    public static <T> T convertJsonToObject(String json, Class<T> targetType) {
        try {
            return getObjectMapper().readValue(json, targetType);
        } catch (Exception e) {
            throw new MatrixDataSyncException(MatrixErrorCode.JSON_PARSE_FAILURE, e);
        }
    }

    public static <T> T convertJsonToObject(byte[] jsonBytes, TypeReference<T> typeReference) {
        try {
            return new ObjectMapper().readValue(jsonBytes, typeReference);
        } catch (IOException e) {
            throw new MatrixDataSyncException(MatrixErrorCode.ERROR_DESERIALIZING_JSON,e);
        }
    }

    public static <T> T convertJsonToObject(String json, TypeReference<T> typeReference) {
        try {
            return new ObjectMapper().readValue(json, typeReference);
        } catch (IOException e) {
            throw new MatrixDataSyncException(MatrixErrorCode.ERROR_DESERIALIZING_JSON,e);
        }
    }

    public static <T> T convertJsonToObject(byte[] bytes, Class<T> targetType) {
        try {
            return getObjectMapper().readValue(bytes, targetType);
        } catch (Exception e) {
            throw new MatrixDataSyncException(MatrixErrorCode.JSON_PARSE_FAILURE, e);
        }
    }

    public static <T> String convertObjectToString(T object) {
        try {
            return getObjectMapper().writeValueAsString(object);
        } catch (JsonProcessingException e) {
            log.info(OBJECT_MAPPING_FAILED, e);
            throw new MatrixDataSyncException(MatrixErrorCode.JSON_PARSE_FAILURE, e);
        }
    }

    public static <T> String convertObjectToStringSilently(T object) {
        try {
            return getObjectMapper().writeValueAsString(object);
        } catch (JsonProcessingException e) {
            log.info(OBJECT_MAPPING_FAILED, e);
            return null;
        }
    }

    public static <T> String convertObjectToJson(T object) {
        try {
            return getObjectMapper().writeValueAsString(object);
        } catch (JsonProcessingException e) {
            log.info(OBJECT_MAPPING_FAILED, e);
            return null;
        }
    }
}
