package com.star.matrix.util;

import com.star.matrix.exception.MatrixDataSyncException;
import com.star.matrix.exception.MatrixErrorCode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Slf4j
@Component
@Generated
public class KafkaEventPublisherUtil {

    private KafkaTemplate<String, String> kafkaTemplate;

    public KafkaEventPublisherUtil(
            @Qualifier("dataSyncKafkaTemplate")KafkaTemplate<String, String> kafkaTemplate
    ){
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publishEventToKafkaTopic(String topic, String event){
        try{
            var producerRecord = new ProducerRecord<String, String>(topic, event);
            kafkaTemplate.send(producerRecord);
        } catch (Exception e){
            log.error("Failed to Produce event : {} to kafka.", event, e);
            throw new MatrixDataSyncException(MatrixErrorCode.PUBLISHING_FAILED);
        }
    }
}