package com.star.matrix.dto.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class PolicyDocumentSummary {

    @JsonProperty("PolicyNo")
    private String policyNo;
    private List<DocumentDetail> documentDetails;

    @Data
    public static class DocumentDetail {
        private String documentType;
        private String documentName;
        private String documentSource;
        private String proposalNo;
        private String apiDocumentType;
    }
}
