package com.star.matrix.dto.zoho;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.star.matrix.util.Generated;
import lombok.Data;

@Generated
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class RenewalQuoteEncrypt {

    private String intermediatorEmailE;
    private Integer numberOfYear;
    private String proposerEmailIdE;
    private String policyFromDate;
    private String gracePeriodEndDate;
    private String premiaConvertedPolicyTotalPremium;
    private String salesManagerPhoneE;
    private String installmentPremiumAmount;
    private String officeCode;
    private String productCode;
    private String branchManagerName;
    private String paymentDate;
    private String installmentTax;
    private String source;
    private String proposalType;
    private String previousPolicyNumber;
    private String currencyPolicyPremiumGst;
    private String renewalPaymentType;
    private String intermediaryCode;
    private String fulfillerCode;
    private String currentPremiumTax;
    private String pinCode;
    private String policyConvertedDate;
    private String premiaCurrentPolicySumInsured;
    private String renewalStatus;
    private String installmentTotalPremium;
    private String ncb;
    private String intermediaryName;
    private String branchManagerPhNo;
    private String environment;
    private String branchManagerCode;
    private String intermediatorPhoneE;
    private String secondaryEmail;
    private String emiPolicy;
    private String divisonCode;
    private String recordReceivedFromSystem;
    private String proposerContactNoE;
    private String renewalLocation;
    private String workflowTrigger;
    private String paymentStatus;
    private String renewalId;
    private String policyToDate;
    private String renewalPolicyRefNo;
    private String policyRenewed;
    private String premiaCurrentPolicyNo;
    private String paymentMode;
    private String installmentYear;
    private String sumInsured;
    private String currentPolicyPremiumTotalAmount;
    private String premiaConvertedPremiumAmount;
    private String contactName;
    private String premiaConvertedPolicyNo;
    private String premiumAmount;
    private String claimStatus;
    private String premiaContactCode;
    private String currentPolicyPremiumAmount;
    private String currentPolicyNumber;
    private String productName;
    private String currentPremiumTotal;
    private String premiaConvertedPolicyGst;
    private String renewalAddress3;
    private String renewalAddress1;
    private String ncdIssued;
    private String salesManagerName;
    private String noOfInstallment;
    private String renewalAddress2;

    private String upsellSumInsured1;
    private String upsellPremium1;
    private String upsellGst1;
    private String upsellTotal1;
    private String upsellSumInsured2;
    private String upsellPremium2;
    private String upsellGst2;
    private String upsellTotal2;
    private String upsellSumInsured3;
    private String upsellPremium3;
    private String upsellGst3;
    private String upsellTotal3;
    private String upsellSumInsured4;
    private String upsellPremium4;
    private String upsellGst4;
    private String upsellTotal4;
    private String upsellSumInsured5;
    private String upsellPremium5;
    private String upsellGst5;
    private String upsellTotal5;


}
