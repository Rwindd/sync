package com.star.matrix.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Data
@Generated
@Document(collection = "policy_Index_Ranges")
public class PolicyIndexRange {

	@Id
	private String id;

	@JsonProperty("start_index")
	private int startIndex;

	@JsonProperty("end_index")
	private int endIndex;

	private String name;

	private LocalDateTime date;

	@CreatedDate
	private LocalDateTime createdAt;

	@LastModifiedDate
	private LocalDateTime updatedAt;
}