package com.star.matrix.dto.request;

import lombok.Data;

@Data
public class OneTimeBatchRemoveRequest {

    private boolean removeStatusCollection;
    private boolean removeProgressCollection;
}
