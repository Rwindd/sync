package com.star.matrix.entity;

public enum HospitalFlagName {
    RAW, SUSPICIOUS, EXCLUDED
}