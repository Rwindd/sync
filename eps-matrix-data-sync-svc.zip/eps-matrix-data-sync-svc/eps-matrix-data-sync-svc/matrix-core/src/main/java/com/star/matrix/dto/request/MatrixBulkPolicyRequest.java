package com.star.matrix.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.dto.BeneficiariesInfo;
import com.star.matrix.dto.PolicyDetails;
import lombok.Data;

import java.util.List;

@Data
public class MatrixBulkPolicyRequest {
    public String traceId;
    public List<Batch> batches;

    @Data
    public static class Batch{

        @JsonProperty("PolicyInfo")
        private PolicyDetails policyInfo;

        @JsonProperty("BeneficiaryInfo")
        private List<BeneficiariesInfo> beneficiaryInfo;
    }
}
