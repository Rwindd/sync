package com.star.matrix.dto.common;

import lombok.Data;

import java.util.List;

@Data
public class ClaimHistorySummary {

    private String policyNumber;
    private List<ClaimHistory> claimHistories;
}
