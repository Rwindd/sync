package com.star.matrix.dto.postgres;

import lombok.Data;

@Data
public class PostgresPolicyDocument {
    private String policyNo;
    private String proposalNo;
    private String documentType;
    private String documentName;
    private String documentSource;
    private String apiDocumentType;
}
