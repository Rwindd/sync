package com.star.matrix.dto.request;

import com.star.matrix.entity.BatchStatus;
import lombok.Data;

import java.util.List;

@Data
public class OneTimeBatchUpdateRequest {

    private String command;
    private List<BatchStatus> statuses;
    private Integer fromIndex;
    private Integer endIndex;
    private boolean matrixSuccess;
}
