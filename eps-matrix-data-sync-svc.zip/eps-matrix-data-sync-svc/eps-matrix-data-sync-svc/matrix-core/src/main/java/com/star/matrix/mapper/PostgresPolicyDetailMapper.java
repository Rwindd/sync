package com.star.matrix.mapper;

import com.star.matrix.dto.postgres.PostgresPolicyDetail;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

@Component
@Slf4j
public class PostgresPolicyDetailMapper implements RowMapper<PostgresPolicyDetail> {

    @Override
    public PostgresPolicyDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
        PostgresPolicyDetail detail = new PostgresPolicyDetail();

        try {
            // Map all fields with proper error handling
            detail.setPolicyNo(getString(rs, "policy_no"));
            detail.setPolicyFromDate(getString(rs, "policy_from_date"));
            detail.setPolicyToDate(getString(rs, "policy_to_date"));
            detail.setUwYear(getString(rs, "uw_year"));
            detail.setPreviousPolicyNo(getString(rs, "previous_policy_no"));
            detail.setInsuredName(getString(rs, "INSURED_NAME"));
            detail.setGender(getString(rs, "Gender"));
            detail.setDob(getString(rs, "DOB"));
            detail.setRelation(getString(rs, "Relation"));
            detail.setMemberSumInsured(getString(rs, "member_sum_insured"));
            detail.setPed(getString(rs, "PED"));
            detail.setHealthId(getString(rs, "HEALTH_ID"));
            detail.setPolicyInceptionDate(getString(rs, "POLICY_INCEPTION_DATE"));
            detail.setPolicyType(getString(rs, "POLICY_TYPE"));
            detail.setEffectiveFrom(getString(rs, "effectivefrom"));
            detail.setEffectiveTo(getString(rs, "effectiveto"));
            detail.setInsuredInceptionDate(getString(rs, "insured_inception_Date"));
            detail.setProductName(getString(rs, "product_name"));

            // Handle numeric conversion properly
            detail.setPolicySumInsured(formatPolicySumInsured(rs));

        } catch (SQLException e) {
            log.error("Error mapping row {} for policy: {}", rowNum, getString(rs, "policy_no"), e);
            throw e;
        }

        return detail;
    }

    private String getString(ResultSet rs, String column) throws SQLException {
        String value = rs.getString(column);
        return rs.wasNull() ? null : value;
    }

    private String formatPolicySumInsured(ResultSet rs) throws SQLException {
        Object value = rs.getObject("policy_sum_insured");
        if (rs.wasNull()) {
            return null;
        }
        try {
            if (value instanceof Number) {
                BigDecimal bd = value instanceof BigDecimal
                        ? (BigDecimal) value
                        : BigDecimal.valueOf(((Number) value).doubleValue());

                return bd.toPlainString();
            }
            return value.toString();
        } catch (Exception e) {
            log.warn("Failed to format policy_sum_insured value: {}", value, e);
            return value.toString();
        }
    }
}
