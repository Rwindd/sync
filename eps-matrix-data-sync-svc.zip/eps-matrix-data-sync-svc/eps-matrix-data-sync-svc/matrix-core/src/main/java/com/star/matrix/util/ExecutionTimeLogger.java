package com.star.matrix.util;

import lombok.extern.slf4j.Slf4j;

import java.util.function.Supplier;

@Slf4j
public class ExecutionTimeLogger {

    private ExecutionTimeLogger(){

    }

    // Utility method for tasks with a return value
    public static <T> T logExecutionTime(String taskName, Supplier<T> task) {
        long startTime = System.currentTimeMillis();
        T result = task.get();
        long endTime = System.currentTimeMillis();
        log.info("{} took {} ms", taskName, endTime - startTime);
        return result;
    }

    // Utility method for tasks without a return value
    public static void logExecutionTime(String taskName, Runnable task) {
        long startTime = System.currentTimeMillis();
        task.run();
        long endTime = System.currentTimeMillis();
        log.info("{} took {} ms", taskName, endTime - startTime);
    }
}
