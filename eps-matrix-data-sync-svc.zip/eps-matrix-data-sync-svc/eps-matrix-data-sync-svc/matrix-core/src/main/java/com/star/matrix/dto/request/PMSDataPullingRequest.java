package com.star.matrix.dto.request;

import lombok.Data;
import lombok.NonNull;

@Data
public class PMSDataPullingRequest {

	@NonNull
	private Long startDateTime;
	@NonNull
	private Long endDateTime;
}
