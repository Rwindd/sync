package com.star.matrix.dto.request;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.star.matrix.dto.HospitalDetail;
import com.star.matrix.util.Generated;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MatrixHospitalPayload extends HospitalDetail {

    private List<MatrixPackageDetail> packageDetails;
    private List<MatrixDocumentDetail> documentDetails;
}
