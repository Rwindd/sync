package com.star.matrix.entity.zoho;

public enum RenewQuoteBatchStatus {
    COMPLETED
}
