package com.star.matrix.common;

import com.star.matrix.util.ObjectMapperUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;

@Slf4j
public class RequestResponseLogger {

    private RequestResponseLogger() {
    }

    public static <T> void logRequest(RequestEntity<T> requestEntity) {

        log.info("======= http api request logging begin ===========");
        log.info("URI         : {}", requestEntity.getUrl());
        log.info("Method      : {}", requestEntity.getMethod());
        log.info("Headers     : {}", requestEntity.getHeaders());
        String requestBody = ObjectMapperUtil.convertObjectToString(requestEntity.getBody());
        log.info("Request body: {}", requestBody);
        log.info("======= http api request logging ends ============");
    }

    public static <T> void logResponse(ResponseEntity<T> responseEntity) {

        log.info("====== http api response logging begin ============");
        log.info("Status code  : {}", responseEntity.getStatusCode());
        log.info("Headers      : {}", responseEntity.getHeaders());
        log.info("Response body: {}", responseEntity.getBody());
        log.info("====== http api response logging ends  ============");
    }

}

