package com.star.matrix.entity;

public enum BatchStatus {

    COMPLETED, FAILED, NO_DATA, RETRY
}
