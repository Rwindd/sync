package com.star.matrix.dto.common;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@RequiredArgsConstructor
public class PolicyMemberDetailSummary {

    private String policyNo;
    private String policyFromDate;
    private String policyToDate;
    private String uwYear;
    private String sumInsured;
    private String productName;
    private String previousPolicyNo;
    private String policySource;
    private String policyInceptionDate;
    private String policyType;
    private List<Member> members;

    @Data
    public static class Member {
        private String insuredName;
        private String healthId;
        private String gender;
        private String dob;
        private String relation;
        private String sumInsured;
        private String ped;
        private String effectiveFrom;
        private String effectiveTo;
        private String insuredInceptionDate;
    }
}
