package com.star.matrix.util;

public class ApplicationConstant {

    private ApplicationConstant(){

    }

    public static final String DATALAKE_CLIENT_API_PROCESSOR = "DATALAKE_CLIENT_API_PROCESSOR";

    public static final String POLICY_HISTORY_API_CONTROLLER_PROCESSOR = "POLICY_HISTORY_API_CONTROLLER_PROCESSOR";

    public static final String OBJECT_MAPPING_FAILED = "Object mapping failed";


}
