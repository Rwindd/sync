package com.star.matrix.client;

import com.star.matrix.dto.response.zoho.ZohoRenewQuoteResponse;
import com.star.matrix.dto.response.zoho.ZohoTokenResponse;

public interface ZohoClient {

    ZohoTokenResponse getAuthToken();
    ZohoRenewQuoteResponse renewQuotePush(String object, String token);
}
