package com.star.matrix.entity.zoho;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.dto.zoho.RenewalQuoteEncrypt;
import com.star.matrix.enumeration.RequestStatus;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Document(collection = "renew_quote_payload")
public class RenewQuotePayload {
    @Id
    private String id;
    private String recordId;
    @JsonProperty("STATUS")
    private RequestStatus status;
    private String renewalPolicyRefNo;
    private Integer retryCount;
    private RenewalQuoteEncrypt renewalQuoteEncrypt;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;
}
