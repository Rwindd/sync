package com.star.matrix.entity.grouppolicy;

public enum GroupPolicyBatchStatus {
    COMPLETED
}
