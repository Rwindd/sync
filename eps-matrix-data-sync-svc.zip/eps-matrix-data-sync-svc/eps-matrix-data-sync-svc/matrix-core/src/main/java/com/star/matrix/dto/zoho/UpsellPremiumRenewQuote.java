package com.star.matrix.dto.zoho;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;

@Generated
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class UpsellPremiumRenewQuote {
    @JsonProperty("Upsell_Premium_Amount")
    public String upsellPremiumAmount;
    @JsonProperty("Upsell_Sum_Insured")
    public String upsellSumInsured;
    @JsonProperty("GST")
    public String gst;
    @JsonProperty("Upsell_TOTAL")
    public String upsellTotal;
}
