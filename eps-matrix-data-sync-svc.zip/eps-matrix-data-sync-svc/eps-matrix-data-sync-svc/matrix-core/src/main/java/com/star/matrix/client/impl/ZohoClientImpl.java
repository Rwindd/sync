package com.star.matrix.client.impl;

import com.star.matrix.client.ZohoClient;
import com.star.matrix.common.RequestResponseLogger;
import com.star.matrix.dto.response.zoho.ZohoRenewQuoteResponse;
import com.star.matrix.dto.response.zoho.ZohoTokenResponse;
import com.star.matrix.exception.MatrixDataSyncException;
import com.star.matrix.exception.MatrixErrorCode;
import com.star.matrix.properties.ApplicationProperties;
import com.star.matrix.resttemplate.RestTemplateName;
import com.star.matrix.util.ExecutionTimeLogger;
import com.star.matrix.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ZohoClientImpl implements ZohoClient {

    public static final String ZOHO_RENEW_QUOTE_PUSH_API_CALL = "Zoho renew quote push Api Call";
    public static final String ZOHO_TOKEN_GENERATE_CALL = "Zoho token generate Api Call";

    private final Map<RestTemplateName, RestTemplate> restTemplateMap;
    private final ApplicationProperties applicationProperties;


    @Override
    public ZohoTokenResponse getAuthToken() {
        log.info("Request received to call Zoho to generate token");
        return ExecutionTimeLogger.logExecutionTime(ZOHO_TOKEN_GENERATE_CALL, () -> {
            try {

                HttpHeaders headers = new HttpHeaders();
                MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
                form.add("refresh_token", applicationProperties.getZohoRefreshToken());
                form.add("client_id", applicationProperties.getZohoClientId());
                form.add("client_secret", applicationProperties.getZohoClientSecret());
                form.add("grant_type", applicationProperties.getZohoGrantType());

                URI uri = new URI(applicationProperties.getZohoTokenGenerateUrl());

                RequestEntity<MultiValueMap<String, String>> requestEntity =
                        new RequestEntity<>(form, headers,HttpMethod.POST, uri);

                RequestResponseLogger.logRequest(requestEntity);

                ResponseEntity<ZohoTokenResponse> responseEntity = restTemplateMap
                        .get(RestTemplateName.ZOHO_SERVICE)
                        .exchange(requestEntity, new ParameterizedTypeReference<ZohoTokenResponse>() {});

                if (responseEntity.getStatusCode() == HttpStatus.OK) {
                    ZohoTokenResponse body = responseEntity.getBody();
                    if (body != null && body.getAccessToken() != null) {
                        RequestResponseLogger.logResponse(responseEntity);
                        return body;
                    }
                    log.error("Zoho token response body is null or missing access token: {}", body);
                } else {
                    log.error("Zoho token call failed with status: {} body: {}",
                            responseEntity.getStatusCode(), responseEntity.getBody());
                }

                throw new MatrixDataSyncException(MatrixErrorCode.FAILED_TO_GENERATE_ZOHO_TOKEN);
            } catch (Exception e) {
                log.error("Error occurred while calling Zoho token API", e);
                throw new MatrixDataSyncException(MatrixErrorCode.FAILED_TO_GENERATE_ZOHO_TOKEN, e);
            }
        });
    }

    @Override
    public ZohoRenewQuoteResponse renewQuotePush(String object, String token) {
        log.info("Request received to call zoho to push renew quote data : {} ", ObjectMapperUtil.convertObjectToString(object));
        return ExecutionTimeLogger.logExecutionTime(ZOHO_RENEW_QUOTE_PUSH_API_CALL, () -> {
            try {

                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.TEXT_PLAIN);
                headers.add("Authorization", "Zoho-oauthtoken " + token);
                RequestEntity<Object> requestEntity = new RequestEntity<>(object, headers, HttpMethod.POST,
                        new URI(applicationProperties.getRenewQuotePushUrl()));
                RequestResponseLogger.logRequest(requestEntity);
                ResponseEntity<String> responseEntity = restTemplateMap
                        .get(RestTemplateName.ZOHO_SERVICE)
                        .exchange(requestEntity, new ParameterizedTypeReference<>(){
                        });
                log.info("Response Body : {}", responseEntity);
                return ObjectMapperUtil.convertJsonToObject(responseEntity.getBody(), ZohoRenewQuoteResponse.class);
            } catch (Exception exception) {
                log.error("Error occurred with calling Zoho", exception);
                return new ZohoRenewQuoteResponse();
            }
        });
    }
}
