package com.star.matrix.entity.grouppolicy;

import com.star.matrix.entity.PolicyBatchStatus;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;

import java.time.Instant;
import java.time.LocalDateTime;

@Data
@Document(collection = "group_policy_batch_detail")
public class GroupPolicyBatchDetail {
    @MongoId
    private String id;
    private GroupPolicyBatchStatus groupPolicyBatchStatus;
    private LocalDateTime date;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;
}
