package com.star.matrix.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class AppConstant {

    public static final String SUCCESS = "200";

    public static final String BAD_REQUEST = "400";

    public static final String UN_AUTHORIZED = "401";

    public static final String FAILURE_CODE = "500";

    public static final String SUCCESS_RESPONSE = "SUCCESS";

    public static final String BAD_RESPONSE = "BAD_REQUEST";

    public static final String FAILURE_RESPONSE = "FAILED";

    public static final String CIRCUIT_BREAKER_OPEN = "CB_OPEN";

    public static final String CIRCUIT_BREAKER_CLOSE = "CB_CLOSE";

    public static final String CIRCUIT_BREAKER_HALF_OPEN = "HALF_OPEN";

    public static final String CIRCUIT_BREAKER_NAME = "externalApiCircuitBreaker";

    public static final String CIRCUIT_BREAKER_FALLBACK = "fallbackResponse";
    public static final String CLIENT_BANCS = "BANCS_CLIENT";
    public static final String EVENT_ID = "event_id";
    public static final String PARENT_EVENT_ID = "parent_event_id";
    public static final String EVENT_NAME = "event_name";
    public static final String PUBLISHER_NAME = "publisher_name";

    public static final String DATA_LAKE_CLIENT_ID = "DATA_LAKE_CLIENT";
    public static final String MATRIX_CLIENT_ID = "DATA_LAKE_CLIENT";

}
