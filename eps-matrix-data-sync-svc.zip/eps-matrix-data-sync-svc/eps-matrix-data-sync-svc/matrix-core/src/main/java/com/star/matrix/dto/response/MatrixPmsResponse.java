package com.star.matrix.dto.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
@Data
public class MatrixPmsResponse {

    @JsonProperty("isSuccess")
    @JsonAlias({"isSuccess", "IsSuccess"})
    private Boolean isSuccess;

    private String message;
}