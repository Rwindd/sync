package com.star.matrix.logging;

import com.star.eps.models.LoggingDto;
import com.star.matrix.util.ObjectMapperUtil;

public class PolicyHistoryControllerApiProcessorImpl extends CommonLogging {

    @Override
    public void populateRequestFields(LoggingDto loggingDto, Object[] arguments) {
        loggingDto.setRequest(ObjectMapperUtil.convertObjectToStringSilently(arguments[0]));
    }


}
