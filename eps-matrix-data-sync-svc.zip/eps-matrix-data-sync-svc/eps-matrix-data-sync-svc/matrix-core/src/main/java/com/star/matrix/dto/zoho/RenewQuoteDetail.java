package com.star.matrix.dto.zoho;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;

import java.util.List;

@Generated
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class RenewQuoteDetail {

    @JsonProperty("Intermediator_Email")
    public String intermediatorEmail;
    @JsonProperty("Number_of_Year")
    public Integer numberOfYear;
    @JsonProperty("Email")
    public String email;
    @JsonProperty("From_Date")
    public String fromDate;
    @JsonProperty("Grace_Period_End_Date")
    public String gracePeriodEndDate;
    @JsonProperty("Premia_Converted_Policy_Total_Premium")
    public Object premiaConvertedPolicyTotalPremium;
    @JsonProperty("Sales_Manager_Phone")
    public String salesManagerPhone;
    @JsonProperty("Installment_Premium_amount")
    public String installmentPremiumamount;
    @JsonProperty("Premia_Division_Name")
    public String premiaDivisionName;
    @JsonProperty("Premia_Product_Code")
    public String premiaProductCode;
    @JsonProperty("Branch_Manager_Name")
    public Object branchManagerName;
    @JsonProperty("Payment_Date")
    public Object paymentDate;
    @JsonProperty("Installment_Tax")
    public String installmentTax;
    @JsonProperty("Policy_Source")
    public String policySource;
    @JsonProperty("Renewal_Policy_Type")
    public String renewalPolicyType;
    @JsonProperty("Previous_Policy_No")
    public String previousPolicyNo;
    @JsonProperty("Currency_Policy_Premium_GST")
    public String currencyPolicyPremiumGST;
    @JsonProperty("Renewal_Payment_Type")
    public Object renewalPaymentType;
    @JsonProperty("Intermediator_Code")
    public String intermediatorCode;
    @JsonProperty("Sales_Manager_Code")
    public String salesManagerCode;
    @JsonProperty("Service_Tax")
    public String serviceTax;
    @JsonProperty("Renewal_Policy_Pincode")
    public String renewalPolicyPincode;
    @JsonProperty("Policy_Converted_Date")
    public Object policyConvertedDate;
    @JsonProperty("Premia_Current_Policy_Sum_Insured")
    public String premiaCurrentPolicySumInsured;
    @JsonProperty("Upsell_Premium")
    public List<UpsellPremiumRenewQuote> upsellPremium;
    @JsonProperty("Renewal_Status")
    public String renewalStatus;
    @JsonProperty("Installment_Total_Premium")
    public String installmentTotalPremium;
    @JsonProperty("NCB")
    public String ncb;
    @JsonProperty("Intermediator_Name")
    public String intermediatorName;
    @JsonProperty("Branch_Manager_Mobile")
    public Object branchManagerMobile;
    @JsonProperty("Environment")
    public String environment;
    @JsonProperty("Branch_Manager_Code")
    public Object branchManagerCode;
    @JsonProperty("Intermediator_Phone")
    public String intermediatorPhone;
    @JsonProperty("Secondary_Email")
    public String secondaryEmail;
    @JsonProperty("Emi_Policy")
    public String emiPolicy;
    @JsonProperty("Divison_Code")
    public String divisonCode;
    @JsonProperty("Record_received_from_system")
    public String recordReceivedFromSystem;
    @JsonProperty("Proposer_Contact_No")
    public String proposerContactNo;
    @JsonProperty("Renewal_Location")
    public String renewalLocation;
    @JsonProperty("Workflow_trigger")
    public String workflowTrigger;
    @JsonProperty("Payment_Status")
    public Object paymentStatus;
    @JsonProperty("Renewal_ID")
    public Object renewalID;
    @JsonProperty("Expire_Date")
    public String expireDate;
    @JsonProperty("Renewal_Policy_Ref_No")
    public String renewalPolicyRefNo;
    @JsonProperty("Policy_Renewed")
    public Object policyRenewed;
    @JsonProperty("Premia_Current_Policy_No")
    public String premiaCurrentPolicyNo;
    @JsonProperty("Payment_Mode")
    public Object paymentMode;
    @JsonProperty("Installment_Year")
    public String installmentYear;
    @JsonProperty("Sum_Insured")
    public String sumInsured;
    @JsonProperty("Current_Policy_Premium_Total_Amount")
    public String currentPolicyPremiumTotalAmount;
    @JsonProperty("Premia_Converted_Premium_Amount")
    public Object premiaConvertedPremiumAmount;
    @JsonProperty("Contact_Name")
    public String contactName;
    @JsonProperty("Premia_Converted_Policy_No")
    public Object premiaConvertedPolicyNo;
    @JsonProperty("Premium_Amount")
    public String premiumAmount;
    @JsonProperty("Claim_Status")
    public String claimStatus;
    @JsonProperty("Premia_Contact_Code")
    public Object premiaContactCode;
    @JsonProperty("Current_Policy_Premium_amount")
    public String currentPolicyPremiumAmount;
    @JsonProperty("Premia_Product_Name")
    public String premiaProductName;
    @JsonProperty("Total")
    public String total;
    @JsonProperty("Sys_Created_by")
    public String sysCreatedBy;
    @JsonProperty("Premia_Converted_Policy_GST")
    public Object premiaConvertedPolicyGST;
    @JsonProperty("Renewal_Address3")
    public String renewalAddress3;
    @JsonProperty("Branch_Manager_Phone")
    public Object branchManagerPhone;
    @JsonProperty("Sys_Created_date")
    public String sysCreateddate;
    @JsonProperty("NCD_Issued")
    public String ncdIssued;
    @JsonProperty("Renewal_Address1")
    public String renewalAddress1;
    @JsonProperty("Sales_Manager_Name")
    public String salesManagerName;
    @JsonProperty("No_of_Installment")
    public String noOfInstallment;
    @JsonProperty("Renewal_Address2")
    public String renewalAddress2;
}
