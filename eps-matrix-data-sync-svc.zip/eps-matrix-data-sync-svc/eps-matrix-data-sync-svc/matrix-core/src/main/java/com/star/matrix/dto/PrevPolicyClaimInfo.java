package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;

@Generated
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class PrevPolicyClaimInfo {

	@JsonProperty("POLICY_NO")
	private String policyNo;

	@JsonProperty("HEALTH_ID")
	private String healthId;

	@JsonProperty("POLICY_YEAR")
	private String policyYear;

	@JsonProperty("CLAIM_NUMBER")
	private String claimNumber;

	@JsonProperty("CLAIM_TYPE")
	private String claimType;

	@JsonProperty("INSURED_PATIENT_NAME")
	private String insuredPatientName;

	@JsonProperty("INTIMATION_NUMBER")
	private String intimationNumber;

	@JsonProperty("DATE_OF_ADMISSION")
	private String dateOfAdmission;

	@JsonProperty("CLAIM_STATUS")
	private String claimStatus;

	@JsonProperty("CLAIM_AMOUNT")
	private String claimAmount;

	@JsonProperty("APPROVED_AMOUNT")
	private String approvedAmount;

	@JsonProperty("HOSPITAL_DETAILS")
	private String hospitalDetails;

	@JsonProperty("DIAGNOSIS")
	private String diagnosis;

	@JsonProperty("SUBLIMIT_NAME")
	private String subLimitName;

	@JsonProperty("SUBLIMIT_AMOUNT")
	private String subLimitAmount;

	@JsonProperty("ICD_CODE")
	private String icdCode;

	@JsonProperty("SUB_LIMIT_CATEGORY")
	private String subLimitCategory;

	@JsonProperty("PED")
	private String ped;

	@JsonProperty("SI_RESTRICTION")
	private String siRestriction;

	@JsonProperty("CO_PAY")
	private String coPay;

	@JsonProperty("CATARACT_DETAILS")
	private String cataractDetails;

	@JsonProperty("DONOR_COVER")
	private String donorCover;

	@JsonProperty("INTIMATION_SOURCE")
	private String intimationSource;

	@JsonProperty("CLAIM_PROCESSED")
	private String claimProcessed;
}
