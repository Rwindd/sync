package com.star.matrix.shared;

import lombok.Data;

@Data
public class SharedData {
    private String clientId;
    private String sourceName;
}
