package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;

@Generated
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class PrevPolicyInfo {

	@JsonProperty("POLICY_NO")
	private String policyNo;

	@JsonProperty("POLICY_FROM_DATE")
	private String policyFromDate;

	@JsonProperty("POLICY_TO_DATE")
	private String policyToDate;

	@JsonProperty("UW_YEAR")
	private String uwYear;

	@JsonProperty("SUM_INSURED")
	private String sumInsured;

	@JsonProperty("PRODUCT_NAME")
	private String productName;

	@JsonProperty("PREVIOUS_POLICY_NO")
	private String previousPolicyNo;

	@JsonProperty("POLICY_SOURCE")
	private String policySource;
}
