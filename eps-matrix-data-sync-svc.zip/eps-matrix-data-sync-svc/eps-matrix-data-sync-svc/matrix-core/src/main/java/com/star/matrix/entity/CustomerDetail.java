package com.star.matrix.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDetail {
    private String policyNumber;
    private String healthId;
    private String proposerName;
    private String insuredName;
    private String insuredAge;
    private String planType;
    private String policyType;
    private String proposerPincode;
    private String premiumAmount;
    private String sumInsured;
    private String childrenCount;
    private String adultCount;
    private String riskSrNo;
    private String ageType;
    private String agentCode;
    private String agentName;
    private String agentMobileNoE;
    private String proposerMobileNoE;
    private String insuredMobileNoE;
    private String intermediaryType;
    private String advisorName;
    private String advisorContact;
}
