package com.star.matrix.entity.grouppolicy;

import com.star.matrix.entity.BatchStatus;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;

import java.time.Instant;

@Data
@Document(collection = "one_time_group_policy_batch_progres")
public class OneTimeGroupPolicyBatchProgress {
    @MongoId
    private String id;
    private BatchStatus status;
    private long startIndex;
    private long endIndex;
    private boolean isMatrixSuccess;
    private int retries;
    private String traceId;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;
}
