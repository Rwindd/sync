package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PrimaryBeneficiaryInfo {
    @JsonProperty("Name")
    private String name;
    @JsonProperty("EmployeeCode")
    private String employeeCode;
    @JsonProperty("DateOfJoining")
    private String dateOfJoining;
    @JsonProperty("FloaterSumInsured")
    private String floaterSumInsured;
    @JsonProperty("Grade")
    private String grade;
    @JsonProperty("RiskId")
    private String riskId;
}

