package com.star.matrix.entity;

import lombok.Data;

@Data
public class HospitalFlag {
    private HospitalFlagName flag;
    private String date;
    private String reason;
}
