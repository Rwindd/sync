package com.star.matrix.dto.postgres;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class PostgresPolicyDetail {
    private String policyNo;
    private String policyFromDate;
    private String policyToDate;
    private String uwYear;
    private String policySumInsured;
    private String previousPolicyNo;
    private String insuredName;
    private String gender;
    private String dob;
    private String relation;
    private String memberSumInsured;
    private String ped;
    private String healthId;
    private String policyInceptionDate;
    private String policyType;
    private String effectiveFrom;
    private String effectiveTo;
    private String insuredInceptionDate;
    private String productName;
}