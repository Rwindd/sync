package com.star.matrix.properties;

import lombok.Data;
import lombok.Generated;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@Generated
@ConfigurationProperties(prefix = "kafka.config")
public class KafkaConfigurationProperties {
    private String bootstrapServers;
    private int requestTimeout;
    private int deliveryTimeout;
    private int retryBackoffMs;
    private int concurrencyThreads;
    private long pollTimeout;
    private boolean enableIdempotenceConfig;
    private String acksConfig;
    private int maxPollRecord;
    private int heartbeatRate;
}
