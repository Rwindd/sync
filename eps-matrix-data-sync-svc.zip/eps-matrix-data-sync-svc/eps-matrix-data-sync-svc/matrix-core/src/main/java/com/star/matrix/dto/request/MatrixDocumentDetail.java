package com.star.matrix.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MatrixDocumentDetail {

    private String documentID;
    private String shaiHospitalId;
    private String documentType;
    private String documentName;
    private boolean documentIsActive = true;
}
