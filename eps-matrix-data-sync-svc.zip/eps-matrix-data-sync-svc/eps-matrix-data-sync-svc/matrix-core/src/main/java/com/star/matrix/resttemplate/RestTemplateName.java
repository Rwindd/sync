package com.star.matrix.resttemplate;

public enum RestTemplateName {
    MATRIX_SERVICE("matrix.service"),
    DATA_LAKE_SERVICE("datalake.service"),
    ZOHO_SERVICE("zoho.service")
    ;
    final String prefix;

    RestTemplateName(String prefix) {
        this.prefix = prefix;
    }
}

