package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;

import java.util.List;

@Generated
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class PrevPolicyDataResponse {

	@JsonProperty("PrevPolicyInfo")
	private PrevPolicyInfo prevPolicyInfo;

	@JsonProperty("MEMBER")
	private List<PrevPolicyMemberInfo> member;

	@JsonProperty("Document")
	private List<PrevPolicyDocument> document;

	@JsonProperty("Claim")
	private List<PrevPolicyClaimInfo> claim;

	@JsonProperty("documents")
	private List<PrevPolicyClaimDocument> documents;
}
