package com.star.matrix.logging;

import com.star.eps.events.LoggingEvent;
import com.star.eps.models.LoggableRequestContext;
import com.star.eps.models.LoggingDto;
import com.star.matrix.constant.AppConstant;
import com.star.matrix.exception.MatrixDataSyncException;
import com.star.matrix.properties.ApplicationProperties;
import com.star.matrix.util.CommonUtil;
import com.star.matrix.util.ObjectMapperUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

@Slf4j
public class DataLakeClientProcessorImpl implements LoggingEvent<LoggingDto> {

    private ApplicationProperties applicationProperties;

    @Override
    public String getApiName(LoggingDto loggingInfo) {
        return loggingInfo.getApiName();
    }

    @Override
    public LoggingDto generateNewLoggingSchema(String actionName) {
        LoggingDto dto = new LoggingDto();
        dto.setApiName(actionName);
        dto.setClientId(AppConstant.DATA_LAKE_CLIENT_ID);
        return dto;
    }

    @Override
    public void populateRequestFields(LoggingDto loggingSchema, Object[] arguments) {
        loggingSchema.setRequest(ObjectMapperUtil.convertObjectToStringSilently(arguments[0]));

    }

    @Override
    public void populateExceptionDetails(LoggingDto loggingSchema, Throwable throwable) {
        loggingSchema.setException(throwable.getMessage());
        loggingSchema.setStatus(AppConstant.FAILURE_RESPONSE);
        if (throwable instanceof MatrixDataSyncException e) {
            loggingSchema.setResponseCode(String.valueOf(e.getMatrixErrorCode().getHttpStatus().value()));
        } else
            loggingSchema.setResponseCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
        loggingSchema.setMessage("Databricks API Call Failed");
    }

    @Override
    public void populateResponseFields(LoggingDto loggingSchema, Object apiResponse) {
        if (apiResponse instanceof ResponseEntity<?> responseEntity) {
            loggingSchema.setResponseCode(String.valueOf(responseEntity.getStatusCode().value()));
            loggingSchema.setResponse(ObjectMapperUtil.convertObjectToStringSilently(responseEntity));
            if (responseEntity.getStatusCode().is2xxSuccessful())
                loggingSchema.setStatus(AppConstant.SUCCESS_RESPONSE);
            else
                loggingSchema.setStatus(AppConstant.FAILURE_RESPONSE);
        }
        loggingSchema.setMessage("Databricks API Call Success");
    }

    @Override
    public Optional<LoggableRequestContext> getLoggableRequestContext(LoggingDto loggingInfo) {
        return CommonUtil.setExternalCallLoggingRequestContext(
                applicationProperties.getDatabricksUrl(),
                applicationProperties.getApplicationName(),
                HttpMethod.POST);
    }
}
