package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.entity.HospitalFlag;
import com.star.matrix.util.Generated;
import lombok.Data;

import java.util.List;

@Generated
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class HospitalDetail {

    private DiscountDetails discountDetails;

    @JsonProperty("SHAIHospitalID")
    private String shaiHospitalId;

    @JsonProperty("HospitalName")
    private String hospitalName;

    @JsonProperty("HospitalAddr1")
    private String hospitalAddr1;

    @JsonProperty("HospitalAddr2")
    private String hospitalAddr2;

    @JsonProperty("HospitalCityID")
    private String hospitalCityId;

    @JsonProperty("HospitalPincode")
    private String hospitalPincode;

    @JsonProperty("HospitalContact")
    private String hospitalContact;

    @JsonProperty("HospitalPhone")
    private String hospitalPhone;

    @JsonProperty("HospitalIsActive")
    private Boolean hospitalIsActive;

    @JsonProperty("Hospitalwebsite")
    private String hospitalWebsite;

    @JsonProperty("HospitalEmail")
    private String hospitalEmail;

    @JsonProperty("HospitalPayableToName")
    private String hospitalPayableToName;

    @JsonProperty("HospitalIsPPN")
    private Boolean hospitalIsPpn;

    @JsonProperty("HospitalSTDCode")
    private String hospitalStdCode;

    @JsonProperty("HospIsFaxUpdated")
    private String hospIsFaxUpdated;

    @JsonProperty("HospitalState")
    private String hospitalState;

    @JsonProperty("HospitalDistrict")
    private String hospitalDistrict;

    @JsonProperty("HospitalRegistrationCode")
    private String hospitalRegistrationCode;

    @JsonProperty("RohiniCode")
    private String rohiniCode;

    @JsonProperty("Latitude")
    private String latitude;

    @JsonProperty("Longitude")
    private String longitude;

    @JsonProperty("CPUCode")
    private String cpuCode;

    @JsonProperty("EPDPercentage")
    private String epdPercentage;

    @JsonProperty("EPDStartDate")
    private String epdStartDate;

    @JsonProperty("EPDEnddate")
    private String epdEndDate;

    @JsonProperty("EPDAgreedDays")
    private String epdAgreedDays;

    @JsonProperty("IsNetworkHospital")
    private Boolean isNetworkHospital;

    @JsonProperty("EmpanelmentSatrtDate")
    private String empanelmentStartDate;

    @JsonProperty("EmpanelmentEndDate")
    private String empanelmentEndDate;

    @JsonProperty("AccountHoldername")
    private String accountHolderName;

    @JsonProperty("AccountNumber")
    private String accountNumber;

    @JsonProperty("IFSCCode")
    private String ifscCode;

    @JsonProperty("isBlacklisted")
    private Boolean isBlacklisted;

    @JsonProperty("isCaution")
    private Boolean isCaution;

    @JsonProperty("specialityType")
    private String specialityType;

    @JsonProperty("bedCount")
    private String bedCount;

    @JsonProperty("hospitalGstinNo")
    private String hospitalGstinNo;

    @JsonProperty("hospitalTanNumber")
    private String hospitalTanNumber;

    @JsonProperty("hospitalPanNumber")
    private String hospitalPanNumber;

    @JsonProperty("hospHFRCode")
    private String hospHfrCode;

    @JsonProperty("discountRemarks")
    private String discountRemarks;

    @JsonProperty("hospitalFlag")
    private List<HospitalFlag> hospitalFlag;

    @JsonProperty("isPrathamHospital")
    private String prathamFlag;

    @JsonProperty("grade")
    private String hospitalGrade;

    @JsonProperty("SOC_FLAG")
    private String socFlag;

    @JsonProperty("NETWORK_HOSP_TYPE")
    private String networkHospType;
}