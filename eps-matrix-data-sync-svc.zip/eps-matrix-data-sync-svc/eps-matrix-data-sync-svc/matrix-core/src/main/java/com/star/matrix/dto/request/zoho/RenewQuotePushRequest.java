package com.star.matrix.dto.request.zoho;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.dto.zoho.RenewQuoteDetail;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class RenewQuotePushRequest {

    private List<RenewQuoteDetail> data;
    @JsonProperty("duplicate_check_fields")
    private List<String> duplicateCheckFields;
    private List<String> trigger;

}
