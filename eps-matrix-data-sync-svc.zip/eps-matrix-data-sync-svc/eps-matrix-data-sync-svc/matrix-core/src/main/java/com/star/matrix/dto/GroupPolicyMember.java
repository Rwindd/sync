package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class GroupPolicyMember {
    @JsonProperty("PrimaryBeneficiaryInfo")
    private PrimaryBeneficiaryInfo primaryBeneficiaryInfo;
    private List<GroupPolicyBeneficiary> beneficiaryInfo;
}
