package com.star.matrix.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DataLakeResponseDto {
    private String intimationNumber;
    private String processingApplication;
}