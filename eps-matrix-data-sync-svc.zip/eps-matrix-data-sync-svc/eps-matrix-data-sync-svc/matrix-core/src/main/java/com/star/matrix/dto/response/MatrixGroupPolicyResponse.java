package com.star.matrix.dto.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MatrixGroupPolicyResponse {
    @JsonProperty("Errors")
    private Object errors;
    @JsonProperty("isSuccess")
    @JsonAlias({"isSuccess", "IsSuccess"})
    private Boolean isSuccess;
    @JsonProperty("Message")
    private String message;
    @JsonProperty("ErrorMessage")
    private String errorMessage;
    @JsonProperty("ErrorMsg")
    private String errorMsg;
}
