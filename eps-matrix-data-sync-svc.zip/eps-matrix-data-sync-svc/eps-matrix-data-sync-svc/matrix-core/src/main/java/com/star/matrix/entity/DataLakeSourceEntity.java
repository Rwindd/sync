package com.star.matrix.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class DataLakeSourceEntity {

    private String intimationNumber;
    private String processingApplication;
}
