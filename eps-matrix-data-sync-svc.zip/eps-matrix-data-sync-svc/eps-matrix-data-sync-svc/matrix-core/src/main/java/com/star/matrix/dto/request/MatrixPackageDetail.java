package com.star.matrix.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MatrixPackageDetail {

    private String exclusions;
    private String icd;
    private String inclusions;
    private String insurerProcedureCode;
    private String los;
    private String packageExpirydate;
    private String packageName;
    private String packageStartdate;
    private String pcs;
    private String procedureMapping;
    private String remarks;
    private String shaiHospitalId;
    private String roomCategory;
    private String packageRate;
}
