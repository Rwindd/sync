package com.star.matrix.entity;

public enum PolicyBatchStatus {

    COMPLETED
}
