package com.star.matrix.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataBricksResponse {

	@JsonProperty("statement_id")
	private String statementId;

	private Status status;
	private Manifest manifest;
	private Result result;

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Status {
		private String state;
	}

	@Data
	public static class Manifest {
		private String format;
		private Schema schema;

		@JsonProperty("total_chunk_count")
		private int totalChunkCount;

		private List<Chunk> chunks;

		@JsonProperty("total_row_count")
		private int totalRowCount;

		private boolean truncated;

		@Data
		public static class Schema {
			@JsonProperty("column_count")
			private int columnCount;

			private List<Column> columns;

			@Data
			public static class Column {

				private String name;

				@JsonProperty("type_text")
				private String typeText;

				@JsonProperty("type_name")
				private String typeName;

				private int position;
			}
		}

		@Data
		public static class Chunk {

			@JsonProperty("chunk_index")
			private int chunkIndex;

			@JsonProperty("row_offset")
			private int rowOffset;

			@JsonProperty("row_count")
			private int rowCount;
		}

	}

	@Data
	public static class Result {

		@JsonProperty("chunk_index")
		private int chunkIndex;

		@JsonProperty("row_offset")
		private int rowOffset;

		@JsonProperty("row_count")
		private int rowCount;

		@JsonProperty("data_array")
		private List<List<Object>> dataArray;

	}

}
