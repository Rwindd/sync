package com.star.matrix.logging;

import com.star.eps.models.LoggingDto;
import org.apache.commons.lang3.exception.ExceptionUtils;

public class DataLakePolicySchedulerProcessor extends CommonLogging {

    @Override
    public void populateExceptionDetails(LoggingDto loggingDto, Throwable throwable) {
        loggingDto.setException(ExceptionUtils.getStackTrace(throwable));
        loggingDto.setMessage("Exception occurred");
    }

    @Override
    public void populateResponseFields(LoggingDto loggingDto, Object apiResponse) {
        loggingDto.setMessage("DataLake Scheduler for Policy data");
    }

}
