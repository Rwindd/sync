package com.star.matrix.logging;

import com.star.eps.models.LoggingDto;
import com.star.matrix.dto.PolicyDetails;
import com.star.matrix.dto.request.MatrixBulkPolicyRequest;
import com.star.matrix.util.ObjectMapperUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;

public class MatrixClientBulkGroupPolicyPushProcessor extends CommonLogging{


    @Override
    public void populateExceptionDetails(LoggingDto loggingDto, Throwable throwable) {
        loggingDto.setException(ExceptionUtils.getStackTrace(throwable));
        loggingDto.setMessage("Exception occurred");
    }

    @Override
    public void populateRequestFields(LoggingDto loggingDto, Object[] arguments) {
        MatrixBulkPolicyRequest matrixBulkPolicyRequest = (MatrixBulkPolicyRequest) arguments[0];
        var list = matrixBulkPolicyRequest.getBatches().stream().map(MatrixBulkPolicyRequest.Batch::getPolicyInfo)
                .map(PolicyDetails::getPolicyNumber).toList();
        loggingDto.setRequest("Policy push size"+ list);
    }

    @Override
    public void populateResponseFields(LoggingDto loggingDto, Object apiResponse) {
        loggingDto.setMessage("Matrix Scheduler for PMS data");
        loggingDto.setResponse(ObjectMapperUtil.convertObjectToJson(apiResponse));
    }
}
