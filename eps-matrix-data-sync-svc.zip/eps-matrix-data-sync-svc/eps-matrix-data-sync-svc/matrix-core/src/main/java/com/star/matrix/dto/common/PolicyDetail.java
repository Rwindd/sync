package com.star.matrix.dto.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PolicyDetail {
    @JsonProperty("Policy_No")
    private String policyNo;

    @JsonProperty("Policy_From_Date")
    private String policyFromDate;

    @JsonProperty("Policy_To_Date")
    private String policyToDate;

    @JsonProperty("UW_Year")
    private String uwYear;

    @JsonProperty("policy_SUM_Insured")
    private String policySumInsured;

    @JsonProperty("PREVIOUS_POLICY_NO")
    private String previousPolicyNo;

    @JsonProperty("Insured_NAme")
    private String insuredName;

    @JsonProperty("Gender")
    private String gender;

    @JsonProperty("DOB")
    private String dob;

    @JsonProperty("Relation")
    private String relation;

    @JsonProperty("Member_Sum_Insured")
    private String memberSumInsured;

    @JsonProperty("PED")
    private String ped;

    @JsonProperty("HEALTH_ID")
    private String healthId;
    
    @JsonProperty("POLICY_INCEPTION_DATE")
    private String policyInceptionDate;
    
    @JsonProperty("POLICY_TYPE")
    private String policyType;
    
    @JsonProperty("EffectiveFrom")
    private String effectiveFrom;
    
    @JsonProperty("EffectiveTo")
    private String effectiveTo;
    
    @JsonProperty("Insured_Inception_Date")
    private String insuredInceptionDate;

    @JsonProperty("PRODUCT_NAME")
    private String productName;
}
