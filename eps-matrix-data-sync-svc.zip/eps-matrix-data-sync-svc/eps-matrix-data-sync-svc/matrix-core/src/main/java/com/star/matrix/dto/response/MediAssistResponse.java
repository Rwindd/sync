package com.star.matrix.dto.response;

import lombok.Data;

@Data
public class MediAssistResponse {
    private String message;
    private String referenceNumber;
}
