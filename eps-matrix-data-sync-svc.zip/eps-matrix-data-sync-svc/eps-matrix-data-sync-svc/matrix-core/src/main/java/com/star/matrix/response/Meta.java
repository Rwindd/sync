package com.star.matrix.response;

import com.star.matrix.shared.SharedApplicationContext;

public record Meta(String code, String message, String displayMessage, String traceId) {
    public Meta(String code, String message, String displayMessage) {
        this(code, message, displayMessage, SharedApplicationContext.getTraceId());

    }
}

