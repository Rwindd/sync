package com.star.matrix.config;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

@Configuration
@RequiredArgsConstructor
public class ConfigAppPostgresJdbcConfig {

    @Bean
    @ConfigurationProperties("spring.datasource.matrix-sync")
    public DataSourceProperties matrixSyncDataSourceProps() {
        return new DataSourceProperties();
    }

    @Bean
    @ConfigurationProperties("spring.datasource.claims")
    public DataSourceProperties claimsDataSourceProps() {
        return new DataSourceProperties();
    }

    @Bean(name = "matrixSyncDataSource")
    public DataSource matrixSyncDataSource() {
        return matrixSyncDataSourceProps().initializeDataSourceBuilder().build();
    }

    @Bean(name = "claimsDataSource")
    public DataSource claimsDataSource() {
        return claimsDataSourceProps().initializeDataSourceBuilder().build();
    }

    @Bean(name = "matrixSyncJdbcTemplate")
    public NamedParameterJdbcTemplate minusDayJdbcTemplate(@Qualifier("matrixSyncDataSource") DataSource matrixDataSource) {
        return new NamedParameterJdbcTemplate(matrixDataSource);
    }


    @Bean(name = "claimsJdbcTemplate")
    public NamedParameterJdbcTemplate claimsJdbcTemplate(@Qualifier("claimsDataSource") DataSource claimsDataSource) {
       return new NamedParameterJdbcTemplate(claimsDataSource);
    }

    @Primary
    @Bean(name = "matrixSyncTxnManager")
    public PlatformTransactionManager matrixSyncTxnManager(@Qualifier("matrixSyncDataSource") DataSource ds) {
        return new DataSourceTransactionManager(ds);
    }

    @Bean(name = "claimsTxnManager")
    public PlatformTransactionManager claimsTxnManager(@Qualifier("claimsDataSource") DataSource ds) {
        return new DataSourceTransactionManager(ds);
    }


}