package com.star.matrix.util;

import com.star.eps.models.LoggableRequestContext;
import lombok.experimental.UtilityClass;
import org.springframework.http.HttpMethod;

import java.util.Optional;

@UtilityClass
public class CommonUtil {

    public static Optional<LoggableRequestContext> setExternalCallLoggingRequestContext(String url, String xForwardFor, HttpMethod httpMethod) {
        return Optional.of(LoggableRequestContext.builder().uri(url)
                .method(httpMethod.name())
                .xForwardedFor(xForwardFor).build());
    }
}
