package com.star.matrix.dto.request;

import lombok.Data;

import java.util.List;

@Data
public class EnvVariableDeleteRequestDto {
    List<String> id;
}
