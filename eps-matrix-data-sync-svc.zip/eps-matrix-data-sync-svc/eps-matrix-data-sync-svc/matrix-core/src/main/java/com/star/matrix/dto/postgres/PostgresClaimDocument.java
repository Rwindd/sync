package com.star.matrix.dto.postgres;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PostgresClaimDocument {
    @JsonProperty("INTIMATION_NUMBER")
    private String intimationNumber;
    @JsonProperty("DOCUMENT_NAME")
    private String documentName;
    @JsonProperty("DOCUMENT_TOKEN")
    private String documentToken;
    @JsonProperty("DOCUMENT_TYPE")
    private String documentType;
    @JsonProperty("DOCUMENT_SOURCE")
    private String documentSource;
}
