package com.star.matrix.entity.zoho;


import com.star.matrix.dto.zoho.RenewalQuoteEncrypt;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
@Builder
@Data
@Document(collection = "renew_quote_failed_payload")
public class RenewQuoteFailedPayload {
    @Id
    private String id;
    private String renewalPolicyRefNo;
    private RenewalQuoteEncrypt payload;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;

}
