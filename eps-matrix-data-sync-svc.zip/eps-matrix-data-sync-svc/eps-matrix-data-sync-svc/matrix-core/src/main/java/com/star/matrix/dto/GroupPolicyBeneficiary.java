package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class GroupPolicyBeneficiary {
    private String relation;
    private String name;
    private String dateOfBirth;
    private String gender;
    private String effectiveFrom;
    private String effectiveTo;
    private String zoneForMember;
    private String active;
    private Long individualSumInsured;
    private String insurerBeneficiaryUniqueID;
    @JsonProperty("InsurerInceptionDate")
    private String inception;
    @JsonProperty("RiskId")
    private String riskId;
}
