package com.star.matrix.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "environment_variables")
public class EnvironmentVariables {
    @Id
    private String id;
    private String key;
    private String value;
}
