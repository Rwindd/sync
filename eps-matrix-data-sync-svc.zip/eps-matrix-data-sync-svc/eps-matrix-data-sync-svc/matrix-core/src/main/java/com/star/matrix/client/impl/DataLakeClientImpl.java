package com.star.matrix.client.impl;

import com.star.eps.annotations.StarLogging;
import com.star.matrix.client.DataLakeClient;
import com.star.matrix.common.RequestResponseLogger;
import com.star.matrix.dto.request.StatementIDRequest;
import com.star.matrix.dto.response.DataBricksResponse;
import com.star.matrix.logging.DataLakeClientProcessorImpl;
import com.star.matrix.properties.ApplicationProperties;
import com.star.matrix.resttemplate.RestTemplateName;
import com.star.matrix.util.ExecutionTimeLogger;
import com.star.matrix.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Map;

import static com.star.matrix.util.ApplicationConstant.DATALAKE_CLIENT_API_PROCESSOR;
import static com.star.matrix.util.ObjectMapperUtil.convertObjectToStringSilently;

@Slf4j
@Service
@RequiredArgsConstructor
public class DataLakeClientImpl implements DataLakeClient {

    public static final String DATA_LAKE_STATEMENT_ID_CALL = "Data Lake Statement Id Api call";
    public static final String DATA_LAKE_CONNECTION_STOP_CALL = "Data Lake Connection Stop Api call";

    private final Map<RestTemplateName, RestTemplate> restTemplateMap;
    private final ApplicationProperties applicationProperties;


    @Override
    @StarLogging(loggingEvent = DataLakeClientProcessorImpl.class, actionName = DATALAKE_CLIENT_API_PROCESSOR)
    public DataBricksResponse getDataBricksResponse(StatementIDRequest requestPayload) {
        log.info("Request received to call databricks for payload: {}", ObjectMapperUtil.convertObjectToString(requestPayload));
        return ExecutionTimeLogger.logExecutionTime(DATA_LAKE_STATEMENT_ID_CALL, () -> {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                headers.add("Authorization", "Bearer " + applicationProperties.getToken());
                String requestJsonString = convertObjectToStringSilently(requestPayload);
                RequestEntity<Object> requestEntity = new RequestEntity<>(requestJsonString, headers, HttpMethod.POST,
                        new URI(applicationProperties.getDatabricksUrl()));
                RequestResponseLogger.logRequest(requestEntity);
                ResponseEntity<DataBricksResponse> responseEntity = restTemplateMap
                        .get(RestTemplateName.DATA_LAKE_SERVICE)
                        .exchange(requestEntity, new ParameterizedTypeReference<>() {
                        });
                return responseEntity.getBody();
            } catch (Exception exception) {
                log.error("Error occurred with calling Databricks", exception);
                return new DataBricksResponse();
            }
        });
    }

    @Override
    @StarLogging(loggingEvent = DataLakeClientProcessorImpl.class, actionName = DATALAKE_CLIENT_API_PROCESSOR)
    public DataBricksResponse getCRMDataBricksResponse(StatementIDRequest requestPayload) {
        log.info("Request received to call CRM databricks for payload: {}", ObjectMapperUtil.convertObjectToString(requestPayload));
        return ExecutionTimeLogger.logExecutionTime(DATA_LAKE_STATEMENT_ID_CALL, () -> {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                headers.add("Authorization", "Bearer " + applicationProperties.getCrmToken());
                String requestJsonString = convertObjectToStringSilently(requestPayload);
                RequestEntity<Object> requestEntity = new RequestEntity<>(requestJsonString, headers, HttpMethod.POST,
                        new URI(applicationProperties.getDatabricksUrl()));
                RequestResponseLogger.logRequest(requestEntity);
                ResponseEntity<DataBricksResponse> responseEntity = restTemplateMap
                        .get(RestTemplateName.DATA_LAKE_SERVICE)
                        .exchange(requestEntity, new ParameterizedTypeReference<>() {
                        });
                log.info("Response Body : {}", responseEntity);
                return responseEntity.getBody();
            } catch (Exception exception) {
                log.error("Error occurred with calling Databricks", exception);
                return new DataBricksResponse();
            }
        });
    }


    @Override
    //@StarLogging(loggingEvent = DataLakeClientCloseConnProcessor.class, actionName = "DATALAKE_CLIENT_CLOSE_CONNECTION")
    public boolean stopDBConnection() {
        return ExecutionTimeLogger.logExecutionTime(DATA_LAKE_CONNECTION_STOP_CALL, () -> {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.add("Authorization", "Bearer " + applicationProperties.getToken());
                URI uri = UriComponentsBuilder.fromHttpUrl(applicationProperties.getConnectionStopUrl()).build().toUri();
                RequestEntity<Object> requestEntity = new RequestEntity<>(headers, HttpMethod.POST, uri);
                RequestResponseLogger.logRequest(requestEntity);
                ResponseEntity<DataBricksResponse> responseEntity = restTemplateMap.get(RestTemplateName.DATA_LAKE_SERVICE)
                        .exchange(requestEntity, new ParameterizedTypeReference<>() {
                        });
                log.info("Response Body : {}", responseEntity);
                return responseEntity.getStatusCode().equals(HttpStatusCode.valueOf(200));
            } catch (Exception exception) {
                log.error("Exception occurred in stopDBConnection ", exception);
            }
            return false;
        });
    }

}
