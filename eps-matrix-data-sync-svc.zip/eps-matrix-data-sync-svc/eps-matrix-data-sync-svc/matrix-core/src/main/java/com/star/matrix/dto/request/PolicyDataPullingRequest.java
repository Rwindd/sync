package com.star.matrix.dto.request;

import lombok.Data;

@Data
public class PolicyDataPullingRequest {

	private long pullingDate;
	private boolean manual;

}
