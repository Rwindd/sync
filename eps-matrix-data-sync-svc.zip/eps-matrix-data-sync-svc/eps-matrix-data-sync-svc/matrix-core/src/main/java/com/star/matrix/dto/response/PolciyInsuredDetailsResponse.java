package com.star.matrix.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.awt.*;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PolciyInsuredDetailsResponse {
    private String proposerName;
    private String numberOfChildren;
    private String numberOfAdult;
    private List<DetailsOfAdult> detailsOfAdult;
    private List<DetailsOfChildren> detailsOfChildren;
    private String pincode;
    private String planType;
    private String policyType;
    private String premiumAmount;
    private String sumInsured;
    private AgentDetails agentDetails;
    @Data
    public static class DetailsOfAdult{
        private String adultName;
        private String age;
        private String proposerMobileNumber;
        private String insuredMobileNumber;
        private String healthId;
        private String sumInsured;
    }
    @Data
    public static class DetailsOfChildren{
        private String childName;
        private String age;
        private String proposerMobileNumber;
        private String insuredMobileNumber;
        private String healthId;
        private String sumInsured;
    }

    @Data
    public static class AgentDetails{
        private String agentName;
        private String agentCode;
        private String agentMobileNo;
        private String intermediaryType;
        private String advisorName;
        private String advisorContact;
    }

}
