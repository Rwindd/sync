package com.star.matrix.dto.common;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class PolicyClaimHistoryCombined {

    private List<PolicyMemberDetailSummary> policyMemberDetailSummaries;
    private List<PolicyDocumentSummary> policyDocumentSummaries;
    private List<ClaimHistorySummary> claimHistorySummaries;
    private List<ClaimDocumentSummary> claimDocumentSummaries;
}
