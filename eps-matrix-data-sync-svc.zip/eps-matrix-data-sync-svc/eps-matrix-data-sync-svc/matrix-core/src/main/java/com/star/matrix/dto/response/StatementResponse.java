package com.star.matrix.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatementResponse {

	@JsonProperty("statement_id")
	private String statementId;
	private Status status;

	@Data
	public class Status {
		private String state;
	}
}
