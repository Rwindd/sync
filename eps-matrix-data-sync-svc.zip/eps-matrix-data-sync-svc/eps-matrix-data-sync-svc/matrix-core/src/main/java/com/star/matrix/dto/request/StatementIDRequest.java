package com.star.matrix.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class StatementIDRequest {

	@JsonProperty("warehouse_id")
	private String warehouseId;
	
	private String statement;
	
	@JsonProperty("wait_timeout")
	private String waitTimeout;
}
