package com.star.matrix.logging;

import com.star.eps.events.LoggingEvent;
import com.star.eps.models.LoggingDto;
import com.star.matrix.util.ObjectMapperUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;

public abstract class CommonLogging implements LoggingEvent<LoggingDto> {
    @Override
    public String getApiName(LoggingDto loggingInfo) {
        return loggingInfo.getApiName();
    }

    @Override
    public LoggingDto generateNewLoggingSchema(String actionName) {
        LoggingDto loggingDto = new LoggingDto();
        loggingDto.setApiName(actionName);
        return loggingDto;
    }

    @Override
    public void populateExceptionDetails(LoggingDto loggingDto, Throwable throwable) {
        loggingDto.setException(ExceptionUtils.getStackTrace(throwable));
        loggingDto.setMessage("Exception occurred while calling datalake client Api");
    }

    @Override
    public void populateRequestFields(LoggingDto loggingDto, Object[] arguments) {
        //No Request Field Required
    }

    @Override
    public void populateResponseFields(LoggingDto loggingDto, Object apiResponse) {
        loggingDto.setResponse(ObjectMapperUtil.convertObjectToStringSilently(apiResponse));
    }

}
