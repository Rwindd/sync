package com.star.matrix.resttemplate;

import com.star.matrix.properties.RestTemplateProperties;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.TimeUnit;

@Slf4j
@UtilityClass
class RestTemplateUtil {

    private final String CONNECT_TIMEOUT_SUFFIX = ".connect.timeout";
    private final String READ_TIMEOUT_SUFFIX = ".read.timeout";
    private final String MAX_CONNECTION_SUFFIX = ".max.connection";

    static RestTemplate createRestTemplate(RestTemplateProperties restTemplateProperties, MeterRegistry meterRegistry) {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getInterceptors().add(new MetricsRestTemplateInterceptor(meterRegistry, "http.client.requests"));
        restTemplate.setRequestFactory(getRequestFactory(restTemplateProperties));
        return restTemplate;
    }

    private static HttpComponentsClientHttpRequestFactory getRequestFactory(RestTemplateProperties restTemplateProperties) {
        PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
        connManager.setMaxTotal(restTemplateProperties.getMaxConnection());
        connManager.setDefaultMaxPerRoute(restTemplateProperties.getMaxConnection());
        final ConnectionConfig connConfig = ConnectionConfig.custom()
                .setSocketTimeout(restTemplateProperties.getReadTimeout(), TimeUnit.MILLISECONDS)
                .setConnectTimeout(restTemplateProperties.getConnectTimeout(), TimeUnit.MILLISECONDS)
                .build();
        connManager.setDefaultConnectionConfig(connConfig);
        CloseableHttpClient httpClient = HttpClientBuilder.create()
                .setConnectionManager(connManager)
                .disableCookieManagement()
                .build();
        return new HttpComponentsClientHttpRequestFactory(httpClient);
    }

    public RestTemplateProperties getRestTemplateProperties(Environment environment, RestTemplateName restTemplateName) {
        RestTemplateProperties properties = new RestTemplateProperties();
        try {
            properties.setConnectTimeout(environment.getProperty(restTemplateName.prefix + CONNECT_TIMEOUT_SUFFIX, Integer.class));
            properties.setReadTimeout(environment.getProperty(restTemplateName.prefix + READ_TIMEOUT_SUFFIX, Integer.class));
            properties.setMaxConnection(environment.getProperty(restTemplateName.prefix + MAX_CONNECTION_SUFFIX, Integer.class));
            log.info("properties for restTemplate {}", properties);
        } catch (Exception ex) {
            throw new RestClientException("Properties not available for : " + restTemplateName);
        }
        return properties;
    }
}

