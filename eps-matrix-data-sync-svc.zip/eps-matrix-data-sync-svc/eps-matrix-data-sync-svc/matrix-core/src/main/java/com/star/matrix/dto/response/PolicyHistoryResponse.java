package com.star.matrix.dto.response;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class PolicyHistoryResponse {
	private List<Policy> policies = new ArrayList<>();

	@Data
	public static class Policy {


		private String policyNo;

		private String policyFromDate;

		private String policyToDate;

		private String uwYear;

		private String sumInsured;

		private String productName;

		private String previousPolicyNo;

		private String policySource;

		private String policyInceptionDate;

		private String policyType;

		private List<Member> member;

		private List<Document> document;

		private List<Claim> claim;
	}

	@Data
	public static class Member {

		private String insuredName;

		private String healthId;

		private String gender;

		private String dob;

		private String relation;

		private String sumInsured;

		private String ped;

		private String effectiveFrom;

		private String effectiveTo;

		private String insuredInceptionDate;
	}

	@Data
	public static class Document {

		private String proposalNo;

		private String policyNo;

		private String policyId;

		private String documentType;

		private String documentName;

		private String documentSource;

		private String apiDocumentType;
	}

	@Data
	public static class Claim {

		private String healthId;

		private String policyYear;

		private String claimNumber;

		private String claimType;

		private String insuredPatientName;

		private String intimationNumber;

		private String dateOfAdmission;

		private String claimStatus;

		private String claimAmount;

		private String approvedAmount;

		private String hospitalDetails;

		private String diagnosis;

		private String sublimitName;

		private String sublimitAmount;

		private String icdCode;

		private String sublimitCategory;

		private String ped;

		private String siRegistration;

		private String copay;

		private String cataractDetails;

		private String donorCover;

		private String intimationSource;

		private String claimProcessed;

		private List<ClaimDocument> documents;
	}

	@Data
	public static class ClaimDocument {

		private String documentName;
		

		private String documentToken;
		

		private String documentType;
		

		private String documentCategory;
	}
}
