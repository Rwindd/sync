package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;

@Generated
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class PrevPolicyDocument {

	@JsonProperty("PolicyNo")
	private String policyNo;

	@JsonProperty("ProposalNo")
	private String proposalNo;

	@JsonProperty("DocumentType")
	private String documentType;

	@JsonProperty("DocumentName")
	private String documentName;

	@JsonProperty("DocumentSource")
	private String documentSource;

}
