package com.star.matrix.dto.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ClaimHistory {

    @JsonProperty("POLICY_NUMBER")
    private String policyNumber;
    @JsonProperty("HEATH_ID")
    private String healthId;
    @JsonProperty("POLICY_YEAR")
    private String policyYear;
    @JsonProperty("CLAIM_NUMBER")
    private String claimNumber;
    @JsonProperty("CLAIM_TYPE")
    private String claimType;
    @JsonProperty("INTIMATION_NUMBER")
    private String intimationNumber;
    @JsonProperty("PATIENT_NAME")
    private String patientName;
    @JsonProperty("DIAGNOSIS")
    private String diagnosis;
    @JsonProperty("ADMISSION_DATE")
    private String admissionDate;
    @JsonProperty("CLAIM_STATUS")
    private String claimStatus;
    @JsonProperty("CLAIMED_AMOUNT")
    private String claimedAmount;
    @JsonProperty("SI_RESTRICTION_FLAG")
    private String siRestrictionFlag;
    @JsonProperty("APPROVED_AMOUNT")
    private String approvedAmount;
    @JsonProperty("COPAY")
    private String copay;
    @JsonProperty("HOSPITAL_NAME")
    private String hospitalName;
    @JsonProperty("PED_NAME")
    private String pedName;
    @JsonProperty("ICD_CODE")
    private String icdCode;
    @JsonProperty("SUBLIMIT_CATEGORY")
    private String sublimitCategory;
    @JsonProperty("SURROGACY_OOCYTE_COVER")
    private String surrogacyOocyteCover;
    @JsonProperty("CATARACT_DETAILS")
    private String cataractDetails;
    @JsonProperty("SUBLIMIT_NAME")
    private String sublimitName;
    @JsonProperty("SUBLIMIT_AMONT")
    private String sublimitAmount;
}
