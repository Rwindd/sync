package com.star.matrix.entity.grouppolicy;

import com.star.matrix.entity.OneTimeStatus;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;

import java.time.Instant;

@Data
@Document(collection = "one_time_group_policy_status")
public class OneTimeGroupPolicyStatus {
    @MongoId
    private String id;
    private OneTimeStatus status;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;
}

