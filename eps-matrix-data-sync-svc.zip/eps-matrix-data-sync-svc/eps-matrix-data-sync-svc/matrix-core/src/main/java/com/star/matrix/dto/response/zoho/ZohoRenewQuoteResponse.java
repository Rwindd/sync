package com.star.matrix.dto.response.zoho;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZohoRenewQuoteResponse {

    private List<DataObj> data;

    @Data
    public static class DataObj {
        public String code;
        public String duplicate_field;
        public String action;
        public Object details;
        public String message;
        public String status;
    }

}
