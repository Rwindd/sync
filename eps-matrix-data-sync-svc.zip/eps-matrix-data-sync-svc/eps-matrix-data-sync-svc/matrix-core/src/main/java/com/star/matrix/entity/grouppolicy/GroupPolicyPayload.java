package com.star.matrix.entity.grouppolicy;

import com.star.matrix.dto.GroupPolicyData;
import com.star.matrix.dto.GroupPolicyDataResponse;
import com.star.matrix.enumeration.RequestStatus;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;

import java.time.Instant;

@Data
@Document(collection = "group_policy_payload")
public class GroupPolicyPayload {
    @MongoId
    private String id;
    private String recordId;
    private RequestStatus status;
    private String policyNumber;
    private int retryCount ;
    private GroupPolicyData payload;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;
}
