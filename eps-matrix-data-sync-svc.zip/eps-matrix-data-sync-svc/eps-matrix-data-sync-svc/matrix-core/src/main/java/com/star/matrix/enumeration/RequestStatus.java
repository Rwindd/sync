package com.star.matrix.enumeration;

public enum RequestStatus {

    INITIATED, SUCCESS, FAILED, IN_PROGRESS, QUEUED
}
