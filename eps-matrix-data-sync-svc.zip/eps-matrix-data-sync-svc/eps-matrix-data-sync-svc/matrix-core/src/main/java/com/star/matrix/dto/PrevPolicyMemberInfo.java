package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;

@Generated
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class PrevPolicyMemberInfo {

	@JsonProperty("INSURED_NAME")
	private String insuredName;

	@JsonProperty("HEALTH_ID")
	private String healthId;

	@JsonProperty("GENDER")
	private String gender;

	@JsonProperty("DOB")
	private String dob;

	@JsonProperty("RELATION")
	private String relation;

	@JsonProperty("SUM_INSURED")
	private String sumInsured;

	@JsonProperty("PED")
	private String ped;

}
