package com.star.matrix.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.dto.request.MatrixHospitalPayload;
import com.star.matrix.enumeration.RequestStatus;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;


@Data
@Document(collection = "hospitalDetail_payloads")
public class HospitalPayload {

    @Id
    private String id;
    @JsonProperty("STATUS")
    private RequestStatus status;
    private String hospitalID;
    private int retryCount;
    private MatrixHospitalPayload matrixHospitalPayload;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;
}
