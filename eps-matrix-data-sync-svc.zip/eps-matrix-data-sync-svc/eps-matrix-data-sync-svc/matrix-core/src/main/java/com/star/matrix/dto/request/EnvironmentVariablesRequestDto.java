package com.star.matrix.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EnvironmentVariablesRequestDto {
    @NotBlank
    private String key;
    @NotBlank
    private String value;
}
