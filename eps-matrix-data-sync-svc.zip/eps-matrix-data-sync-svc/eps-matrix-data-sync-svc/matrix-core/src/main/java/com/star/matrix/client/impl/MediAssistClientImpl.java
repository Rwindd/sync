package com.star.matrix.client.impl;

import com.star.eps.annotations.StarLogging;
import com.star.matrix.client.MediAssistClient;
import com.star.matrix.common.RequestResponseLogger;
import com.star.matrix.dto.GroupPolicyData;
import com.star.matrix.dto.PolicyDataResponse;
import com.star.matrix.dto.request.MatrixBulkGroupPolicyRequest;
import com.star.matrix.dto.request.MatrixBulkPolicyRequest;
import com.star.matrix.dto.response.*;
import com.star.matrix.logging.MatrixClientBulkPolicyPushProcessor;
import com.star.matrix.logging.MatrixClientHospitalPushProcessor;
import com.star.matrix.logging.MatrixClientPolicyPushProcessor;
import com.star.matrix.properties.ApplicationProperties;
import com.star.matrix.resttemplate.RestTemplateName;
import com.star.matrix.util.ExecutionTimeLogger;
import com.star.matrix.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class MediAssistClientImpl implements MediAssistClient {
    public static final String MEDI_ASSIST_HOSPITAL_PUSH_API_CALL = "Medi Assist hospital push Api Call";
    public static final String MEDI_ASSIST_POLICY_PUSH_API_CALL = "Medi Assist policy push Api Call";
    public static final String MATRIX_CLIENT_GROUP_POLICY_PUSH = "Medi Assist Group policy push Api Call";
    public static final String MATRIX_CLIENT_BULK_GROUP_POLICY_PUSH = "Medi Assist Bulk Group policy push Api Call";


    private final Map<RestTemplateName, RestTemplate> restTemplateMap;
    private final ApplicationProperties applicationProperties;

    @Override
    @StarLogging(loggingEvent = MatrixClientHospitalPushProcessor.class, actionName = "MATRIX_CLIENT_HOSPITAL_PUSH")
    public MatrixPmsResponse hospitalPush(String payload) {
        log.info("Request received for calling matrix to push hospital data : {}", payload);
        return ExecutionTimeLogger.logExecutionTime(MEDI_ASSIST_HOSPITAL_PUSH_API_CALL, () -> {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                RequestEntity<Object> requestEntity = new RequestEntity<>(payload, headers, HttpMethod.POST,
                        new URI(applicationProperties.getMatrixHospitalPushUrl()));
                RequestResponseLogger.logRequest(requestEntity);
                ResponseEntity<MatrixPmsResponse> responseEntity = restTemplateMap
                        .get(RestTemplateName.MATRIX_SERVICE)
                        .exchange(requestEntity, new ParameterizedTypeReference<>() {
                        });
                log.info("Response Body : {}", responseEntity);
                return responseEntity.getBody();
            } catch (Exception exception) {
                log.error("Error occurred with calling Matrix", exception);
                return new MatrixPmsResponse();
            }
        });
    }

    @Override
    @StarLogging(loggingEvent = MatrixClientPolicyPushProcessor.class, actionName = "MATRIX_CLIENT_POLICY_PUSH")
    public MatrixPolicyResponse policyPush(PolicyDataResponse object) {
        log.info("Request received to call matrix to push policy data : {} ", ObjectMapperUtil.convertObjectToString(object));
        return ExecutionTimeLogger.logExecutionTime(MEDI_ASSIST_POLICY_PUSH_API_CALL, () -> {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                RequestEntity<Object> requestEntity = new RequestEntity<>(object, headers, HttpMethod.POST,
                        new URI(applicationProperties.getMatrixPolicyPushUrl()));
                RequestResponseLogger.logRequest(requestEntity);
                ResponseEntity<MatrixPolicyResponse> responseEntity = restTemplateMap
                        .get(RestTemplateName.MATRIX_SERVICE)
                        .exchange(requestEntity, new ParameterizedTypeReference<>() {
                        });
                log.info("Response Body : {}", responseEntity);
                return responseEntity.getBody();
            } catch (Exception exception) {
                log.error("Error occurred with calling Matrix", exception);
                return new MatrixPolicyResponse();
            }
        });
    }

    @Override
    @StarLogging(loggingEvent = MatrixClientBulkPolicyPushProcessor.class, actionName = "MATRIX_CLIENT_BULK_POLICY_PUSH")
    public MatrixBulkPolicyResponse bulkPolicyPush(MatrixBulkPolicyRequest matrixBulkPolicyRequest) {
        log.info("Request received to call matrix to push bulk policy data : {} ",
                ObjectMapperUtil.convertObjectToString(matrixBulkPolicyRequest.getBatches().size()));
        return ExecutionTimeLogger.logExecutionTime(MEDI_ASSIST_POLICY_PUSH_API_CALL, () -> {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                RequestEntity<Object> requestEntity = new RequestEntity<>(matrixBulkPolicyRequest, headers, HttpMethod.POST,
                        new URI(applicationProperties.getMatrixBulkPolicyPushUrl()));
                ResponseEntity<MatrixBulkPolicyResponse> responseEntity = restTemplateMap
                        .get(RestTemplateName.MATRIX_SERVICE)
                        .exchange(requestEntity, new ParameterizedTypeReference<>() {
                        });
                log.info("Response Body : {}", responseEntity);
                return responseEntity.getBody();
            } catch (Exception exception) {
                log.error("Error occurred with calling Matrix", exception);
                return new MatrixBulkPolicyResponse();
            }
        });
    }

    @Override
    @StarLogging(loggingEvent = MatrixClientBulkPolicyPushProcessor.class, actionName = "MATRIX_CLIENT_GROUP_POLICY_PUSH")
    public MatrixGroupPolicyResponse groupPolicyPush(GroupPolicyData matrixGroupPolicyRequest) {
        return ExecutionTimeLogger.logExecutionTime(MATRIX_CLIENT_GROUP_POLICY_PUSH, () -> {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                RequestEntity<Object> requestEntity = new RequestEntity<>(matrixGroupPolicyRequest, headers, HttpMethod.POST,
                        new URI(applicationProperties.getMatrixGroupPolicyPushUrl()));
                log.info("Call matrix Minimum group policy push API {}, for policy Number : {}", applicationProperties.getMatrixGroupPolicyPushUrl(), matrixGroupPolicyRequest.getPolicyInfo().getPolicyNumber());
                ResponseEntity<MatrixGroupPolicyResponse> responseEntity = restTemplateMap
                        .get(RestTemplateName.MATRIX_SERVICE)
                        .exchange(requestEntity, new ParameterizedTypeReference<>() {
                        });
                log.info("Response Body for {} : {}", matrixGroupPolicyRequest.getPolicyInfo().getPolicyNumber(), responseEntity);
                return responseEntity.getBody();
            } catch (Exception exception) {
                log.error("Error occurred with calling Matrix for Group Policy Request : {}", matrixGroupPolicyRequest, exception);
                return new MatrixGroupPolicyResponse();
            }
        });
    }

    @Override
    public MatrixBulkGroupPolicyResponse bulkGroupPolicyPush(MatrixBulkGroupPolicyRequest matrixBulkPolicyRequest) {
        log.info("Request received to call matrix to push bulk group policy data : {} ",
                ObjectMapperUtil.convertObjectToString(matrixBulkPolicyRequest.getBatches().size()));
        return ExecutionTimeLogger.logExecutionTime(MATRIX_CLIENT_BULK_GROUP_POLICY_PUSH, () -> {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                RequestEntity<Object> requestEntity = new RequestEntity<>(matrixBulkPolicyRequest, headers, HttpMethod.POST,
                        new URI(applicationProperties.getMatrixBulkGroupPolicyPushUrl()));
                RequestResponseLogger.logRequest(requestEntity);
                ResponseEntity<MatrixBulkGroupPolicyResponse> responseEntity = restTemplateMap
                        .get(RestTemplateName.MATRIX_SERVICE)
                        .exchange(requestEntity, new ParameterizedTypeReference<>() {
                        });
                RequestResponseLogger.logResponse(responseEntity);
                log.info("Response Body : {}", responseEntity);
                return responseEntity.getBody();
            } catch (Exception exception) {
                log.error("Error occurred with calling Matrix", exception);
                return new MatrixBulkGroupPolicyResponse();
            }
        });
    }
}

