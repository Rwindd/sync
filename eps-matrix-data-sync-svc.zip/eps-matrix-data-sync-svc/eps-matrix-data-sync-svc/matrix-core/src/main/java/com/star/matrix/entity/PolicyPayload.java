package com.star.matrix.entity;

import com.star.matrix.dto.PolicyDataResponse;
import com.star.matrix.enumeration.RequestStatus;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Document(collection = "policyDetail_payloads")
@Data
public class PolicyPayload {

	@Id
	private String id;
	private RequestStatus status;
	private String policyNumber;
	private int retryCount ;
	private PolicyDataResponse payload;
	@CreatedDate
	private Instant createdAt;
	@LastModifiedDate
	private Instant updatedAt;
}
