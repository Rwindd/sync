package com.star.matrix.shared;

import org.slf4j.MDC;

import java.util.Objects;

public class SharedApplicationContext {
    public static final ThreadLocal<SharedData> SHARED_DATA_THREAD_LOCAL = new InheritableThreadLocal<>();


    private SharedApplicationContext() {
    }

    public static SharedData getSharedData() {
        if (Objects.nonNull(SHARED_DATA_THREAD_LOCAL.get())) {
            return SHARED_DATA_THREAD_LOCAL.get();
        } else {
            SharedData sharedData = new SharedData();
            SHARED_DATA_THREAD_LOCAL.set(sharedData);
            return sharedData;
        }
    }

    public static String getTraceId() {
        return String.valueOf(MDC.get("traceId"));
    }

    public static void removeSharedData() {
        SHARED_DATA_THREAD_LOCAL.remove();
    }
}

