package com.star.matrix.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.star.matrix.util.Generated;
import lombok.Data;

@Data
@Generated
public class BeneficiariesInfo {

	@JsonProperty("Relation")
	private String relation;

	@JsonProperty("Name")
	private String name;

	@JsonProperty("DateOfBirth")
	private String dateOfBirth;

	@JsonProperty("Gender")
	private String gender;

	@JsonProperty("EffectiveFrom")
	private String effectiveFrom;

	@JsonProperty("EffectiveTo")
	private String effectiveTo;

	@JsonProperty("ZoneForMember")
	private String zoneForMember;

	@JsonProperty("Active")
	private String active;

	@JsonProperty("IndividualSumInsured")
	private String individualSumInsured;

	@JsonProperty("InsurerBeneficiaryUniqueID")
	private String insurerBeneficiaryUniqueID;

	@JsonProperty("Inception")
	private String insurerInceptionDate;

}
