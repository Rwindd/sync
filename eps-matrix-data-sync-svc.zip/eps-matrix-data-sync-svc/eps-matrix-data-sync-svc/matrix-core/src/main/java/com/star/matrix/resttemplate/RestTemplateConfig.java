package com.star.matrix.resttemplate;

import com.star.matrix.properties.RestTemplateProperties;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import java.util.EnumMap;
import java.util.Map;

@Configuration
@RequiredArgsConstructor
public class RestTemplateConfig {

    private final Environment environment;

    @Bean
    Map<RestTemplateName, RestTemplate> restTemplateMap(MeterRegistry meterRegistry) {
        Map<RestTemplateName, RestTemplate> restTemplateMap = new EnumMap<>(RestTemplateName.class);
        for (RestTemplateName restTemplateName : RestTemplateName.values()) {
            RestTemplateProperties properties = RestTemplateUtil.getRestTemplateProperties(environment, restTemplateName);
            restTemplateMap.put(restTemplateName, RestTemplateUtil.createRestTemplate(properties, meterRegistry));
        }
        return restTemplateMap;
    }
}
