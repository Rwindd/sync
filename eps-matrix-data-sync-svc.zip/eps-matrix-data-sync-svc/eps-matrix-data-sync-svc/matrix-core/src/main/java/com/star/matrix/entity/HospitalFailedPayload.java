package com.star.matrix.entity;

import com.star.matrix.dto.request.MatrixHospitalPayload;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Document(collection = "hospitalError_payloads")
public class HospitalFailedPayload {

    @Id
    private String id;
    private String hospitalID;
    private MatrixHospitalPayload payload;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;

}
