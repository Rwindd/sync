package com.star.matrix.config;

import com.star.matrix.properties.KafkaConfigurationProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;

import java.util.Map;

@Slf4j
@EnableKafka
@Configuration
@RequiredArgsConstructor
@ConditionalOnProperty(value = "kafka.producer.enabled", havingValue = "true")
public class KafkaConsumerConfig {

    private final KafkaConfigurationProperties kafkaConfigurationProperties;

    private Map<String, Object> consumerConfigs() {
        return Map.of(
                ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,        kafkaConfigurationProperties.getBootstrapServers(),
                ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,        "earliest",
                ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG,       kafkaConfigurationProperties.getRequestTimeout(),
                ConsumerConfig.RETRY_BACKOFF_MS_CONFIG,         kafkaConfigurationProperties.getRetryBackoffMs(),
                ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG,    kafkaConfigurationProperties.getHeartbeatRate(),
                ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG,       Boolean.FALSE,
                ConsumerConfig.MAX_POLL_RECORDS_CONFIG,         kafkaConfigurationProperties.getMaxPollRecord()
        );
    }

    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        return new DefaultKafkaConsumerFactory<>(
                consumerConfigs(),
                new StringDeserializer(),
                new StringDeserializer()
        );
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        factory.setConcurrency(kafkaConfigurationProperties.getConcurrencyThreads());
        factory.getContainerProperties().setPollTimeout(kafkaConfigurationProperties.getPollTimeout());
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        factory.getContainerProperties().setObservationEnabled(true);
        return factory;
    }
}