package com.star.matrix.dto.common;

import lombok.Data;

import java.util.List;

@Data
public class ClaimDocumentSummary {

    private String intimationNumber;
    private List<ClaimDocument> claimDocuments;
}
