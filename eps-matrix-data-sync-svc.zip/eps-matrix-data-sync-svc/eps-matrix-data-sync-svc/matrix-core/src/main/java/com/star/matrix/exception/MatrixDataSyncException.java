package com.star.matrix.exception;

import lombok.Getter;

@Getter
public class MatrixDataSyncException extends RuntimeException {

  private final MatrixErrorCode matrixErrorCode;

  public MatrixDataSyncException(MatrixErrorCode matrixErrorCode) {
    super(matrixErrorCode.getDisplayMessage());
    this.matrixErrorCode = matrixErrorCode;
  }

  public MatrixDataSyncException(MatrixErrorCode matrixErrorCode, Object... args) {
    super(String.format(matrixErrorCode.getDisplayMessage(), args));
    this.matrixErrorCode = matrixErrorCode;
  }

  public MatrixDataSyncException(MatrixErrorCode matrixErrorCode, Throwable cause, Object... args) {
    super(String.format(matrixErrorCode.getDisplayMessage(), args), cause);
    this.matrixErrorCode = matrixErrorCode;
  }

  public MatrixDataSyncException(MatrixErrorCode matrixErrorCode, Throwable cause) {
    super(cause);
    this.matrixErrorCode = matrixErrorCode;
  }

  public MatrixDataSyncException(MatrixErrorCode matrixErrorCode, String displayMessage) {
    super(displayMessage);
    this.matrixErrorCode = matrixErrorCode;
  }

}
