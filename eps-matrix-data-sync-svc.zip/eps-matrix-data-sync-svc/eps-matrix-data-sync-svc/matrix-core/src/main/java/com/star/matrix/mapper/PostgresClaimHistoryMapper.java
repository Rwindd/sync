package com.star.matrix.mapper;

import com.star.matrix.dto.postgres.PostgresClaimHistory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
@Slf4j
public class PostgresClaimHistoryMapper implements RowMapper<PostgresClaimHistory> {

    @Override
    public PostgresClaimHistory mapRow(ResultSet rs, int rowNum) throws SQLException {
        PostgresClaimHistory claimHistory = new PostgresClaimHistory();

        try {
            claimHistory.setPolicyNumber(getString(rs, "POLICY_NUMBER"));
            claimHistory.setHeathId(getString(rs, "HEATH_ID"));
            claimHistory.setPolicyYear(getString(rs, "POLICY_YEAR"));
            claimHistory.setClaimNumber(getString(rs, "CLAIM_NUMBER"));
            claimHistory.setClaimType(getString(rs, "CLAIM_TYPE"));
            claimHistory.setIntimationNumber(getString(rs, "INTIMATION_NUMBER"));
            claimHistory.setPatientName(getString(rs, "PATIENT_NAME"));
            claimHistory.setDiagnosis(getString(rs, "DIAGNOSIS"));
            claimHistory.setAdmissionDate(getString(rs, "ADMISSION_DATE"));
            claimHistory.setClaimStatus(getString(rs, "CLAIM_STATUS"));
            claimHistory.setSiRestrictionFlag(getString(rs, "SI_RESTRICTION_FLAG"));
            claimHistory.setHospitalName(getString(rs, "HOSPITAL_NAME"));
            claimHistory.setPedName(getString(rs, "PED_NAME"));
            claimHistory.setIcdCode(getString(rs, "ICD_CODE"));
            claimHistory.setSublimitCategory(getString(rs, "SUBLIMIT_CATEGORY"));
            claimHistory.setSurrogacyOocyteCover(getString(rs, "SURROGACY_OOCYTE_COVER"));
            claimHistory.setCataractDetails(getString(rs, "CATARACT_DETAILS"));
            claimHistory.setSublimitName(getString(rs, "SUBLIMIT_NAME"));
            claimHistory.setClaimedAmount(formatDouble(rs, "CLAIMED_AMOUNT"));
            claimHistory.setApprovedAmount(formatDouble(rs, "APPROVED_AMOUNT"));
            claimHistory.setCopay(formatDouble(rs, "COPAY"));
            claimHistory.setSublimitAmont(formatDouble(rs, "SUBLIMIT_AMONT"));

        } catch (SQLException e) {
            log.error("Error mapping row {} for claim: {}", rowNum, getString(rs, "CLAIM_NUMBER"), e);
            throw e;
        }

        return claimHistory;
    }

    private String getString(ResultSet rs, String column) throws SQLException {
        String value = rs.getString(column);
        return rs.wasNull() ? null : value;
    }

    private Double formatDouble(ResultSet rs, String column) throws SQLException {
        Object value = rs.getObject(column);
        if (rs.wasNull()) {
            return null;
        }

        try {
            if (value instanceof Number) {
                return ((Number) value).doubleValue();
            } else if (value instanceof String) {
                String stringValue = ((String) value).trim();
                if (!stringValue.isEmpty()) {
                    return Double.parseDouble(stringValue);
                }
            }
            return null;
        } catch (Exception e) {
            log.warn("Unexpected error parsing {} value: {}", column, value, e);
        }
        return null;
    }
}