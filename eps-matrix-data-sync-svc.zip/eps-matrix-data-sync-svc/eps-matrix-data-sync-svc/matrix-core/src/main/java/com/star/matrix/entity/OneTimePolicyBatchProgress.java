package com.star.matrix.entity;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Document(collection = "one_time_policy_batch_progress")
public class OneTimePolicyBatchProgress {

	@Id
	private String id;
	private BatchStatus status;
	private long startIndex;
	private long endIndex;
	private boolean isMatrixSuccess;
	private int retries;
	private String traceId;
	@CreatedDate
	private Instant createdAt;
	@LastModifiedDate
	private Instant updatedAt;

}