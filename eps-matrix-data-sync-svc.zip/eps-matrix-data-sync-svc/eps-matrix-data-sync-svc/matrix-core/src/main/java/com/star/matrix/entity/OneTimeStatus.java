package com.star.matrix.entity;

public enum OneTimeStatus {

    STOPPED, IN_PROGRESS, COMPLETED, FAILED, RETRY_STOPPED, RETRY_INITIATED
}
