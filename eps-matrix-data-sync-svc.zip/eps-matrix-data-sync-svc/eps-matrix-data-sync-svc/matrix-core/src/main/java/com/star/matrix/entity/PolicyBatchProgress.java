package com.star.matrix.entity;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.time.LocalDateTime;

@Data
@Document(collection = "policy_batch_progress")
public class PolicyBatchProgress {

	@Id
	private String id;
	private LocalDateTime date;
	private BatchStatus status;
	private String traceId;
	private int startIndex;
	private int endIndex;
	@CreatedDate
	private Instant createdAt;
	@LastModifiedDate
	private Instant updatedAt;

}