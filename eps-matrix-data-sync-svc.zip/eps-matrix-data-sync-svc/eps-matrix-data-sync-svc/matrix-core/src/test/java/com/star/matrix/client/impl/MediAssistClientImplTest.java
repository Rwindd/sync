package com.star.matrix.client.impl;

import com.star.matrix.dto.PolicyDataResponse;
import com.star.matrix.dto.request.MatrixHospitalPayload;
import com.star.matrix.dto.response.MatrixPmsResponse;
import com.star.matrix.dto.response.MatrixPolicyResponse;
import com.star.matrix.properties.ApplicationProperties;
import com.star.matrix.resttemplate.RestTemplateName;
import com.star.matrix.util.ObjectMapperUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class MediAssistClientImplTest {

    private RestTemplate restTemplate;
    private ApplicationProperties applicationProperties;
    private MediAssistClientImpl mediAssistClient;
    private Map<RestTemplateName, RestTemplate> restTemplateMap;

    @BeforeEach
    void setUp() {
        restTemplate = mock(RestTemplate.class);
        applicationProperties = mock(ApplicationProperties.class);
        restTemplateMap = new HashMap<>();
        restTemplateMap.put(RestTemplateName.MATRIX_SERVICE, restTemplate);

        mediAssistClient = new MediAssistClientImpl(restTemplateMap, applicationProperties);
    }

    @Test
    void testHospitalPush_success() throws Exception {
        MatrixHospitalPayload requestObject = new MatrixHospitalPayload();
        String hospitalPushUrl = "http://localhost/hospital-push";

        MatrixPmsResponse expectedResponse = new MatrixPmsResponse();
        ResponseEntity<MatrixPmsResponse> responseEntity = new ResponseEntity<>(expectedResponse, HttpStatus.OK);

        when(applicationProperties.getMatrixHospitalPushUrl()).thenReturn(hospitalPushUrl);
        when(restTemplate.exchange(any(RequestEntity.class), any(ParameterizedTypeReference.class)))
                .thenReturn(responseEntity);

        MatrixPmsResponse actualResponse = mediAssistClient.hospitalPush(ObjectMapperUtil.convertObjectToJson(requestObject));

        assertThat(actualResponse).isEqualTo(expectedResponse);

        ArgumentCaptor<RequestEntity> captor = ArgumentCaptor.forClass(RequestEntity.class);
        verify(restTemplate).exchange(captor.capture(), any(ParameterizedTypeReference.class));

        RequestEntity captured = captor.getValue();
        assertThat(captured.getUrl()).isEqualTo(new URI(hospitalPushUrl));
        assertThat(captured.getMethod()).isEqualTo(HttpMethod.POST);
        assertThat(captured.getHeaders().getContentType()).isEqualTo(MediaType.APPLICATION_JSON);
        assertThat(captured.getBody()).isEqualTo(ObjectMapperUtil.convertObjectToJson(requestObject));
    }

    @Test
    void testHospitalPush_failure() throws Exception {
        MatrixHospitalPayload requestObject = new MatrixHospitalPayload();

        when(applicationProperties.getMatrixHospitalPushUrl()).thenReturn("http://fail-url");
        when(restTemplate.exchange(any(RequestEntity.class), any(ParameterizedTypeReference.class)))
                .thenThrow(new RuntimeException("Simulated error"));

        MatrixPmsResponse response = mediAssistClient.hospitalPush(ObjectMapperUtil.convertObjectToJson(requestObject));

        assertThat(response).isNotNull();
    }

    @Test
    void testPolicyPush_success() throws Exception {
        PolicyDataResponse requestObject = new PolicyDataResponse();
        String policyPushUrl = "http://localhost/policy-push";

        MatrixPolicyResponse expectedResponse = new MatrixPolicyResponse();
        ResponseEntity<MatrixPolicyResponse> responseEntity = new ResponseEntity<>(expectedResponse, HttpStatus.OK);

        when(applicationProperties.getMatrixPolicyPushUrl()).thenReturn(policyPushUrl);
        when(restTemplate.exchange(any(RequestEntity.class), any(ParameterizedTypeReference.class)))
                .thenReturn(responseEntity);

        MatrixPolicyResponse actualResponse = mediAssistClient.policyPush(requestObject);

        assertThat(actualResponse).isEqualTo(expectedResponse);

        ArgumentCaptor<RequestEntity> captor = ArgumentCaptor.forClass(RequestEntity.class);
        verify(restTemplate).exchange(captor.capture(), any(ParameterizedTypeReference.class));

        RequestEntity captured = captor.getValue();
        assertThat(captured.getUrl()).isEqualTo(new URI(policyPushUrl));
        assertThat(captured.getMethod()).isEqualTo(HttpMethod.POST);
        assertThat(captured.getHeaders().getContentType()).isEqualTo(MediaType.APPLICATION_JSON);
        assertThat(captured.getBody()).isEqualTo(requestObject);
    }

    @Test
    void testPolicyPush_failure() throws Exception {
        PolicyDataResponse requestObject = new PolicyDataResponse();

        when(applicationProperties.getMatrixPolicyPushUrl()).thenReturn("http://fail-url");
        when(restTemplate.exchange(any(RequestEntity.class), any(ParameterizedTypeReference.class)))
                .thenThrow(new RuntimeException("Simulated error"));

        MatrixPolicyResponse response = mediAssistClient.policyPush(requestObject);

        assertThat(response).isNotNull();
    }
}
