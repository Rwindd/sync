
package com.star.matrix.client.impl;

import com.star.matrix.dto.request.StatementIDRequest;
import com.star.matrix.dto.response.DataBricksResponse;
import com.star.matrix.properties.ApplicationProperties;
import com.star.matrix.resttemplate.RestTemplateName;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class DataLakeClientImplTest {

    private RestTemplate restTemplate;
    private ApplicationProperties applicationProperties;
    private DataLakeClientImpl dataLakeClient;
    private Map<RestTemplateName, RestTemplate> restTemplateMap;

    @BeforeEach
    void setUp() {
        restTemplate = mock(RestTemplate.class);
        applicationProperties = mock(ApplicationProperties.class);
        restTemplateMap = new HashMap<>();
        restTemplateMap.put(RestTemplateName.DATA_LAKE_SERVICE, restTemplate);

        dataLakeClient = new DataLakeClientImpl(restTemplateMap, applicationProperties);
    }

    @Test
    void testGetDataBricksResponse_success() throws Exception {
        StatementIDRequest request = new StatementIDRequest();
        String databricksUrl = "http://dummy-url.com";

        DataBricksResponse mockResponse = new DataBricksResponse();
        ResponseEntity<DataBricksResponse> responseEntity = new ResponseEntity<>(mockResponse, HttpStatus.OK);

        when(applicationProperties.getToken()).thenReturn("dummy-token");
        when(applicationProperties.getDatabricksUrl()).thenReturn(databricksUrl);
        when(restTemplate.exchange(
                any(RequestEntity.class),
                any(ParameterizedTypeReference.class)
        )).thenReturn(responseEntity);

        DataBricksResponse result = dataLakeClient.getDataBricksResponse(request);

        assertThat(result).isEqualTo(mockResponse);

        ArgumentCaptor<RequestEntity> captor = ArgumentCaptor.forClass(RequestEntity.class);
        verify(restTemplate).exchange(captor.capture(), any(ParameterizedTypeReference.class));

        RequestEntity capturedRequest = captor.getValue();
        assertThat(capturedRequest.getUrl()).isEqualTo(new URI(databricksUrl));
        assertThat(capturedRequest.getMethod()).isEqualTo(HttpMethod.POST);
        assertThat(capturedRequest.getHeaders().getFirst("Authorization")).isEqualTo("Bearer dummy-token");
    }

    @Test
    void testGetDataBricksResponse_failure() {
        StatementIDRequest request = new StatementIDRequest();

        when(applicationProperties.getToken()).thenReturn("dummy-token");
        when(applicationProperties.getDatabricksUrl()).thenReturn("malformed-url");
        when(restTemplate.exchange(any(RequestEntity.class), any(ParameterizedTypeReference.class)))
                .thenThrow(new RuntimeException("API failed"));

        DataBricksResponse response = dataLakeClient.getDataBricksResponse(request);
        assertThat(response).isNotNull();
    }

    @Test
    void testStopDBConnection_success() throws Exception {
        String stopUrl = "http://stop-url.com";
        DataBricksResponse mockResponse = new DataBricksResponse();
        ResponseEntity<DataBricksResponse> responseEntity = new ResponseEntity<>(mockResponse, HttpStatus.OK);

        when(applicationProperties.getToken()).thenReturn("dummy-token");
        when(applicationProperties.getConnectionStopUrl()).thenReturn(stopUrl);
        when(restTemplate.exchange(
                any(RequestEntity.class),
                any(ParameterizedTypeReference.class)
        )).thenReturn(responseEntity);

        boolean result = dataLakeClient.stopDBConnection();
        assertThat(result).isTrue();
    }

    @Test
    void testStopDBConnection_failure() {
        when(applicationProperties.getToken()).thenReturn("dummy-token");
        when(applicationProperties.getConnectionStopUrl()).thenReturn("bad-url");
        when(restTemplate.exchange(any(RequestEntity.class), any(ParameterizedTypeReference.class)))
                .thenThrow(new RuntimeException("Failure"));

        boolean result = dataLakeClient.stopDBConnection();
        assertThat(result).isFalse();
    }
}
