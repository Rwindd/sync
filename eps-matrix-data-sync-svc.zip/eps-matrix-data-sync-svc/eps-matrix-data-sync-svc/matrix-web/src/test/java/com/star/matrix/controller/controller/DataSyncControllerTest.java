package com.star.matrix.controller.controller;

import com.star.matrix.DataSyncService;
import com.star.matrix.controller.DataSyncController;
import com.star.matrix.dto.request.PMSDataPullingRequest;
import com.star.matrix.dto.request.PolicyDataPullingRequest;
import com.star.matrix.response.ResponseObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class DataSyncControllerTest {

    private DataSyncService dataSyncService;
    private DataSyncController dataSyncController;

    @BeforeEach
    void setUp() {
        dataSyncService = mock(DataSyncService.class);
        dataSyncController = new DataSyncController(dataSyncService);
    }

    @Test
    void testRunPmsSync_shouldCallServiceWithConvertedDateTimes() {
        long startEpoch = 1717564800000L;
        long endEpoch = 1717651200000L;
        PMSDataPullingRequest request = new PMSDataPullingRequest(startEpoch, endEpoch);

        ResponseObject<String> response = dataSyncController.runPmsSync(request);

        ArgumentCaptor<LocalDateTime> startCaptor = ArgumentCaptor.forClass(LocalDateTime.class);
        ArgumentCaptor<LocalDateTime> endCaptor = ArgumentCaptor.forClass(LocalDateTime.class);

        verify(dataSyncService).processPmsDataFromDataLake(startCaptor.capture(), endCaptor.capture());

        LocalDateTime expectedStart = Instant.ofEpochMilli(startEpoch)
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();
        LocalDateTime expectedEnd = Instant.ofEpochMilli(endEpoch)
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();

        assertThat(startCaptor.getValue()).isEqualTo(expectedStart);
        assertThat(endCaptor.getValue()).isEqualTo(expectedEnd);
        assertThat(response.meta().displayMessage()).isEqualTo("Hospital Data Pulled Successfully");
    }


    @Test
    void testRunMatrixPmsSync_shouldCallProcessPmsDataToMatrix() {
        PMSDataPullingRequest request = new PMSDataPullingRequest(1717564800000L, 1717651200000L);
        ResponseObject<String> response = dataSyncController.runMatrixPmsSync(request);
        verify(dataSyncService, times(1)).processPmsDataToMatrix();
        assertThat(response.meta().displayMessage()).isEqualTo("Pms data pushed to matrix");
    }

    @Test
    void testRunMatrixPolicySync_shouldCallProcessMinimumPolicyDataToMatrix() {
        ResponseObject<String> response = dataSyncController.runMatrixPolicySync();
        verify(dataSyncService, times(1)).processMinimumPolicyDataToMatrix();
        assertThat(response.meta().displayMessage()).isEqualTo("policy data pushed to matrix");
    }


    @Test
    void testRunPolicySync_shouldCallServiceWithConvertedDate() {
        long epochMillis = 1717545600000L;
        PolicyDataPullingRequest request = new PolicyDataPullingRequest();
        request.setPullingDate(epochMillis);
        ResponseObject<String> response = dataSyncController.runPolicySync(request);

        ArgumentCaptor<LocalDate> dateCaptor = ArgumentCaptor.forClass(LocalDate.class);
        verify(dataSyncService, times(1)).processMinimumPolicyDataFromDataLake(dateCaptor.capture(), anyBoolean());

        LocalDate expectedDate = Instant.ofEpochMilli(epochMillis)
                .atZone(ZoneId.systemDefault())
                .toLocalDate();

        assertThat(dateCaptor.getValue()).isEqualTo(expectedDate);
        assertThat(response.meta().displayMessage()).isEqualTo("Policy Data Pulled Successfully");
    }

}
