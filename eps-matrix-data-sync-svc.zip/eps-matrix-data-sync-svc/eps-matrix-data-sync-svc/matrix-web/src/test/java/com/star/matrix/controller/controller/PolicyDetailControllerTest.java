package com.star.matrix.controller.controller;

import com.star.matrix.PolicyDetailService;
import com.star.matrix.controller.PolicyDetailController;
import com.star.matrix.dto.response.PolicyHistoryResponse;
import com.star.matrix.response.ResponseObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PolicyDetailControllerTest {

    @Mock
    private PolicyDetailService policyDetailService;

    @InjectMocks
    private PolicyDetailController policyDetailController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetPolicyDetails_Success() {
        String policyNumber = "POL123456";
        PolicyHistoryResponse mockResponse = new PolicyHistoryResponse();
        when(policyDetailService.getPolicyHistoryDetails(policyNumber)).thenReturn(mockResponse);
        ResponseObject<PolicyHistoryResponse> response = policyDetailController.getPolicyDetails(policyNumber);
        assertNotNull(response);
        assertEquals("policy details fetched successfully", response.meta().displayMessage());
        assertEquals(mockResponse, response.data());
        verify(policyDetailService, times(1)).getPolicyHistoryDetails(policyNumber);
    }

    @Test
    void testGetPolicyDetails_Failure() {

        String policyNumber = "INVALID_POLICY";
        when(policyDetailService.getPolicyHistoryDetails(policyNumber))
                .thenThrow(new RuntimeException("Policy not found"));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            policyDetailController.getPolicyDetails(policyNumber);
        });

        assertEquals("Policy not found", exception.getMessage());
        verify(policyDetailService, times(1)).getPolicyHistoryDetails(policyNumber);
    }
}

