package com.star.matrix.controller.scheduler;
import com.star.matrix.DataSyncService;
import com.star.matrix.EnvVariablesService;
import com.star.matrix.properties.ApplicationProperties;
import com.star.matrix.scheduler.MatrixScheduler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

class MatrixSchedulerTest {

    private DataSyncService dataSyncService;

    private EnvVariablesService envVariablesService;
    private MatrixScheduler matrixScheduler;

    @BeforeEach
    void setUp() {
        dataSyncService = mock(DataSyncService.class);
        envVariablesService = mock(EnvVariablesService.class);
        matrixScheduler = new MatrixScheduler(dataSyncService, envVariablesService);
    }

    @Test
    void testEpsHospitalDataFetchScheduler_callsProcessPmsDataToMatrix() {
        matrixScheduler.epsHospitalDataFetchScheduler();
        verify(dataSyncService, times(1)).processPmsDataToMatrix();
    }

    @Test
    void testEpsPolicyDataFetchScheduler_callsProcessMinimumPolicyDataToMatrix() {
        matrixScheduler.epsPolicyDataFetchScheduler();
        verify(dataSyncService, times(1)).processMinimumPolicyDataToMatrix();
    }

    @Test
    void testPmsDataFetchScheduler_callsProcessPmsDataFromDataLake() {
        matrixScheduler.pmsDataFetchScheduler();
        verify(dataSyncService, times(0)).processPmsDataFromDataLake();
    }

    @Test
    void testPolicyDataFetchScheduler_callsProcessMinimumPolicyDataFromDataLake() {
        matrixScheduler.policyDataFetchScheduler();
        verify(dataSyncService, times(0)).processMinimumPolicyDataFromDataLake();
    }
}
