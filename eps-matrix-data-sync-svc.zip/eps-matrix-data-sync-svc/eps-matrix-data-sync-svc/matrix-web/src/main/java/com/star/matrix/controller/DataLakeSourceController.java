package com.star.matrix.controller;

import com.star.matrix.DataLakeService;
import com.star.matrix.dto.request.PolicyInsuredDetailsRequest;
import com.star.matrix.dto.request.DataLakeRequestDto;
import com.star.matrix.dto.response.PolciyInsuredDetailsResponse;
import com.star.matrix.dto.response.DataLakeResponseDto;
import com.star.matrix.response.ResponseObject;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@Slf4j
public class DataLakeSourceController {

    private final DataLakeService service;

    public DataLakeSourceController(DataLakeService service) {
        this.service = service;
    }

    @PostMapping("/intimation/processingsystem")
    public ResponseEntity<ResponseObject<DataLakeResponseDto>> handleIntimation(@Valid @RequestBody DataLakeRequestDto request) {
        log.info("[DataLakeSourceController]- getProcessingSystem API");
        var response = new ResponseObject<>("Fetch Successfully", service.processIntimation(request.getIntimationNumber()));
        return ResponseEntity.ok(response);
    }

//    @PostMapping("/policydetails")
//    public ResponseEntity<ResponseObject<DataLakeCustomerDetailsResponse>> handlePolicyNumber(@Valid @RequestBody DataLakeCustomerDetailsRequest request){
//        log.info("[DataLakeSourceController]- getPolicyDetails API");
//        var reponse = new ResponseObject<>("Fetch Successfully",service.getPolicyDetails(request.getPolicyNumber()));
//        return ResponseEntity.ok(reponse);
//    }


    @PostMapping("/knowyourpolicy/policy/details")
    public ResponseEntity<ResponseObject<PolciyInsuredDetailsResponse>> handlePolicyNumber(
            @Valid @RequestBody PolicyInsuredDetailsRequest request) {

        log.info("[DataLakeSourceController] getCustomerDetails API for policyNumber={}", request.getPolicyNumber());

        PolciyInsuredDetailsResponse result = service.getPolicyDetails(request.getPolicyNumber());

        ResponseObject<PolciyInsuredDetailsResponse> response =
                new ResponseObject<>("Fetch Successfully", result);

        return ResponseEntity.ok(response);
    }
}