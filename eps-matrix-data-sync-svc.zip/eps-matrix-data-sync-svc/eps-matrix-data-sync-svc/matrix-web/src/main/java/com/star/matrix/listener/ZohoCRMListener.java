package com.star.matrix.listener;

import com.star.matrix.ZohoService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RequiredArgsConstructor
public class ZohoCRMListener {

    private final ZohoService zohoService;

    @KafkaListener(
            topics = "${kafka.topic.zoho-crm}",
            groupId = "${kafka.consumer.group-id}",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void processZohoCrm(String event, Acknowledgment acknowledgment) {
        log.info("Event listened : {}", event);
        try{
            String recordId = event;
            log.info("Renewal policy object IDs : {}", recordId);
            zohoService.pushZohoCRMToMatrix(recordId);
        } catch (Exception e) {
            log.error("Error while processing Payload : {}", event, e);
        } finally {
            acknowledgment.acknowledge();
        }
    }
}
