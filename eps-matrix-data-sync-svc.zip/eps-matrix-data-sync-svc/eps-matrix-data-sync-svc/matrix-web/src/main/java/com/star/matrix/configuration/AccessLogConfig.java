package com.star.matrix.configuration;

import ch.qos.logback.access.tomcat.LogbackValve;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.InetAddress;
import java.net.UnknownHostException;

@Slf4j
@Configuration
@NoArgsConstructor
public class AccessLogConfig {

    @Value("${spring.application.name}")
    private String applicationName;

    @Bean
    public WebServerFactoryCustomizer<TomcatServletWebServerFactory> accessLogsCustomizer() {
        return factory -> {
            LogbackValve logbackValve = new LogbackValve();
            InetAddress inetAddress = null;
            try {
                inetAddress = InetAddress.getLocalHost();
            } catch (UnknownHostException e) {
                throw new RuntimeException(e);
            }
            String hostname = inetAddress.getHostName();
            // Ensure the config file is in src/main/resources
            logbackValve.setFilename("logback-access.xml");
            logbackValve.setQuiet(false); // Set to false to see any errors
            logbackValve.setAsyncSupported(true);

            // Set system properties instead of valve properties
            System.setProperty("HOSTNAME", hostname);
            System.setProperty("APPLICATION_NAME", applicationName);

            factory.addContextValves(logbackValve);
            log.info("Access log configuration initialized with hostname: {} and app: {}", hostname, applicationName);
        };
    }
}