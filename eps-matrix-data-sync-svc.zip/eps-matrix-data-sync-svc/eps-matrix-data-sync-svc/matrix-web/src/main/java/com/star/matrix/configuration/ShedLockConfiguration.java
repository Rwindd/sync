package com.star.matrix.configuration;

import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.mongo.MongoLockProvider;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "${scheduler.default.max.lock.for:10m}")
@Configuration
public class ShedLockConfiguration {

    @Bean
    public LockProvider lockProvider(MongoTemplate documentMongoTemplate) {
        return new MongoLockProvider(documentMongoTemplate.getDb());
    }

}
