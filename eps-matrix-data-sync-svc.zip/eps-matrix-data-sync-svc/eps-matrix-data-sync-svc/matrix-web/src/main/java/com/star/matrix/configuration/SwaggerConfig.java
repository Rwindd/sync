package com.star.matrix.configuration;

import com.star.matrix.exception.MatrixErrorCode;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;

@Configuration
public class SwaggerConfig {

    public static final String CLIENT_ID = "client-id";
    public static final String X_API_KEY = "x-api-key";
    public static final char CHAR_SEPARATOR = '|';
    public static final String NEW_LINE_SEPARATOR = "|\n";
    public static final HttpStatus HTTP_STATUS_CREATED = HttpStatus.CREATED;

    private static String getErrorCodes() {
        StringBuilder errorTable = new StringBuilder();
        String heading = "| Response Code | Message | Display Message  | Http Status Code | Http Status Description |\n";
        String format = "|----------------|---------|------------------|------------------|-------------------------|\n";
        errorTable.append(heading);
        errorTable.append(format);

        errorTable.append(CHAR_SEPARATOR).append("200").append(CHAR_SEPARATOR)
                .append("SUCCESS").append(CHAR_SEPARATOR)
                .append("success message").append(CHAR_SEPARATOR)
                .append(HTTP_STATUS_CREATED.value()).append(CHAR_SEPARATOR)
                .append(HTTP_STATUS_CREATED.name()).append(NEW_LINE_SEPARATOR);

        for (MatrixErrorCode errorCode : MatrixErrorCode.values()) {
            errorTable.append(CHAR_SEPARATOR).append(errorCode.getCode()).append(CHAR_SEPARATOR)
                    .append(errorCode.name()).append(CHAR_SEPARATOR)
                    .append(errorCode.getDisplayMessage()).append(CHAR_SEPARATOR)
                    .append(errorCode.getHttpStatus().value()).append(CHAR_SEPARATOR)
                    .append(errorCode.getHttpStatus().name()).append(NEW_LINE_SEPARATOR);
        }

        return collapsableMarkdown("Error Codes", errorTable.toString());

    }

    private static String collapsableMarkdown(String summary, String description) {
        return "<details>\n"
                + "  <summary><b>" + summary + "</b> (Click here)</summary>\n"
                + description
                + "</details>";
    }

    @Bean
    public OpenAPI openApi() {

        String description = getErrorCodes() + "<br/>";

        return new OpenAPI()
                .info(new Info()
                        .title("Schema Registry Service")
                        .description(description)
                        .version("v1.0.0"))
                .components(new Components()
                        .addSecuritySchemes(X_API_KEY, new SecurityScheme()
                                .type(SecurityScheme.Type.APIKEY)
                                .in(SecurityScheme.In.HEADER)
                                .name(X_API_KEY))
                        .addSecuritySchemes(CLIENT_ID, new SecurityScheme()
                                .type(SecurityScheme.Type.APIKEY)
                                .in(SecurityScheme.In.HEADER)
                                .name(CLIENT_ID)))
                .addSecurityItem(new SecurityRequirement().addList(X_API_KEY).addList(CLIENT_ID));
    }
}