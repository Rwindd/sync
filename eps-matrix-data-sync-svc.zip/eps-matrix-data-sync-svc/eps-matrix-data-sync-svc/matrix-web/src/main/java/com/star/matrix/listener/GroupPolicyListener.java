package com.star.matrix.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.star.matrix.GroupPolicyMigrationService;
import com.star.matrix.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
@RequiredArgsConstructor
public class GroupPolicyListener {

    private final GroupPolicyMigrationService GroupPolicyMigrationService;

    @KafkaListener(
            topics = "${kafka.topic.group-policy}",
            groupId = "${kafka.consumer.group-id}",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void processGroupPolicy(String event, Acknowledgment acknowledgment) {
        log.info("Event listened : {}", event);
        try{
            String recordId = event;
            log.info("Group policy object IDs : {}", recordId);
            GroupPolicyMigrationService.pushGroupPolicyToMatrix(recordId);
        } catch (Exception e) {
            log.error("Error while processing Payload : {}", event, e);
        } finally {
            acknowledgment.acknowledge();
        }
    }
}