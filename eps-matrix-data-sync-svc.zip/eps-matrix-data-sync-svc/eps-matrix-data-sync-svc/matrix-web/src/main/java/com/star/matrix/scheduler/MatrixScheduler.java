package com.star.matrix.scheduler;

import com.star.eps.annotations.StarLogging;
import com.star.matrix.DataSyncService;
import com.star.matrix.EnvVariablesService;
import com.star.matrix.logging.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import static com.star.matrix.constant.EnvVariableConstant.*;

@Slf4j
@RequiredArgsConstructor
@Configuration
public class MatrixScheduler {

    private final DataSyncService dataSyncService;
    private final EnvVariablesService envVariablesService;

    @Scheduled(cron = "${matrix.scheduler.push.pms.cron}")
    @SchedulerLock(name = "matrixHospitalDataFetchScheduler", lockAtMostFor = "PT5M", lockAtLeastFor = "PT1M")
    @StarLogging(loggingEvent = MatrixSchedulerPmsSchedulerProcessor.class, actionName = "MATRIX_SCHEDULER_PMS")
    public void epsHospitalDataFetchScheduler() {
        log.info("initiated matrix Hospital Data Fetch Scheduler");
        dataSyncService.processPmsDataToMatrix();
    }

    @Scheduled(cron = "${matrix.scheduler.push.policy.cron}")
    @SchedulerLock(name = "matrixPolicyDataFetchScheduler", lockAtMostFor = "PT5M", lockAtLeastFor = "PT1M")
    @StarLogging(loggingEvent = MatrixSchedulerPolicySchedulerProcessor.class, actionName = "MATRIX_SCHEDULER_POLICY")
    public void epsPolicyDataFetchScheduler() {
        log.info("initiated Matrix Policy Data Fetch Scheduler");
        dataSyncService.processMinimumPolicyDataToMatrix();
    }

    @Scheduled(cron = "${schedular.databricks.pms.cron}")
    @StarLogging(loggingEvent = DataLakePmsSchedulerProcessor.class, actionName = "DATALAKE_PMS_SCHEDULER")
    @SchedulerLock(name = "databricksPmsScheduler", lockAtMostFor = "PT5M", lockAtLeastFor = "PT1M")
    public void pmsDataFetchScheduler() {
        if (!envVariablesService.getBool(DATABRICKS_PMS_SCHEDULER_ENABLED.name(), false)) {
            log.info("Pms Scheduler is disabled");
            return;
        }
        log.info("initiated PMS Data Fetch Scheduler");
        dataSyncService.processPmsDataFromDataLake();
    }

    @Scheduled(cron = "${schedular.databricks.policy.cron}")
    @StarLogging(loggingEvent = DataLakePolicySchedulerProcessor.class, actionName = "DATALAKE_POLICY_SCHEDULER")
    @SchedulerLock(name = "databricksPolicyScheduler", lockAtMostFor = "${schedular.databricks.policy.lockAtMost}", lockAtLeastFor = "${schedular.databricks.policy.lockAtLeast}")
    public void policyDataFetchScheduler() {
        if (!envVariablesService.getBool(DATABRICKS_POLICY_SCHEDULER_ENABLED.name(), false)) {
            log.info("Policy Scheduler is disabled");
            return;
        }
        log.info("initiated Policy Data Fetch Scheduler");
        dataSyncService.processMinimumPolicyDataFromDataLake();
    }

    @Scheduled(cron = "${schedular.databricks.zoho.cron}")
    @StarLogging(loggingEvent = DataLakeRenewQuoteSchedulerProcessor.class, actionName = "DATALAKE_RENEW_QUOTE_SCHEDULER")
    @SchedulerLock(name = "databricksRenewQuoteScheduler", lockAtMostFor = "${schedular.databricks.zoho.lockAtMost}", lockAtLeastFor = "${schedular.databricks.zoho.lockAtLeast}")
    public void renewQuoteDataFetchScheduler() {
        if (!envVariablesService.getBool(DATABRICKS_ZOHO_RENEW_QUOTE_SCHEDULER_ENABLED.name(), false)) {
            log.info("Renew Quote Scheduler is disabled");
            return;
        }
        log.info("initiated renew quote Data Fetch Scheduler");
        dataSyncService.processRenewQuoteDataFromDataLake();
    }

    @Scheduled(cron = "${zoho.scheduler.push.renewQuote.cron}")
    @SchedulerLock(name = "zohoRenewQuoteDataFetchScheduler", lockAtMostFor = "PT5M", lockAtLeastFor = "PT1M")
    @StarLogging(loggingEvent = ZohoRenewQuoteSchedulerProcessor.class, actionName = "ZOHO_SCHEDULER_RENEW_QUOTE")
    public void epsRenewQuoteDataFetchScheduler() {
        log.info("initiated Zoho renew Quote Data Fetch Scheduler");
        dataSyncService.processRenewQuoteDataToZoho();
    }

    @Scheduled(cron = "${schedular.databricks.zoho.retry.cron}")
    @SchedulerLock(name = "renewQuotePolicyDataRetryScheduler", lockAtMostFor = "${schedular.databricks.zoho.retry.lockAtMost}", lockAtLeastFor = "${schedular.databricks.zoho.retry.lockAtLeast}")
    @StarLogging(loggingEvent = ZohoRenewQuoteSchedulerProcessor.class, actionName = "ZOHO_SCHEDULER_RENEW_QUOTE")
    public void retryZohoRenewalPoliciesScheduler(){
        if (!envVariablesService.getBool(ZOHO_PUSH_FAILED_RENEW_QUOTE_SCHEDULER_ENABLED.name(), false)) {
            log.info("retryFailedZohoRenewalFetchScheduler is disabled");
            return;
        }
        log.info("initiated Retry failed Zoho renewal Policy Scheduler");
        dataSyncService.processRetryableZohoRenewalToMatrix();
    }

    @Scheduled(cron = "${schedular.databricks.group-policy.cron}")
    @StarLogging(loggingEvent = DataLakeGroupPolicySchedulerProcessor.class, actionName = "DATALAKE_GROUP_POLICY_SCHEDULER")
    @SchedulerLock(name = "databricksGroupPolicyScheduler", lockAtMostFor = "${schedular.databricks.group-policy.lockAtMost}", lockAtLeastFor = "${schedular.databricks.group-policy.lockAtLeast}")
    public void groupPolicyDataFetchScheduler() {
        if (!envVariablesService.getBool(DATABRICKS_GROUP_POLICY_FETCH_SCHEDULER_ENABLED.name(), false)) {
            log.info("Group policy Scheduler is disabled");
            return;
        }
        log.info("initiated groupPolicyDataFetchScheduler");
        dataSyncService.processMinimumGroupPolicyDataFromDataLake();
    }

    @Scheduled(cron = "${schedular.databricks.group-policy.retry.cron}")
    @SchedulerLock(name = "groupPolicyDataFetchScheduler", lockAtMostFor = "${schedular.databricks.group-policy.retry.lockAtMost}", lockAtLeastFor = "${schedular.databricks.group-policy.retry.lockAtLeast}")
    @StarLogging(loggingEvent = MatrixSchedulerGroupPolicySchedulerProcessor.class, actionName = "MATRIX_SCHEDULER_GROUP_POLICY")
    public void retryGroupPoliciesScheduler(){
        if (!envVariablesService.getBool(MATRIX_PUSH_FAILED_GROUP_POLICY_SCHEDULER_ENABLED.name(), false)) {
            log.info("retryFailedGroupPolicyFetchScheduler is disabled");
            return;
        }
        log.info("initiated Retry failed Group Policy Scheduler");
        dataSyncService.processRetryableGroupPolicyToMatrix();
    }

    @Scheduled(cron = "0 0/30 * * * *")
    public void refreshEnvironmentVariables() {
        log.info("Refresh Environment variables");
        envVariablesService.refreshCache();
    }
}