package com.star.matrix.controller;

import com.star.eps.annotations.StarLogging;
import com.star.matrix.EnvVariablesService;
import com.star.matrix.client.DataLakeClient;
import com.star.matrix.dto.request.EnvVariableDeleteRequestDto;
import com.star.matrix.dto.request.EnvironmentVariablesRequestDto;
import com.star.matrix.dto.request.StatementIDRequest;
import com.star.matrix.dto.response.DataBricksResponse;
import com.star.matrix.dto.response.EnvVariablesResponse;
import com.star.matrix.logging.PolicyHistoryControllerApiProcessorImpl;
import com.star.matrix.repository.PmsBatchProgressRepository;
import com.star.matrix.repository.PolicyBatchDetailRepository;
import com.star.matrix.response.ResponseObject;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.star.matrix.util.ApplicationConstant.POLICY_HISTORY_API_CONTROLLER_PROCESSOR;

@RestController
@RequestMapping("/api/v1")
@Slf4j
@RequiredArgsConstructor
public class EnvironmentVariableController {

    private final EnvVariablesService envVariablesService;
    private final DataLakeClient dataLakeClient;
    private final PmsBatchProgressRepository pmsBatchProgressRepository;
    private final PolicyBatchDetailRepository policyBatchDetailRepository;

    @GetMapping("/fetchEnvironment")
    @StarLogging(loggingEvent = PolicyHistoryControllerApiProcessorImpl.class, actionName = POLICY_HISTORY_API_CONTROLLER_PROCESSOR)
    public ResponseObject<List<EnvVariablesResponse>> getPolicyDetails(@RequestParam String key) {
        log.info("Inside the getEnvironment Controller");
        var details = envVariablesService.getEnvironmentVariables(key);
        return new ResponseObject<>("Environment Variables Fetched Successfully", details);
    }

    @PostMapping("/updateEnvironment")
    @StarLogging(loggingEvent = PolicyHistoryControllerApiProcessorImpl.class, actionName = POLICY_HISTORY_API_CONTROLLER_PROCESSOR)
    public ResponseObject<String> updateEnvironmentDetails(
            @RequestParam String key,
            @RequestParam boolean deleteEnvironment,
            @RequestBody(required = false) EnvironmentVariablesRequestDto environmentVariablesRequestDto) {
        log.info("Inside the UpdateEnvironment Controller");
        var message = envVariablesService.updateEnvironmentVariables(key, deleteEnvironment, environmentVariablesRequestDto);
        return new ResponseObject<>(message);
    }

    @PostMapping("/createEnvironment")
    @StarLogging(loggingEvent = PolicyHistoryControllerApiProcessorImpl.class, actionName = POLICY_HISTORY_API_CONTROLLER_PROCESSOR)
    public ResponseObject<String> createEnvironmentDetails(
            @Valid @RequestBody EnvironmentVariablesRequestDto environmentVariablesRequestDto) {
        log.info("Inside the CreateEnvironment Controller");
        var message = envVariablesService.createEnvironmentVariables(environmentVariablesRequestDto);
        return new ResponseObject<>(message);
    }

    @PostMapping("/deleteEnvironment")
    public ResponseObject<String> deleteEnvironmentDetails(
            @Valid @RequestBody EnvVariableDeleteRequestDto deleteRequestDto
            ){
        log.info("Inside the DeleteEnvironment Controller");
        var message =envVariablesService.deleteEnvironmentVariables(deleteRequestDto);
        return new ResponseObject<>(message);
    }

    @PostMapping("/testDatalake")
    @StarLogging(loggingEvent = PolicyHistoryControllerApiProcessorImpl.class, actionName = POLICY_HISTORY_API_CONTROLLER_PROCESSOR)
    public DataBricksResponse testDataLake(@RequestBody StatementIDRequest statementIDRequest) {
        return dataLakeClient.getDataBricksResponse(statementIDRequest);
    }

    @PostMapping("/removePmsProgressData")
    public boolean removePmsData(@RequestBody String objectId) {
        pmsBatchProgressRepository.deleteById(objectId);
        return true;
    }

    @PostMapping("/removePolicyDetailData")
    public boolean removePolicyDetailData(@RequestBody String objectId) {
        policyBatchDetailRepository.deleteById(objectId);
        return true;
    }
}
