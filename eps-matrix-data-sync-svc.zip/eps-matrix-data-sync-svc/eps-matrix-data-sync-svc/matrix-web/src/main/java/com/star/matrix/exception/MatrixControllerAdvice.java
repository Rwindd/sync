package com.star.matrix.exception;

import com.star.matrix.response.Meta;
import com.star.matrix.response.ResponseObject;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.filter.ServerHttpObservationFilter;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.util.stream.Collectors;


@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
public class MatrixControllerAdvice {
    private final MeterRegistry registry;

    @ExceptionHandler(MatrixDataSyncException.class)
    public ResponseEntity<ResponseObject<Object>> handleException(HttpServletRequest request, MatrixDataSyncException ex) {

        log.error("Matrix data sync exception occurred", ex);
        setErrorInMetric(request, ex);
        MatrixErrorCode errorCode = ex.getMatrixErrorCode();
        String message = errorCode.name();
        String displayMessage;
        if (StringUtils.hasText(ex.getMessage())) {
            displayMessage = ex.getMessage();
        } else {
            displayMessage = errorCode.getDisplayMessage();
        }
        Meta meta = new Meta(errorCode.getCode(), message, displayMessage);
        ResponseObject<Object> objectOrderResponse = new ResponseObject<>(meta, null);
        return new ResponseEntity<>(objectOrderResponse, errorCode.getHttpStatus());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ResponseObject<Object>> handleGenericException(HttpServletRequest request, Exception ex) {

        log.error("Generic Exception occurred", ex);
        setErrorInMetric(request, ex);

        MatrixErrorCode errorCode = MatrixErrorCode.TECHNICAL_FAILURE;
        String message = errorCode.name();
        String displayMessage;
        if (StringUtils.hasText(ex.getMessage())) {
            displayMessage = ex.getMessage();
        } else {
            displayMessage = errorCode.getDisplayMessage();
        }
        Meta meta = new Meta(errorCode.getCode(), message, displayMessage);
        ResponseObject<Object> objectOrderResponse = new ResponseObject<>(meta, null);
        return new ResponseEntity<>(objectOrderResponse, errorCode.getHttpStatus());

    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ResponseObject<Object>> handleConstraintViolationException(HttpServletRequest request,
                                                                                     ConstraintViolationException ex) {

        log.error("ConstraintViolationException occurred", ex);
        setErrorInMetric(request, ex);
        MatrixErrorCode errorCode = MatrixErrorCode.INVALID_PAYLOAD;
        String message = errorCode.name();
        String exceptionMessage = ex.getConstraintViolations().stream().map(ConstraintViolation::getMessage)
                .collect(Collectors.joining(", "));
        String displayMessage;
        if (StringUtils.hasLength(exceptionMessage))
            displayMessage = exceptionMessage;
        else
            displayMessage = errorCode.getDisplayMessage();
        Meta meta = new Meta(errorCode.getCode(), message, displayMessage);
        ResponseObject<Object> objectOrderResponse = new ResponseObject<>(meta, null);
        return new ResponseEntity<>(objectOrderResponse, errorCode.getHttpStatus());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResponseObject<Object>> handleMethodException(HttpServletRequest request,
                                                                        MethodArgumentNotValidException ex) {

        log.error("MethodArgumentNotValidException occurred", ex);
        setErrorInMetric(request, ex);
        MatrixErrorCode errorCode = MatrixErrorCode.INVALID_PAYLOAD;
        String message = errorCode.name();
        String exceptionMessage = ex.getBindingResult().getFieldErrors().stream()
                .map(result-> result.getField()+" " +result.getDefaultMessage()).collect(Collectors.joining(", "));
        String displayMessage;
        if (StringUtils.hasLength(exceptionMessage))
            displayMessage = exceptionMessage;
        else
            displayMessage = errorCode.getDisplayMessage();
        Meta meta = new Meta(errorCode.getCode(), message, displayMessage);
        ResponseObject<Object> objectOrderResponse = new ResponseObject<>(meta, null);
        return new ResponseEntity<>(objectOrderResponse, errorCode.getHttpStatus());
    }

    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<ResponseObject<Object>> handleNoResourceFoundException(
            HttpServletRequest request, Exception ex) {

        log.error("NoResourceFound Exception occurred", ex);
        MatrixErrorCode resourceNotFound = MatrixErrorCode.RESOURCE_NOT_FOUND;
        ResponseObject<Object> objectDmsResponse = new ResponseObject<>(resourceNotFound);
        return new ResponseEntity<>(objectDmsResponse, resourceNotFound.getHttpStatus());

    }

    private void setErrorInMetric(HttpServletRequest request, Exception ex) {
        if (ex instanceof MatrixDataSyncException matrixDataSyncException) {
            var counter = getCounter(request, matrixDataSyncException.getMatrixErrorCode().name(),
                    matrixDataSyncException.getMatrixErrorCode().getCode(),
                    matrixDataSyncException.getMatrixErrorCode().getCategory().name());

            counter.increment();
        } else {
            var counter = getCounter(request, ex.getMessage(), "unexpected-error",
                    MatrixErrorCode.ErrorCategory.TECHNICAL.name());
            counter.increment();
        }
        ServerHttpObservationFilter.findObservationContext(request)
                .ifPresent(context -> context.setError(ex));
    }

    @NotNull
    private Counter getCounter(HttpServletRequest request, String errorName, String errorCode, String category) {
        return Counter.builder("orderErrorCodeCounter")
                .tag("uri", request.getRequestURI())
                .tag("name", errorName)
                .tag("code", errorCode)
                .tag("category", category)
                .tag("method", request.getMethod())
                .register(registry);
    }


}

