package com.star.matrix;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.scheduling.annotation.EnableAsync;

@RequiredArgsConstructor
@SpringBootApplication(scanBasePackages = "com.star.matrix",
	exclude = {
		HibernateJpaAutoConfiguration.class, JpaRepositoriesAutoConfiguration.class
	}
)
@ComponentScan(basePackages = {"com.star.matrix", "com.star.eps","com.starhealth.encryption"})
@EnableMongoAuditing
@EnableAsync
public class MatrixWebApplication {
	public static void main(String[] args) {
		SpringApplication.run(MatrixWebApplication.class, args);
	}
}
