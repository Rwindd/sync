package com.star.matrix.controller;

import com.star.matrix.DataSyncService;
import com.star.matrix.dto.request.*;
import com.star.matrix.impl.ZohoTokenManager;
import com.star.matrix.response.ResponseObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

@RestController
@RequestMapping("/api/v1")
@Slf4j
@RequiredArgsConstructor
public class DataSyncController {

    private final DataSyncService dataSyncService;



    @PostMapping("/pms/sync")
    public ResponseObject<String> runPmsSync(@RequestBody PMSDataPullingRequest pmsDataPullingRequest) {
        dataSyncService.processPmsDataFromDataLake(convertToDateTime(pmsDataPullingRequest.getStartDateTime()),
                convertToDateTime(pmsDataPullingRequest.getEndDateTime()));
        return new ResponseObject<>("Hospital Data Pulled Successfully");
    }

    @PostMapping("/policy/sync")
    public ResponseObject<String> runPolicySync(@RequestBody PolicyDataPullingRequest policyDetailRequest) {
        dataSyncService.processMinimumPolicyDataFromDataLake(convertToDate(policyDetailRequest.getPullingDate()), policyDetailRequest.isManual());
        return new ResponseObject<>("Policy Data Pulled Successfully");
    }

    @PostMapping("/matrix/pms/sync")
    public ResponseObject<String> runMatrixPmsSync(@RequestBody PMSDataPullingRequest pmsDataPullingRequest) {
        dataSyncService.processPmsDataToMatrix();
        return new ResponseObject<>("Pms data pushed to matrix");
    }

    @PostMapping("matrix/policy/sync")
    public ResponseObject<String> runMatrixPolicySync() {
        dataSyncService.processMinimumPolicyDataToMatrix();
        return new ResponseObject<>("policy data pushed to matrix");
    }

    @PostMapping("matrix/policy/onetime/changeStatus")
    public ResponseObject<Boolean> runMatrixPolicyOneTimeSync(@RequestBody OneTimeBatchUpdateRequest request) {
        log.info("Request received for change status of one time data sync : {}", request);
        dataSyncService.processOneTimeMinimumPolicyDataToMatrix(request);
        return new ResponseObject<>("true");
    }

    @PostMapping("matrix/policy/onetime/remove")
    public ResponseObject<Boolean> runMatrixPolicyOneTimeSyncRemove(@RequestBody OneTimeBatchRemoveRequest oneTimeBatchRemoveRequest) {
        log.info("Request received for removing data of one time data sync : {}", oneTimeBatchRemoveRequest);
        dataSyncService.processOneTimeMinimumPolicyDataRemovalToMatrix(oneTimeBatchRemoveRequest);
        return new ResponseObject<>("true");
    }

    @PostMapping("matrix/group-policy/onetime/changeStatus")
    public ResponseObject<Boolean> runMatrixGroupPolicyOneTimeSync(@RequestBody OneTimeGroupBatchUpdateRequest request) {
        log.info("Request received for change status of one time group policy data sync : {}", request);
        dataSyncService.processOneTimeMinimumGroupPolicyDataToMatrix(request);
        return new ResponseObject<>("true");
    }

    @PostMapping("matrix/group-policy/onetime/remove")
    public ResponseObject<Boolean> runMatrixGroupPolicyOneTimeSyncRemove(@RequestBody OneTimeBatchRemoveRequest oneTimeBatchRemoveRequest) {
        log.info("Request received for removing data of one time group policy data sync : {}", oneTimeBatchRemoveRequest);
        dataSyncService.processOneTimeMinimumGroupPolicyDataRemovalToMatrix(oneTimeBatchRemoveRequest);
        return new ResponseObject<>("true");
    }

    private LocalDateTime convertToDateTime(Long epochMillis) {
        return Instant.ofEpochMilli(epochMillis)
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();
    }

    public static LocalDate convertToDate(Long epochMillis) {
        return Instant.ofEpochMilli(epochMillis)
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }

    @PostMapping("matrix/policy/retry")
    public ResponseObject<Boolean> retryFailedPolicies(@RequestBody RetryFailedCasesDto request) {
        log.info("Request received for retry Failed Push Policies sync : {}", request);
        if(request.isPolicyFlag()){
            dataSyncService.processMinimumPolicyDataToMatrix(request.getStartDate(), request.getEndDate(), request.getBatchSize());
        }else{
            dataSyncService.processPmsDataToMatrix(request.getStartDate(), request.getEndDate(), request.getBatchSize());
        }
        return new ResponseObject<>("true");
    }

    @PostMapping("zoho/renew-quote/retry")
    public ResponseObject<Boolean> retryFailedRenewQuotes(@RequestBody RetryFailedCasesDto request) {
        log.info("Request received for retry Failed Push Renew quote sync : {}", request);
        dataSyncService.processRenewQuoteDataToZoho(request.getStartDate(), request.getEndDate(), request.getBatchSize());
        return new ResponseObject<>("true");
    }


}
