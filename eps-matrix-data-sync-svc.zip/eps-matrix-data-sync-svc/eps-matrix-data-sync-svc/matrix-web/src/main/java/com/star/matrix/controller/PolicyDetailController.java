package com.star.matrix.controller;

import com.star.eps.annotations.StarLogging;
import com.star.matrix.PolicyDetailService;
import com.star.matrix.dto.request.UpdateIndexRequestDto;
import com.star.matrix.dto.response.PolicyHistoryResponse;
import com.star.matrix.logging.PolicyHistoryControllerApiProcessorImpl;
import com.star.matrix.repository.PolicyBatchProgressRepository;
import com.star.matrix.repository.PolicyPayloadRepository;
import com.star.matrix.response.ResponseObject;
import com.star.matrix.util.ApplicationUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import static com.star.matrix.util.ApplicationConstant.POLICY_HISTORY_API_CONTROLLER_PROCESSOR;

@RestController
@RequestMapping("/api/v1/policy")
@Slf4j
@RequiredArgsConstructor
public class PolicyDetailController {

    private final PolicyDetailService policyDetailService;
    private final PolicyBatchProgressRepository policyBatchProgressRepository;
    private final PolicyPayloadRepository policyPayloadRepository;

    @GetMapping("/fetch")
    @StarLogging(loggingEvent = PolicyHistoryControllerApiProcessorImpl.class, actionName = POLICY_HISTORY_API_CONTROLLER_PROCESSOR)
    public ResponseObject<PolicyHistoryResponse> getPolicyDetails(@RequestParam String policyNumber) {
        log.info("Inside the getPolicyDetails Controller");
        var details = policyDetailService.getPolicyHistoryDetails(policyNumber);
        return new ResponseObject<>("policy details fetched successfully", details);
    }

    @PostMapping("/changeIndex")
    public boolean pushPolicyDataExplicitly(@RequestBody UpdateIndexRequestDto updateIndexRequestDto) {
        var batchHistoryOptional = policyBatchProgressRepository.findFirstByDateOrderByCreatedAtDesc(ApplicationUtil.convertToDate(updateIndexRequestDto.getPullingDate()).atStartOfDay());
        if (batchHistoryOptional.isPresent()) {
            var batchHistory = batchHistoryOptional.get();
            batchHistory.setEndIndex(updateIndexRequestDto.getEndIndex());
            batchHistory.setEndIndex(updateIndexRequestDto.getStartIndex());
            policyBatchProgressRepository.save(batchHistory);
            return true;
        }
        return false;
    }

    @PostMapping("/removePolicyProgressReportedDate")
    public boolean removePolicyProgressReportedDate(@RequestBody UpdateIndexRequestDto updateIndexRequestDto) {
        policyBatchProgressRepository.deleteAllByDate(ApplicationUtil.convertToDate(updateIndexRequestDto.getPullingDate()).atStartOfDay());
        return true;
    }

    @PostMapping("/removePolicyDetail")
    public boolean removePolicyDetail() {
        policyPayloadRepository.deleteAll();
        return true;
    }
}
