package com.star.matrix.repository;

import com.star.matrix.entity.zoho.RenewQuoteBatchProgress;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface RenewQuoteBatchProgressRepository extends MongoRepository<RenewQuoteBatchProgress, String> {
    Optional<RenewQuoteBatchProgress> findFirstByDateOrderByCreatedAtDesc(LocalDateTime date);
}
