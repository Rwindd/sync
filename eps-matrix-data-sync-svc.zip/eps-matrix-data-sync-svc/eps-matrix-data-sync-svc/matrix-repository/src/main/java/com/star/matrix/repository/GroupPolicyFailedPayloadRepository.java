package com.star.matrix.repository;

import com.star.matrix.entity.grouppolicy.GroupPolicyFailedPayload;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface GroupPolicyFailedPayloadRepository extends MongoRepository<GroupPolicyFailedPayload, String> {
}
