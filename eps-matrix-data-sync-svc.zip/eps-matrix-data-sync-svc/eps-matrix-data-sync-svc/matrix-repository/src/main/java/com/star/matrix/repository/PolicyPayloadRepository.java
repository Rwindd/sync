package com.star.matrix.repository;

import com.star.matrix.entity.PolicyPayload;
import com.star.matrix.enumeration.RequestStatus;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
@Repository
public interface PolicyPayloadRepository extends MongoRepository<PolicyPayload, String> {

    List<PolicyPayload> findByStatusAndCreatedAtBetweenOrderByCreatedAtAsc(
             RequestStatus status,
             Instant startDate,
             Instant endDate,
             Pageable pageable
    );

    List<PolicyPayload> findByStatusOrderByCreatedAtAsc(RequestStatus status, Pageable pageable);

}
