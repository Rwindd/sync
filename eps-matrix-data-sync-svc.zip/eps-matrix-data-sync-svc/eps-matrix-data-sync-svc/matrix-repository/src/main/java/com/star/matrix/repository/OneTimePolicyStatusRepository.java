package com.star.matrix.repository;

import com.star.matrix.entity.OneTimePolicyStatus;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OneTimePolicyStatusRepository extends MongoRepository<OneTimePolicyStatus, String> {

    Optional<OneTimePolicyStatus> findFirstByOrderByCreatedAtDesc();

}

