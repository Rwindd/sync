package com.star.matrix.repository;

import com.star.matrix.dto.postgres.PostgresClaimDocument;
import com.star.matrix.dto.postgres.PostgresClaimHistory;
import com.star.matrix.dto.postgres.PostgresPolicyDetail;
import com.star.matrix.dto.postgres.PostgresPolicyDocument;

import java.util.List;
import java.util.Set;

public interface PostgresRepository {
    List<PostgresPolicyDetail> getPolicyAndMemberDetails(String postgresQuery, String policyNumber);

    List<PostgresPolicyDocument> getPolicyDocuments(String postgresQuery, Set<String> policyNumbers);
    List<PostgresClaimHistory> getPolicyClaimHistory(String postgresQuery, Set<String> policyNumbers);
    List<PostgresClaimDocument> getPolicyClaimDocuments(String postgresQuery, Set<String> policyNumbers);
}
