package com.star.matrix.repository;

import com.star.matrix.entity.zoho.RenewQuoteFailedPayload;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RenewQuoteFailedPayloadRepository extends MongoRepository<RenewQuoteFailedPayload, String> {
}
