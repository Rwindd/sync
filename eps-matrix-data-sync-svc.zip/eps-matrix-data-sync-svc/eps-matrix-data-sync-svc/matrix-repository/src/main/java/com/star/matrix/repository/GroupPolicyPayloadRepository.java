package com.star.matrix.repository;

import com.star.matrix.entity.grouppolicy.GroupPolicyPayload;
import com.star.matrix.enumeration.RequestStatus;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface GroupPolicyPayloadRepository extends MongoRepository<GroupPolicyPayload, String> {
    List<GroupPolicyPayload> findByStatusOrderByCreatedAtDesc(RequestStatus requestStatus, Pageable pageable);
    List<GroupPolicyPayload> findByStatusAndCreatedAtBeforeOrderByCreatedAtDesc(
            RequestStatus status,
            Instant dateTime,
            Pageable pageable
    );

    Optional<GroupPolicyPayload> findByRecordId(String recordId);
}
