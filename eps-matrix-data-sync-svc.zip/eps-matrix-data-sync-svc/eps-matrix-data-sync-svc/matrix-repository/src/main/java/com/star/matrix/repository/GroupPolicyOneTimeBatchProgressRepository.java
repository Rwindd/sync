package com.star.matrix.repository;

import com.star.matrix.entity.grouppolicy.OneTimeGroupPolicyBatchProgress;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GroupPolicyOneTimeBatchProgressRepository extends MongoRepository<OneTimeGroupPolicyBatchProgress, String> {
    Optional<OneTimeGroupPolicyBatchProgress> findFirstByOrderByCreatedAtDesc();
}
