package com.star.matrix.repository;

import com.star.matrix.dto.postgres.PostgresClaimDocument;
import com.star.matrix.dto.postgres.PostgresClaimHistory;
import com.star.matrix.dto.postgres.PostgresPolicyDetail;
import com.star.matrix.dto.postgres.PostgresPolicyDocument;
import com.star.matrix.mapper.PostgresClaimHistoryMapper;
import com.star.matrix.mapper.PostgresPolicyDetailMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Repository
@Slf4j
public class PostgresRepositoryImpl implements PostgresRepository{

    private final NamedParameterJdbcTemplate matrixSyncJdbcTemplate;
    private final PostgresPolicyDetailMapper policyDetailMapper;
    private final PostgresClaimHistoryMapper claimHistoryMapper;

    public PostgresRepositoryImpl(@Qualifier("matrixSyncJdbcTemplate") NamedParameterJdbcTemplate matrixSyncJdbcTemplate, PostgresPolicyDetailMapper policyDetailMapper, PostgresClaimHistoryMapper claimHistoryMapper) {
        this.matrixSyncJdbcTemplate = matrixSyncJdbcTemplate;
        this.policyDetailMapper = policyDetailMapper;
        this.claimHistoryMapper = claimHistoryMapper;
    }


    @Override
    public List<PostgresPolicyDetail> getPolicyAndMemberDetails(String postgresQuery, String policyNumber) {
        Map<String, Object> params = new HashMap<>();
        params.put("policyNumber", policyNumber);

        var result = matrixSyncJdbcTemplate.query(
                postgresQuery,
                params,
                policyDetailMapper);
        return result;
    }

    @Override
    public List<PostgresPolicyDocument> getPolicyDocuments(String postgresQuery, Set<String> policyNumbers) {
        Map<String, Object> params = new HashMap<>();
        params.put("policyNumbers", policyNumbers);
        return matrixSyncJdbcTemplate.query(
                postgresQuery,
                params,
                new BeanPropertyRowMapper<>(PostgresPolicyDocument.class));
    }

    @Override
    public List<PostgresClaimHistory> getPolicyClaimHistory(String postgresQuery, Set<String> policyNumbers) {
        Map<String, Object> params = new HashMap<>();
        params.put("policyNumbers", policyNumbers);
        return matrixSyncJdbcTemplate.query(
                postgresQuery,
                params,
                claimHistoryMapper);
    }

    @Override
    public List<PostgresClaimDocument> getPolicyClaimDocuments(String postgresQuery, Set<String> policyNumbers) {
        Map<String, Object> params = new HashMap<>();
        params.put("policyNumbers", policyNumbers);
        return matrixSyncJdbcTemplate.query(
                postgresQuery,
                params,
                new BeanPropertyRowMapper<>(PostgresClaimDocument.class));
    }
}
