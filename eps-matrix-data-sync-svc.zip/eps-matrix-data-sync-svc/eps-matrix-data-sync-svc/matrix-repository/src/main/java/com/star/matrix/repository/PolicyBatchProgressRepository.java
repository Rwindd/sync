package com.star.matrix.repository;

import com.star.matrix.entity.PolicyBatchProgress;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface PolicyBatchProgressRepository extends MongoRepository<PolicyBatchProgress, String> {

    Optional<PolicyBatchProgress> findFirstByDateOrderByCreatedAtDesc(LocalDateTime date);

    void deleteAllByDate(LocalDateTime date);

}
