package com.star.matrix.repository;

import com.star.matrix.entity.HospitalFailedPayload;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HospitalFailedPayloadRepository extends MongoRepository<HospitalFailedPayload,String> {
}
