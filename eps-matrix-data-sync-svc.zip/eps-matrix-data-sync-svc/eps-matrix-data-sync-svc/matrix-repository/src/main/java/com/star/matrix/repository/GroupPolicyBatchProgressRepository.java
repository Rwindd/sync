package com.star.matrix.repository;

import com.star.matrix.entity.grouppolicy.GroupPolicyBatchProgress;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface GroupPolicyBatchProgressRepository extends MongoRepository<GroupPolicyBatchProgress, String> {

    Optional<GroupPolicyBatchProgress> findFirstByDateOrderByCreatedAtDesc(LocalDateTime date);
}

