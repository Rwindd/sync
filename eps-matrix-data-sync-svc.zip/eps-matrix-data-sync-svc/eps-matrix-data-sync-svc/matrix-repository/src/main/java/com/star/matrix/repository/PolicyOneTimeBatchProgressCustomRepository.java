package com.star.matrix.repository;

import com.star.matrix.entity.BatchStatus;
import com.star.matrix.entity.OneTimePolicyBatchProgress;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Slf4j
@Repository
@RequiredArgsConstructor
public class PolicyOneTimeBatchProgressCustomRepository {

    private final MongoTemplate mongoTemplate;

    public List<OneTimePolicyBatchProgress> getOneTimePolicyBatchProgress(int startIndex, int endIndex,
                                                                          int batchSize, int page, List<BatchStatus> status, boolean matrixSuccess) {
        Criteria criteria = Criteria.where("endIndex").lte(endIndex).and("startIndex").gte(startIndex)
                .and("isMatrixSuccess").is(matrixSuccess);
        if (!CollectionUtils.isEmpty(status)) {
            criteria = criteria.and("status").in(status);
        }
        Pageable pageable = PageRequest.of(page, batchSize, Sort.by("createdAt").ascending());
        Query query = new Query(criteria).with(pageable);
        return mongoTemplate.find(query, OneTimePolicyBatchProgress.class);
    }
}
