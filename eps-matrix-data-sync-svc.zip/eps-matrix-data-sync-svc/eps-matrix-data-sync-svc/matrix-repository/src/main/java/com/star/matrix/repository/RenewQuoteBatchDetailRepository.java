package com.star.matrix.repository;

import com.star.matrix.entity.zoho.RenewQuoteBatchDetail;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.LocalDateTime;
import java.util.Optional;

public interface RenewQuoteBatchDetailRepository extends MongoRepository<RenewQuoteBatchDetail, String> {
    Optional<RenewQuoteBatchDetail> findFirstByDateOrderByCreatedAtDesc(LocalDateTime date);
}
