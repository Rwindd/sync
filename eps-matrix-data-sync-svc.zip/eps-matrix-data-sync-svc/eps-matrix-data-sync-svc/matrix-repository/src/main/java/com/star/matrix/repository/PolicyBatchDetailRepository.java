package com.star.matrix.repository;

import com.star.matrix.entity.OneTimePolicyStatus;
import com.star.matrix.entity.PolicyBatchDetail;
import com.star.matrix.entity.PolicyBatchProgress;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface PolicyBatchDetailRepository extends MongoRepository<PolicyBatchDetail, String> {

    Optional<PolicyBatchDetail> findFirstByDateOrderByCreatedAtDesc(LocalDateTime date);

}

