package com.star.matrix.repository;

import com.star.matrix.entity.OneTimePolicyBatchProgress;
import com.star.matrix.entity.PolicyBatchProgress;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PolicyOneTimeBatchProgressRepository extends MongoRepository<OneTimePolicyBatchProgress, String> {

    Optional<PolicyBatchProgress> findFirstByOrderByCreatedAtDesc();

}
