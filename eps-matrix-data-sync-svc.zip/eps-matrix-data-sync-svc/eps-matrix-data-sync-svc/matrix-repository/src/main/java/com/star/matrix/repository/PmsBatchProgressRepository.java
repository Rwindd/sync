package com.star.matrix.repository;

import com.star.matrix.entity.PmsBatchProgress;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PmsBatchProgressRepository extends MongoRepository<PmsBatchProgress, String> {

    Optional<PmsBatchProgress> findFirstByOrderByToTimeDesc();
}
