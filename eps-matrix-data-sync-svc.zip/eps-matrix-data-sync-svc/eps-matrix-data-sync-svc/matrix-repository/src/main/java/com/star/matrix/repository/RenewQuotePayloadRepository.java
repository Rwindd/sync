package com.star.matrix.repository;

import com.star.matrix.entity.grouppolicy.GroupPolicyPayload;
import com.star.matrix.entity.zoho.RenewQuotePayload;
import com.star.matrix.enumeration.RequestStatus;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface RenewQuotePayloadRepository extends MongoRepository<RenewQuotePayload, String> {

    List<RenewQuotePayload> findByStatusAndCreatedAtBetweenOrderByCreatedAtAsc(
            RequestStatus status,
            Instant startDate,
            Instant endDate,
            Pageable pageable
    );

    List<RenewQuotePayload> findByStatusOrderByCreatedAtAsc(RequestStatus status, Pageable pageable);

    Optional<RenewQuotePayload> findByRecordId(String recordId);

    List<RenewQuotePayload> findByStatusAndCreatedAtBeforeOrderByCreatedAtDesc(
            RequestStatus status,
            Instant dateTime,
            Pageable pageable
    );}
