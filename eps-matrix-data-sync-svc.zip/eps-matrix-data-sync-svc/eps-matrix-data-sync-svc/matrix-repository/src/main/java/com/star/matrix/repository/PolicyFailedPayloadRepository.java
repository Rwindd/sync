package com.star.matrix.repository;

import com.star.matrix.entity.PolicyFailedPayload;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PolicyFailedPayloadRepository extends MongoRepository<PolicyFailedPayload, String>{
}
