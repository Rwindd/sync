package com.star.matrix.repository;

import com.star.matrix.entity.grouppolicy.GroupPolicyBatchDetail;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface GroupPolicyBatchDetailRepository extends MongoRepository<GroupPolicyBatchDetail, String> {

    Optional<GroupPolicyBatchDetail> findFirstByDateOrderByCreatedAtDesc(LocalDateTime date);
}

