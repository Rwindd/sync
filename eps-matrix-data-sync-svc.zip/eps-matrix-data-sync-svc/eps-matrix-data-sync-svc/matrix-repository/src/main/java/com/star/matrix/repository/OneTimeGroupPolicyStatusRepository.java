package com.star.matrix.repository;

import com.star.matrix.entity.grouppolicy.OneTimeGroupPolicyStatus;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OneTimeGroupPolicyStatusRepository extends MongoRepository<OneTimeGroupPolicyStatus, String> {
    Optional<OneTimeGroupPolicyStatus> findFirstByOrderByCreatedAtDesc();

}
