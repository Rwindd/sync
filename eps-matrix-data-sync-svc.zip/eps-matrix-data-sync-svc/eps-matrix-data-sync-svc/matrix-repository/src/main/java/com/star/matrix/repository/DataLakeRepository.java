package com.star.matrix.repository;

import com.star.matrix.entity.CustomerDetail;
import com.star.matrix.entity.DataLakeSourceEntity;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class DataLakeRepository {
    private final NamedParameterJdbcTemplate claimsJdbcTemplate;

    public DataLakeRepository(@Qualifier("claimsJdbcTemplate") NamedParameterJdbcTemplate claimsJdbcTemplate){
        this.claimsJdbcTemplate=claimsJdbcTemplate;
    }

    public List<DataLakeSourceEntity> findByIntimationNumber(String intimationNumber, String intimationQuery) {
        Map<String, Object> params = new HashMap<>();
        params.put("intimationNumber", intimationNumber);
        RowMapper<DataLakeSourceEntity> rowMapper = (rs, rowNum) -> new DataLakeSourceEntity(rs.getString("intimation_number"),rs.getString("processing_application"));
        return claimsJdbcTemplate.query(intimationQuery, params, rowMapper);
    }

    public List<CustomerDetail> findByPolicyNumber(String policyNumber, String policyQuery){
        Map<String, Object> params = new HashMap<>();
        params.put("policyNumber", policyNumber);
        RowMapper<CustomerDetail> rowMapper = (rs, rowNum) -> new CustomerDetail(rs.getString("policy_number"),
                rs.getString("health_id"),
                rs.getString("proposer_name"),
                rs.getString("insured_name"),
                rs.getString("insured_age"),
                rs.getString("plan_type"),
                rs.getString("policy_type"),
                rs.getString("proposer_pincode"),
                rs.getString("premium_amount"),
                rs.getString("sum_insured"),
                rs.getString("children_count"),
                rs.getString("adult_count"),
                rs.getString("risk_sr_no"),
                rs.getString("age_type"),
                rs.getString("agent_code"),
                rs.getString("agent_name"),
                rs.getString("agent_mobile_no_e"),
                rs.getString("proposer_mobile_no_e"),
                rs.getString("insured_mobile_no_e"),
                rs.getString("intermediary_type"),
                rs.getString("advisor_name"),
                rs.getString("advisor_contact")
                );
        return claimsJdbcTemplate.query(policyQuery,params, rowMapper);
    }
}