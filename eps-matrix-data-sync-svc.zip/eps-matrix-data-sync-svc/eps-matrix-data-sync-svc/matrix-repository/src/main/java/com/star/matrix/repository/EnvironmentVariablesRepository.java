package com.star.matrix.repository;

import com.star.matrix.entity.EnvironmentVariables;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface EnvironmentVariablesRepository extends MongoRepository<EnvironmentVariables, String> {

    Optional<EnvironmentVariables> findByKey(String key);

}

